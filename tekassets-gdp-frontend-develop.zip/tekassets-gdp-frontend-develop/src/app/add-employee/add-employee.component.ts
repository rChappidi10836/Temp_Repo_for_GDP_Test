import { Component, OnInit, Renderer2, ViewChild } from '@angular/core';
import {
  Validators,
  FormBuilder,
  FormGroup,
  FormControl,
} from '@angular/forms';
import {
  IconDefinition,
  faSearch,
} from '@fortawesome/free-solid-svg-icons';
import { AdminDropdownService } from './../services/admin-dropdown.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CreateProjectDialogComponent } from '../create-project-dialog/create-project-dialog.component';
import { Router } from '@angular/router';
import { NotificationDialogComponent } from '../notification-dialog/notification-dialog.component';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { AuthGuardService } from '../services/auth_guard.service';
import { DemoService } from '../services/demo.service';
import { SharedService } from '../services/shared.service';
import { Constants } from '../model/Constants';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss'],
})
export class AddEmployeeComponent implements OnInit {
  public disableButton = true;
  public userIdExist = '';
  public showOnSave = false;
  public editMode = false;
  public errorMessage = '';
  public titleText = '';
  public noteText = '';
  public buttonText = '';
  public jobTitleData = [];
  public opcoData = [];
  public editFName = '';
  public editSName = '';
  public editLName = '';
  public editUserId = '';
  public editOpco = '';
  public opco = '';
  public changeText = true;
  editData: any;
  jobTitleDropdown: any[];
  originalJobTitleData: any[];
  public resourceForm: FormGroup;
  faSearch: IconDefinition = faSearch;
  filteredOptions = [];
  opcoDropDown: any[];
  originalOpcoData: any[];
  selectedRegion: string;
  public jobTitleFilterCtrl: FormControl = new FormControl();
  public opcoFilterCtrl: FormControl = new FormControl();
  protected onDestroy = new Subject<void>();
  public userRole;
  public isSuperAdmin;
  opcoDisable: string | boolean;
  selectedOpcoId: any;
  userOpcoId: any;
  defaultOpcoName: any;
  sharedData: any;
  opcompchange: boolean=false;


  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    private router: Router,
    private adminDropdownService: AdminDropdownService,
    private authService: AuthGuardService,
    private demoService:DemoService,
    private sharedService:SharedService,
  ) {
    //Added this part to get current user role , so that if user role is super admin opoc field can be enabled
    this.userRole = this.authService.currentUserRole().subscribe((data) => {
      this.userRole = data[0].substring(5);
      this.isSuperAdmin = this.userRole === 'Super Admin';
    });
  }
  /**
   * prevents dupliction of user id
   * checks with the service call if entered id exist
   * @param id entered by user
   */
  getUserId(id) {
    if (this.editMode === false) {
      this.adminDropdownService.getUserId(id,this.resourceForm.controls['opco'].value).subscribe((data) => {
        if (data === true) {
          this.resourceForm.controls.userId.markAsTouched();
          this.resourceForm.get('userId').setErrors({
            exist: true,
          });
        } else {
          this.resourceForm.get('userId').setErrors(null);
        }
      });
    }
  }
  /**
   * prevents duplication of employee ID
   * checks with previously existing employeeid
   * @param id  entered by user
   */
  getEmployeeId(id) {
    this.adminDropdownService.getEmployeeId(id,this.resourceForm.controls['opco'].value).subscribe((data) => {
      if (data === true) {
        this.resourceForm.controls.empId.markAsTouched();
        this.resourceForm.get('empId').setErrors({
          exist: true,
        });
      } else {
        this.resourceForm.get('empId').setErrors(null);
      }
    });
  }
  ngOnInit() {
    this.formBuilder();
    this.opcoDisable=this.userRole === 'Executive'||'Admin';

    // case used for adding new employee
    if (this.router.url.split('/')[2] === 'edit-employee') {
      this.editMode = true;
      this.resourceForm.get('empId').disable();
      this.resourceForm.get('jobTitle').disable();
      this.resourceForm.get('terminationDate').disable();
      this.resourceForm.get('hireDate').disable();
      this.titleText = 'EDIT';
      this.buttonText = 'Update';
      this.noteText = 'Use the form below to view/Edit Resources';
    } // case used for previously existing employee
    else {
      
      this.titleText = 'ADD';
      this.buttonText = 'Save';
      this.noteText = 'Please add resources';
    }
    this.resourceForm.patchValue({
      opco:this.sharedService.sharedDataSubject.value||1,
      // opco: this.editData.opcoId,
    });

    this.getEditData()
    this.getJobTitleDropdown();
    this.getSupervisorChanges();
    this.getOpcoDropdown();
    this.jobTitleFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterJobTitle();
      });
    this.opcoFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterOpco();
      });
  }
ngAfterViewInit(){
if(Constants.CURRENT_ROLE=='Admin'&& this.router.url.split('/')[2] !== 'edit-employee') {
    if(this.sharedService.sharedDataSubject.value==null) {
      this.resourceForm.controls['opco'].setValue(
        Number(1)
         
      );
       console.log(this.sharedService.sharedDataSubject.value)
   
      }else{
      this.resourceForm.controls['opco'].setValue(
        Number(this.sharedService.sharedDataSubject.value)
      );
    }
  } 
  

}

  ngOnDestroy() {
    this.onDestroy.next();
    this.onDestroy.complete();
  }

  filterJobTitle() {
    let search = this.jobTitleFilterCtrl.value;
    if (!search) {
      this.jobTitleData = this.originalJobTitleData;
    }
    search = search.toLowerCase();
    this.jobTitleData = this.originalJobTitleData.filter(
      (emp) => emp.designationName.toLowerCase().includes(search)
    );
  }

  filterOpco() {
    let search = this.opcoFilterCtrl.value;
    if (!search) {
      this.opcoData = this.originalOpcoData;
    }
    search = search.toLowerCase();
    this.opcoData = this.originalOpcoData.filter(
      (emp) => emp.opcoName.toLowerCase().includes(search)
    );
  }

  formBuilder() {
    this.resourceForm = this.fb.group({
      fName: [null, Validators.required],
      lName: [null, Validators.required],
      supervisorName: [null],
      hireDate: [null],
      empId: [null, Validators.required],
      userId: [null, Validators.required],
      jobTitle: [null],
      checkBoxStatus: [true, Validators.required],
      terminationDate: [null],
      opco: [null, Validators.required],
      jobCode: [null],
      resourceLocation: [null],
      access: [null]
    });
  }
  /**
   * list of supervisor on entering minimum 2 alphabets
   */
  getSupervisorChanges() {
    // if(!this.opcompchange){
    this.resourceForm.controls.supervisorName.valueChanges.subscribe(
      (value) => {
        if (value) {
          const temp = value;

          if (temp.split(',').length === 2) {
            value = temp.split(',')[1];
            value = value.substring(1);
            const temp1 = value;
            if (temp1.split(' ').length >= 2) {
              value = temp1.split(' ')[0];
            }
          }
          if (value !== null && value.length >= 2) {
            this.adminDropdownService
              .getSupervisorSearch(value,this.resourceForm.controls.opco.value||this.sharedService.sharedDataSubject.value||1)
              .subscribe((response) => {
                this.filteredOptions = response.data;
              });
              this.opcompchange=false
          } else {
            return null;
          }
        }
      }
    );
    // }
  }
  /**
   * displaying red error in case mandatory field is left
   */
  // selectOpco(option: any) {
  //   this.resourceForm.get('opco').setValue(option.id);
  // }
  setCssColor() {
    if (this.showOnSave === false) {
      return '#4D4F5C !important';
    } else {
      return '#95989A';
    }
  }
  cancelButton() {
    const dialogRef = this.dialog.open(CreateProjectDialogComponent);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        this.router.navigateByUrl('employee-details');
      } else if (data === false) {
        // nothing to do
      }
    });
  }

  onReset() {

    if (this.router.url.split('/')[2] === 'edit-employee') {
      this.resourceForm.markAsPristine();
      this.getEditData();
      this.editMode = true;
      this.changeText = true;
    } else {
      this.resourceForm.reset();
    }

  }

  getSupervisorSearch() {
    this.adminDropdownService.getSupervisorSearch('MI',this.resourceForm.controls.opco.value||this.sharedService.sharedDataSubject.value||1).subscribe((data) => { });
  }
  /**
   * drop down for job title
   */
  getJobTitleDropdown() {
    this.adminDropdownService.getJobTitleDropdown().subscribe((response) => {
      this.jobTitleData = response.data;
      this.originalJobTitleData = response.data;
      this.getEditData();
    });
  }
  getOpcoDropdown() {

    this.demoService.getOpcoDropdown().subscribe((response) => {
      this.getEditData();
      this.opcoData = response.data;
      console.log(this.editData.opcoName)
      this.originalOpcoData = response.data;
      for(let option of response.data){
      console.log(option)
        if(option.opcoName===this.editData.opcoName){
          this.userOpcoId=option.id
          console.log(this.userOpcoId)
          console.log(option.opcoName)
          console.log(this.editData.opcoName)
        }
        if(option.id===1){
          this.defaultOpcoName=option.opcoName
          
        }
      }
      this.getEditData();
     
    });
     
  }
  /**
   * checks if changes made in the fields
   * makes save button active only if its true
   * @param type
   */
  getEdit(type:string) {
    if (this.editMode === true) {
      if (type === 'fname') {
        if (this.editFName !== this.resourceForm.controls.fName.value) {
          this.changeText = false;
        } else {
          this.changeText = true;
        }

      }
      if (type === 'lname') {
        if (this.editLName !== this.resourceForm.controls.lName.value) {
          this.changeText = false;
        } else {
          this.changeText = true;
        }
      }
      if (type === 'sname') {

          if((this.editSName !== this.resourceForm.controls.supervisorName.value)){
            this.changeText = false;
            }
            else{
              this.changeText=true;
            }
        
      }
      if (type === 'userId') {
        if (this.editUserId !== this.resourceForm.controls.userId.value) {
          this.changeText = false;
        } else {
          this.changeText = true;
        }
      }
      if (type === 'opco') {
        if (this.resourceForm.controls.opco.value!==this.userOpcoId) {
          this.changeText = false;
        } else {
          this.changeText = true;
        }

      }

    }
  }
  getBoolValue(){ 
   console.log(this.resourceForm.controls.supervisorName.value!==null)
    if(this.resourceForm.controls.supervisorName.value===''&&this.userOpcoId===this.resourceForm.controls.opco.value){
      this.resourceForm.controls['supervisorName'].setValue(
        // this.resourceForm.controls.supervisorName.value
      this.editSName
      ); 
    }
    else {
    this.resourceForm.controls['supervisorName'].markAsTouched();
    this.resourceForm.controls['supervisorName'].setValue(
      // this.resourceForm.controls.supervisorName.value
    ''
    ); 
    this.opcompchange=true;
    this.filteredOptions=[]
    }
    
    
  }
  /**
   * after editing or adding employee
   *
   */
  onSubmit() {
    let hireDate;
    let termDate;
    if (!this.resourceForm.valid) {
      return;
    } else {
      this.disableButton = false;
      const hireDateValue = this.resourceForm.controls.hireDate.value;
      const hireDateTemp = hireDateValue === null ? null : new Date(
        hireDateValue
      );
      if(hireDateValue!==null){
      
      hireDateTemp.setMinutes(hireDateTemp.getMinutes()-hireDateTemp.getTimezoneOffset());
       hireDate=hireDateTemp.toISOString();
      }else{
        const hireDate=hireDateTemp;
      }
      
      
    
      const termDateValue = this.resourceForm.controls.terminationDate.value;
      const termDateTemp = termDateValue === null ? null : new Date(
        termDateValue
      );
      
      if(termDateValue!==null){
     
      termDateTemp.setMinutes(termDateTemp.getMinutes()-termDateTemp.getTimezoneOffset());
      termDate=termDateTemp.toISOString()
      }
      else{
        termDate=termDateTemp;
      }
      console.log('value is : ' + this.resourceForm.controls.opco.value);
      console.log(this.opcoData);
      const temp = {
        active: this.resourceForm.controls.checkBoxStatus.value,
        designationId: this.resourceForm.controls.jobTitle.value,
        employeeId: this.resourceForm.controls.empId.value,
        firstName: this.resourceForm.controls.fName.value,
        hireDate: hireDate,
        id: null,
        jobCode: this.resourceForm.controls.jobCode.value,
        lastName: this.resourceForm.controls.lName.value,
        middleName: null,
        resourceLocationId: this.resourceForm.controls.resourceLocation.value,
        terminationDate: termDate,
        username: this.resourceForm.controls.userId.value,
        opcoId:this.resourceForm.controls.opco.value ,
        access: this.resourceForm.controls.access.value,
      };
      temp['supervisorId']=''
      
        if(this.editSName===this.resourceForm.controls.supervisorName.value){
          console.log(this.editSName.split(',')[1])
            this.adminDropdownService
            .getSupervisorSearch(this.editSName.split(',')[1],this.resourceForm.controls.opco.value||this.sharedService.sharedDataSubject.value||1)
            .subscribe((response) => {
              this.filteredOptions = response.data;
            });
            for(let option of this.filteredOptions){

              if((option.fullName.trim()===this.editSName.trim())&&temp['supervisorId']===''){
                temp['supervisorId'] =option.id
              }
              }
              if(this.resourceForm.controls.supervisorName.value.trim()===''){
                temp['supervisorId']=''
              }
              
        }
      
        for(let option of this.filteredOptions){
          if(option.fullName===this.resourceForm.controls.supervisorName.value&&temp['supervisorId']===''){
            temp['supervisorId'] =option.id
          }
          else if(this.filteredOptions.length===1&&temp['supervisorId']===''){
             temp['supervisorId'] = this.filteredOptions[0].id
          }
        }
        if(this.editData!==''&&this.userOpcoId===this.resourceForm.controls.opco.value&&temp['supervisorId']===''&&this.resourceForm.controls.supervisorName.value!==''){
          this.adminDropdownService
          .getSupervisorSearch(this.editSName,this.resourceForm.controls.opco.value||this.sharedService.sharedDataSubject.value||1)
          .subscribe((response) => {
            this.filteredOptions = response.data;
          });
          for(let option of this.filteredOptions){
            if((option.fullName.trim()===this.editSName.trim())){
              temp['supervisorId'] =option.id
            }
            }       
           }
        // temp['supervisorId'] = this.filteredOptions[0].id;
        // console.log(this.resourceForm.controls.supervisorName.value)
      console.log(temp['supervisorId'])
      if (this.router.url.split('/')[2] === 'edit-employee') {
        temp.id = this.editData.id;
        // temp.terminationDate = termDate;
        this.adminDropdownService.saveResourceData(temp).subscribe((data) => {
          if (data.statusCode === 'SUCCESS') {
            const dialogConfig = new MatDialogConfig();
            dialogConfig.autoFocus = true;
            dialogConfig.data = {
              value: 'Resource details have been updated successfully',
              source: 'project-updated',
            };
            const dialogRef = this.dialog.open(
              NotificationDialogComponent,
              dialogConfig
            );
            this.router.navigateByUrl('employee-details');
          }
        });
      } {
        this.adminDropdownService.saveResourceData(temp).subscribe((data) => {
          if (data.statusCode === 'SUCCESS') {
            this.router.navigateByUrl('employee-details');
          }
        });
      }
    }
  }
  /**
   * in case of editing employee information
   */
  getEditData() {
   
    if (this.router.url.split('/')[2] === 'edit-employee') {
      if (sessionStorage.getItem('editData')) {
       
        this.editData = JSON.parse(sessionStorage.getItem('editData'));
        console.log(this.editData)
        this.editFName = this.editData.employeeName.split(',')[1];
        this.editLName = this.editData.employeeName.split(',')[0];
        this.editSName = this.editData.supervisor;
        this.editUserId = this.editData.username;
        this.editOpco = this.editData.opcoName;
        // this.editOpco = this.editData.opcoId;
        this.resourceForm.patchValue({
          fName: this.editData.employeeName.split(',')[1],
          lName: this.editData.employeeName.split(',')[0],
          checkBoxStatus: this.editData.active,
          hireDate: this.editData.hireDate,
          userId: this.editData.username,
          empId: this.editData.employeeId,
          supervisorName: this.editData.supervisor,
          terminationDate: this.editData.terminationDate,
          opco:this.userOpcoId,
          // opco: this.editData.opcoId,
          jobCode: this.editData.jobCode,
          resourceLocation: this.editData.resourceLocationId,
          access: this.editData.access

        });
        this.jobTitleData.forEach((x) => {
          if (x.designationName === this.editData.jobTitle) {
            this.resourceForm.patchValue({
              jobTitle: x.id,
            });
          }
        });
        this.opcoData.forEach((x) => {
          if (x.opcoName === this.editData.opco) {
            this.resourceForm.patchValue({
              opco: x.id,
            });
          }
        });
      }
    }
  }
}
