import { Validators, FormBuilder } from '@angular/forms';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AfterViewInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { ReportLogService } from '../services/report-log.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { NotificationDialogComponent } from '../notification-dialog/notification-dialog.component';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { IconDefinition, faArrowDown, faArrowUp, faArrowRight, faCircle, faSpinner } from '@fortawesome/free-solid-svg-icons';
import { SvgService } from '../services/svgImages.service';
import { Constants } from '../model/Constants';
import { SharedService } from '../services/shared.service';
import { Subscription } from 'rxjs';

export interface ReportLogData {
  index: number;
  position: string;
  imageUrl: string;
}

/**
 * intialised postion for diffrent report
 */

@Component({
  selector: 'app-report-log',
  templateUrl: './report-log.component.html',
  styleUrls: ['./report-log.component.scss'],
})
export class ReportLogComponent implements OnInit, AfterViewInit,OnDestroy {
  faSpinner: IconDefinition = faSpinner;
  ELEMENT_DATA: ReportLogData[] = [
    {
      index: 4,
      position: 'Engagement Data Export - Active',
      imageUrl: './assets/images/EngagementDataExport_Active.svg',
    },
    {
      index: 3,
      position: 'Engagement Data Export - All',
      imageUrl: './assets/images/EngagementDataExport_All.svg',
    },
    {
      index: 2,
      position: 'Milestone Agile Sprint Report - Active',
      imageUrl: './assets/images/MilestoneAgile_Active.svg',
    },
    {
      index: 1,
      position: 'Milestone Agile Sprint Report - All',
      imageUrl: './assets/images/MilestoneAgile_All.svg',
    },
    {
      index: 9,
      position: 'Milestone Delivery Report - Active',
      imageUrl: './assets/images/MilestoneDelivery_Active.svg',
    },

    {
      index: 8,
      position: 'Milestone Delivery Report - All',
      imageUrl: './assets/images/MilestoneDelivery_All.svg',
    },

    {
      index: 7,
      position: 'TGS IS Security Profile Report - Active',
      imageUrl: './assets/images/TGSISSecurity_Active.svg',
    },

    {
      index: 6,
      position: 'TGS IS Security Profile Report - All',
      imageUrl: './assets/images/TGSISSecurity_All.svg',
    },

    {
      index: 5,
      position: 'PMO Compliance Report',
      imageUrl: './assets/images/PMOCompliance.svg',
    },

    {
      index: 10,
      position: 'All Stakeholders Data',
      imageUrl: './assets/images/AllStakeholdersData.svg',
    },

    {
      index: 11,
      position: 'Trend Report - Active',
      imageUrl: './assets/images/Trend_Active.svg',
    },

  ];
  CLONED_ELEMENT_DATA;
  reports: ReportLogData[] = [];
  totalReports: number = 11;
  currentPage: number = 0;
  pageSize: number = 10;
  public showTotalPages = 1;
  currentSortTypeIndex: number = 0;// 0 - default ; 1 - asc ; 2 - desc
  faArrowUp: IconDefinition = faArrowUp;
  faArrowDown: IconDefinition = faArrowDown;
  faArrowRight: IconDefinition = faArrowRight;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  orderByAttribute: any;
  sortDirection: any;
  dialogConfig = new MatDialogConfig();
  maxlenth: number = 0;
  maxperpage: number = 100;
  statusReportForm = this.fb.group({
    weekStartingDate: [{ value: new Date() }, Validators.required],
    weekEndingDate: [{ value: new Date() }, Validators.required],
  });
  maxDate: Date;

  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    return (
      day !== 0 && day !== 1 && day !== 2 && day !== 3 && day !== 4 && day !== 5
    );
  }
  endingDate: any;
  pageSize1: number = 2;
  startingDate: any;
  finalSelectedDate: any;
  svgUrls: string[] = [
    './assets/images/EngagementDataExport_Active.svg', './assets/images/EngagementDataExport_All.svg', './assets/images/MilestoneAgile_Active.svg',
    './assets/images/MilestoneAgile_All.svg', './assets/images/MilestoneDelivery_Active.svg', './assets/images/MilestoneDelivery_All.svg',
    './assets/images/TGSISSecurity_Active.svg', './assets/images/TGSISSecurity_All.svg', './assets/images/PMOCompliance.svg',
    './assets/images/AllStakeholdersData.svg', './assets/images/Trend_Active.svg', './assets/images/Reports.svg'];
  // Add more SVG URLs as needed
  loading: boolean = true;
  svgs: string[] = [];
  selectedOpcoId: string;

  private sharedData:Subscription
  constructor(
    private fb: FormBuilder,
    private reportLogService: ReportLogService,
    public dialog: MatDialog,
    private svgService: SvgService,
    private sharedService: SharedService
  ) {
    // setting max weekending date as current week + 4 weeks.
    const date = new Date();
    this.maxDate = new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate() + 35
    );
    this.sharedData=this.sharedService.observer$.subscribe((data)=>{
      if(this.sharedData){
        this.selectedOpcoId=this.sharedService.sharedDataSubject.value
        localStorage.setItem('opcoId',''); 
        this.currentSortTypeIndex=0;
        this.displayFunction();
      }
    })

  }

  /**
   * for paginator page size
   * @returns
   */
  getPageSizeOptions(): number[] {
    if (this.maxlenth > this.maxperpage)
      return [10, 20, 50, this.maxperpage, this.maxlenth];
    else
      return [10, 20, 50, this.maxperpage];
  }

  ngAfterViewInit() {
    this.displayFunction();
  }
  displayFunction(){
    if (this.selectedOpcoId!='2') {
      this.totalReports = this.ELEMENT_DATA.length
      this.reports = this.ELEMENT_DATA.slice(
        this.currentPage * this.pageSize,
        this.currentPage * this.pageSize + this.pageSize
      );
    } else if (this.selectedOpcoId=='2') {
      this.totalReports = this.pageSize1;
      this.reports = this.ELEMENT_DATA.slice(
        this.currentPage * this.pageSize1,
        this.currentPage * this.pageSize1 + this.pageSize1
      );
    }
  }


  onPageChange(event) {
    if (this.selectedOpcoId!='2') {
      this.pageSize = event.pageSize;
      this.currentPage = event.pageIndex;
      if (this.currentSortTypeIndex == 0) {
        this.reports = this.ELEMENT_DATA.slice(this.currentPage * this.pageSize, (this.currentPage * this.pageSize) + this.pageSize);
      }
      else {
        this.reports = this.CLONED_ELEMENT_DATA.slice(this.currentPage * this.pageSize, (this.currentPage * this.pageSize) + this.pageSize);
      }
    }
  }

  current_date:Date;
  ngOnInit(): void {
    this.current_date=new Date();
    Constants.CURRENT_TAB='reports'
    if (Constants.OPCO_ID == 2) {
      this.showTotalPages = 1;
    }
    this.loadSvgImages();
    if((Constants.CURRENT_ROLE=='Executive'&&this.sharedService.sharedDataSubject.value==null)||(Constants.CURRENT_ROLE=='Admin'&&this.sharedService.sharedDataSubject.value==null)){
      this.selectedOpcoId='1'
    }
    else{
    this.selectedOpcoId = this.sharedService.sharedDataSubject.value||Constants.OPCO_ID;
    }
  }

  ngOnDestroy(): void {
    if(this.sharedData){
      this.sharedData.unsubscribe();
    }
  }
 
  /**
   * sort in asc or desc
   * @param value
   */
  sorting(property) {
    if (this.selectedOpcoId!='2') {
      this.currentSortTypeIndex++;
      if (this.currentSortTypeIndex == 3) {
        this.currentSortTypeIndex = 0;
      }
      if (this.currentSortTypeIndex == 0) {
        this.reports = this.ELEMENT_DATA.slice(this.currentPage * this.pageSize, (this.currentPage * this.pageSize) + this.pageSize);
      }
      else {
        let direction = this.currentSortTypeIndex == 1 ? 1 : -1
        this.CLONED_ELEMENT_DATA = [...this.ELEMENT_DATA];
        this.CLONED_ELEMENT_DATA.sort(function (a, b) {
          if (a[property] < b[property]) {
            return -1 * direction;
          }
          else if (a[property] > b[property]) {
            return 1 * direction;
          }
          else {
            return 0;
          }
        });
        this.reports = this.CLONED_ELEMENT_DATA.slice(this.currentPage * this.pageSize, (this.currentPage * this.pageSize) + this.pageSize);
      }

    }
  }
  /**
   * displaying notification window
   * @param value
   */
  triggerNotification(dialogConfig: any) {
    dialogConfig.autoFocus = true;
    const dialogRef = this.dialog.open(
      NotificationDialogComponent,
      dialogConfig
    );
  }
  /**
   * download the particular excel report
   * @param click on particular excel icon
   */
  onRowClick(event) {
    if (event.index === 1) {
      this.reportLogService
        .milestonesAgileSprintReportAll(false,this.selectedOpcoId)
        .subscribe((data) => {
          const blob = new Blob([data], {
            type:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          });
          if (window.navigator && window.navigator.msSaveBlob) {
            window.navigator.msSaveBlob(blob);
            return;
          }
          const sheetUrl = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = sheetUrl;
          link.download = 'Milestone Agile Sprint Report - All.xlsx';
          link.dispatchEvent(
            new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window,
            })
          );
          this.dialogConfig.data = {
            value: 'Milestone Agile Sprint Report - All is downloaded',
            source: 'project-updated',
          };
          this.triggerNotification(this.dialogConfig);
        });

    } else if (event.index === 2) {
      this.reportLogService
        .milestonesAgileSprintReportAll(true,this.selectedOpcoId)
        .subscribe((data) => {
          const blob = new Blob([data], {
            type:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          });
          if (window.navigator && window.navigator.msSaveBlob) {
            window.navigator.msSaveBlob(blob);
            return;
          }
          const sheetUrl = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = sheetUrl;
          link.download = 'Milestone Agile Sprint Report - Active.xlsx';
          link.dispatchEvent(
            new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window,
            })
          );
          this.dialogConfig.data = {
            value: 'Milestone Agile Sprint Report - Active is downloaded',
            source: 'project-updated',
          };
          this.triggerNotification(this.dialogConfig);
        });
    } else if (event.index === 3) {
      this.reportLogService.projectDataExportAll(false,this.selectedOpcoId).subscribe((data) => {
        const blob = new Blob([data], {
          type:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = 'Engagement Data Export - All.xlsx';
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
        this.dialogConfig.data = {
          value: 'Engagement Data Export - All is downloaded',
          source: 'project-updated',
        };
        this.triggerNotification(this.dialogConfig);
      });
    } else if (event.index === 4) {
      this.reportLogService.projectDataExportAll(true,this.selectedOpcoId).subscribe((data) => {
        const blob = new Blob([data], {
          type:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = 'Engagement Data Export - Active.xlsx';
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
        this.dialogConfig.data = {
          value: 'Engagement Data Export - Active is downloaded',
          source: 'project-updated',
        };
        this.triggerNotification(this.dialogConfig)
      });
    } else if (event.index === 5) {
      this.reportLogService.pmlcScorecardReport(this.selectedOpcoId).subscribe((data) => {
        const blob = new Blob([data], {
          type:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = 'PMO Compliance Report.xlsx';
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
        this.dialogConfig.data = {
          value: 'PMO Compliance Report is downloaded',
          source: 'project-updated',
        };
        this.triggerNotification(this.dialogConfig)
      });
    } else if (event.index === 6) {
      this.reportLogService
        .tgsISSecurityProfileReportAll(false,this.selectedOpcoId)
        .subscribe((data) => {
          const blob = new Blob([data], {
            type:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          });
          if (window.navigator && window.navigator.msSaveBlob) {
            window.navigator.msSaveBlob(blob);
            return;
          }
          const sheetUrl = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = sheetUrl;
          link.download = 'TGS IS Security Profile Report - All.xlsx';
          link.dispatchEvent(
            new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window,
            })
          );
          this.dialogConfig.data = {
            value: 'TGS IS Security Profile Report - All is downloaded',
            source: 'project-updated',
          };
          this.triggerNotification(this.dialogConfig)
        });
    } else if (event.index === 7) {
      this.reportLogService
        .tgsISSecurityProfileReportAll(true,this.selectedOpcoId)
        .subscribe((data) => {
          const blob = new Blob([data], {
            type:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          });
          if (window.navigator && window.navigator.msSaveBlob) {
            window.navigator.msSaveBlob(blob);
            return;
          }
          const sheetUrl = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = sheetUrl;
          link.download = 'TGS IS Security Profile Report - Active.xlsx';
          link.dispatchEvent(
            new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window,
            })
          );
          this.dialogConfig.data = {
            value: 'TGS IS Security Profile Report - Active is downloaded',
            source: 'project-updated',
          };
          this.triggerNotification(this.dialogConfig)
        });
    } else if (event.index === 8) {
      this.reportLogService
        .milestonesDeliveryReportAll(false,this.selectedOpcoId)
        .subscribe((data) => {
          const blob = new Blob([data], {
            type:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          });
          if (window.navigator && window.navigator.msSaveBlob) {
            window.navigator.msSaveBlob(blob);
            return;
          }
          const sheetUrl = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = sheetUrl;
          link.download = 'Milestone Delivery Report - All.xlsx';
          link.dispatchEvent(
            new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window,
            })
          );
          this.dialogConfig.data = {
            value: 'Milestone Delivery Report - All is downloaded',
            source: 'project-updated',
          };
          this.triggerNotification(this.dialogConfig)
        });
    } else if (event.index === 9) {
      this.reportLogService
        .milestonesDeliveryReportAll(true,this.selectedOpcoId)
        .subscribe((data) => {
          const blob = new Blob([data], {
            type:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          });
          if (window.navigator && window.navigator.msSaveBlob) {
            window.navigator.msSaveBlob(blob);
            return;
          }
          const sheetUrl = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = sheetUrl;
          link.download = 'Milestone Delivery Report - Active.xlsx';
          link.dispatchEvent(
            new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window,
            })
          );
          this.dialogConfig.data = {
            value: 'Milestone Delivery Report - Active is downloaded',
            source: 'project-updated',
          };
          this.triggerNotification(this.dialogConfig)
        });
    } else if (event.index === 10) {
      this.reportLogService.stakeHoldersDataExport(true,this.selectedOpcoId).subscribe((data) => {
        const blob = new Blob([data], {
          type:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = 'All Stakeholders Data - Active.xlsx';
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
        this.dialogConfig.data = {
          value: 'All Stakeholders Data - Active is downloaded',
          source: 'project-updated',
        };
        this.triggerNotification(this.dialogConfig)
      });
    } else if (event.index === 11) {
      const activeFlag = true;
      this.reportLogService.trendDataReport(activeFlag, this.startingDate, this.endingDate,this.selectedOpcoId).subscribe((data) => {
        const blob = new Blob([data], {
          type:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = 'Trend Report - Active.xlsx';
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
        this.dialogConfig.data = {
          value: 'Trend Report - Active is downloaded',
          source: 'project-updated',
        };
        this.triggerNotification(this.dialogConfig)
      });
    }

  }
  formatEndingDate() {
    let datePipe = new DatePipe('en-US');
    this.endingDate = datePipe.transform(this.endingDate, 'yyyy-MM-dd');
  }
  formatStartingDate() {
    let datePipe = new DatePipe('en-US');
    this.startingDate = datePipe.transform(this.startingDate, 'yyyy-MM-dd');
  }

  onPageEvent = ($event) => {
    console.log($event);
    // this.getProjectStatusDetails();
  }

  private loadSvgImages(): void {
    this.svgService.loadSvg(this.svgUrls).subscribe(
      (data: string[]) => {
        this.svgs = data;
        if (this.svgs) {
          this.loading = false;
        }
        else {
          this.loading = true;
        }
      },
      (error: any) => {
        console.error('Error loading SVG images:', error);
      }
    );
  }

}