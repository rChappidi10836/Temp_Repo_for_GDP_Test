import { Component, OnInit, Inject } from '@angular/core';
import { CreateProjectComponent } from '../create-project/create-project.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-project-dialog',
  templateUrl: './create-project-dialog.component.html',
  styleUrls: ['./create-project-dialog.component.scss']
})
export class CreateProjectDialogComponent implements OnInit {
  isNo = false;
  constructor(public dialogRef: MatDialogRef<CreateProjectComponent>) {
              }

  ngOnInit(): void {
  }
/**
 * on click of no
 */
  onClick(): void {
    this.dialogRef.close(this.isNo);
  }

  onClickOfYes(): void {
    this.isNo = true;
    this.dialogRef.close(this.isNo);
  }

}
