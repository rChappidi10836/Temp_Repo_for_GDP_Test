import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DashboardComponent } from '../dashboard/dashboard.component';

@Component({
  selector: 'app-summarypopup',
  templateUrl: './summarypopup.component.html',
  styleUrls: ['./summarypopup.component.scss']
})
export class SummarypopupComponent implements OnInit {
  message;
  

  constructor(@Inject(MAT_DIALOG_DATA) public data,public dialogRef : MatDialogRef<DashboardComponent>) { 
    this.message = data.Summary;
    this.ngOnInit();
    
  }
  

  ngOnInit(): void {
    this.doMsgFormatting();
  }
 
  doMsgFormatting(){
    this.message = this.message.trim();
  }


  closeDialog() {
    this.dialogRef.close();
  }

}