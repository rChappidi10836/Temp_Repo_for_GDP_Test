import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { FormBuilder } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { UserSearch } from '../model/UserSearch';
import { MatTableDataSource } from '@angular/material/table';
import { CreateProjectService } from '../services/create-project.service';
import { IconDefinition, faCheckCircle , faTimes} from '@fortawesome/free-solid-svg-icons';
import { SharedService } from '../services/shared.service';
import { Constants } from '../model/Constants';

@Component({
  selector: 'app-user-search-dialog',
  templateUrl: './user-search-dialog.component.html',
  styleUrls: ['./user-search-dialog.component.scss']
})
export class UserSearchDialogComponent implements OnInit {

  // icons
  faCheckCircle: IconDefinition = faCheckCircle;
  faTimes: IconDefinition = faTimes;

  userSearchForm = this.fb.group({
    firstName: [null],
    lastName: [null],
    userId: [null],
  });


  constructor(private fb: FormBuilder , public dialogRef: MatDialogRef<UserSearchDialogComponent>
            , private createProjectService: CreateProjectService, private sharedService: SharedService
            ) { }

  data = [];
  public totalPages;
  public currentPage = 0;
  public postPerPage = 5;
  public pageSizeOptions = [5, 10, 50, 100];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  displayedColumns: string[] = [
    'fullName',
    'userId',
    'firstName',
    'lastName',
    // 'actions',
  ];

  datasource = new MatTableDataSource<UserSearch>();

  errorMessage = '';
  tableHasData = false;
  isSelected = false;
  indOpcoId : any;
  opco = Constants.OPCO_ID;
  currentrole = Constants.CURRENT_ROLE;
  // row: UserSearch;

  ngOnInit(): void {
  
  }

  getRecord(row) {
    this.isSelected = true;
    this.close(row);
  }

  close(row) {
      this.dialogRef.close(row);
  }
/**
 * search for adding stakeholders in engagement details screen
 */
search() {
  this.indOpcoId =this.sharedService.shareOpcoIdfromcpc.value
  console.log(this.indOpcoId)
  this.createProjectService.
    userSearch(this.userSearchForm.value ,this.indOpcoId, this.currentPage, this.postPerPage).subscribe(
      (data) => {
        this.data = data.data[0].userSearchDtoList;
        this.totalPages = data.data[0].totalNumberOfElements;
        // sort
        this.data = this.data.sort((a, b) => {
          if (a.fullName < b.fullName) { return -1; }
          if (a.fullName > b.fullName) { return 1; }
      });
        this.datasource = new MatTableDataSource<UserSearch>(this.data);
        this.datasource.sort = this.sort;
        if (this.datasource.data.length > 0) {
          this.tableHasData = true;
          } else {
            this.tableHasData = false;
          }
      } , (error) => {
        this.tableHasData = false;
        this.errorMessage = error.error.message;
      }
    );
  }
/**
 * on moving to next page
 * @param pageData
 */
  onChangedPage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex;
    this.postPerPage = pageData.pageSize;
    this.search();
  }



}
