import { Component, OnInit, ViewChild} from '@angular/core';
  import { AdminDropdownService } from '../services/admin-dropdown.service';
  import {  MatPaginator } from '@angular/material/paginator';
  import {  ReplaySubject, Subject } from 'rxjs';
  import { FormControl } from '@angular/forms';
  import {  takeUntil,take } from 'rxjs/operators';
  import { MatSelect } from '@angular/material/select';
  import { MatSort } from '@angular/material/sort';
  import { MatSlideToggleModule } from '@angular/material/slide-toggle';
  import { MatDialog } from '@angular/material/dialog';
  import { Filter } from '../model/Filter';
  import { SearchProject } from '../model/SearchProject';
  import { PopUpComponent } from '../pop-up/pop-up.component';

@Component({
  selector: 'app-engagement-soft-delete',
  templateUrl: './engagement-soft-delete.component.html',
  styleUrls: ['./engagement-soft-delete.component.scss']
})
export class EngagementSoftDeleteComponent implements OnInit{
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatSlideToggleModule, { static: true })
  slideToggle: MatSlideToggleModule;

  selectedGdpIds = [-1];
  disableAllGDP = false;
  msg;


  constructor(
    private adminDropdownService: AdminDropdownService,
    public dialog: MatDialog,

  ) { }
  openDialog(data:String){
    this.dialog.open(PopUpComponent,{
      data :{
        msg:data
      }
    });

  }



  /** control for the selected option */
  public gdpIdsCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword */
  public gdpIdsFilterCtrl: FormControl = new FormControl();


  /** list of projects filtered by search keyword */
  public filteredGdpIds: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  /**Tooltip function */
  getGDPToolTip(){

    return this.gdpIdsFilterOptions?.filter((e)=>this.selectedGdpIds.indexOf(e.id)>-1).map((e)=>e.name).join(', ');
  }


  // filter options
   gdpIdsFilterOptions: Filter[];

  // on search click
  filterValues: SearchProject;

  ngOnDestroy() {
    this.onDestroy.next();
    this.onDestroy.complete();
  }

  OnselectOfGdpIds(event) {
    let array = event.value;

    if((array.indexOf(-1)>-1 && this.disableAllGDP &&this.gdpIdsFilterCtrl.value.length===0) || array.length===0){
      // select -1 and remove other selections
      this.selectedGdpIds = [-1];
      this.gdpIdsCtrl.setValue(this.selectedGdpIds);
      this.disableAllGDP = true;
            return;
    }
    if(array.length>1 && array.indexOf(-1)>-1){
      //remove -1 from list if anything else is selected
      array = array.filter(function(item) {
          return item !== -1
      });
   }

    this.disableAllGDP = false;
    this.selectedGdpIds = array;
    this.gdpIdsCtrl.setValue(array);
  }
  ngAfterViewInit() {

    this.setInitialValueGdpIds();
  }

/**
 * clear the search results
 */
  onClear() {
    console.log("cleared");

    this.disableAllGDP = false;
    this.filterValues.projectIds=[-1];
    this.getAllProjectFilterValues(this.filterValues);
    this.getGdpIdData();
    this.ngAfterViewInit();


  }

  getGdpIdsFilterOptionsValue() {
    // tslint:disable-next-line: quotemark
    const defaultGdpIds = { name: "All GDP ID's", id: -1 };
    this.gdpIdsFilterOptions.unshift(defaultGdpIds);
    this.gdpIdsCtrl.setValue([this.gdpIdsFilterOptions[0].id]);
    this.filteredGdpIds.next(this.gdpIdsFilterOptions);
    this.gdpIdsFilterCtrl.valueChanges
  .pipe(takeUntil(this.onDestroy))
  .subscribe(() => {
    this.filterGdpIds();

  });

  }
  // For GdpId
  /**
   * Sets the initial value after the filteredProjects are loaded initially
   * */

   protected setInitialValueGdpIds() {

    console.log("filtered GDP Ids "+this.filteredGdpIds);
    this.filteredGdpIds
      .pipe(take(1), takeUntil(this.onDestroy))
      .subscribe(() => {
        if (this.singleSelect) {
          this.singleSelect.compareWith = (a: Filter, b: Filter) =>
            a && b && a.id === b.id;
        }
      });

  }

  protected filterGdpIds() {
    if (!this.gdpIdsFilterOptions) {
      return;
    }
    let search = this.gdpIdsFilterCtrl.value;
    if (!search) {
      this.filteredGdpIds.next(this.gdpIdsFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredGdpIds.next(
      this.gdpIdsFilterOptions.filter((gdpIdsFilterOption) =>
        gdpIdsFilterOption.name.includes(search)
      )
    );
  }

  getAllProjectFilterValues(filters: SearchProject) {

    this.adminDropdownService.getGdpId().subscribe((data) => {
      this.gdpIdsFilterOptions = data.data[0]['gdpIdList'].map((eachProject) => {
        return { id: eachProject.id, name: eachProject.name };

      });

      this.getGdpIdsFilterOptionsValue();
      if(this.selectedGdpIds!==[-1] && this.selectedGdpIds!==undefined)
      this.gdpIdsCtrl.setValue(this.selectedGdpIds);
    });
  }



  ngOnInit(): void {
    console.log("ngOnInit");
    this.filterValues =   new SearchProject();
    this.getAllProjectFilterValues(this.filterValues);

  }

    /** Subject that emits when the component has been destroyed. */
    protected onDestroy = new Subject<void>();

  getGdpIdData(){
    this.adminDropdownService.getGdpId().subscribe((data) =>{

      this.gdpIdsFilterOptions = data.data[0]['gdpIdList'].map((eachProject) => {
        return { id: eachProject.id, name: eachProject.name };
      });


      this.getGdpIdsFilterOptionsValue();
    });

  }
  onSoftDelete(){
    this.filterValues.projectIds =
      this.selectedGdpIds === undefined? [-1]: this.selectedGdpIds;
      this.getAllProjectFilterValues(this.filterValues);
      this.adminDropdownService.getSoftDelete(this.selectedGdpIds).subscribe((data)=>{
      this.onClear();
      this.openDialog(data.data);

    })

  }


}
