import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EngagementSoftDeleteComponent } from './engagement-soft-delete.component';

describe('EngagementSoftDeleteComponent', () => {
  let component: EngagementSoftDeleteComponent;
  let fixture: ComponentFixture<EngagementSoftDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EngagementSoftDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EngagementSoftDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
