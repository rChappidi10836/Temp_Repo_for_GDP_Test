export class SearchProject {
  active: number;
  clientId: number[];
  deliveryOrganizationTypeId: number[];
  cslId: number[];
  projectId: number;
  projectIds: number[];
  orderByAttribute: string;
  sortDirection: string;
  gdmId: number[];
  programManagerId: number[];
  businessUnitId: number[];
 lodId:number[];
  psId: number;
  gddId: number[];
  gdm: string;
  dmId: number[];
  ttpId:any[];
}
