export class Constants {
  public static GLOBAL_DELIVERY_MANAGER = 'Global Delivery Manager';
  public static PROGRAM_MANAGER = 'Program Manager';
  public static NATIONAL_ACCOUNT_OWNER = 'National Account Owner';
  public static ENGAGEMENT_MANAGER = 'Engagement Manager';
  public static OSG_POA = 'OSG POA';
  public static SOLUTION_ENGINEER = 'Solution Engineer';
  public static OSG_BOA = 'OSG BOA';
  public static BDM = 'BDM / AM / SAM';
  public static TEAM_MEMBER_NAME = 'Name';
  public static GLOBAL_DELIVERY_DIRECTOR = 'Global Delivery Director';
  public static OPCO_ID = null;
  public static CURRENT_ROLE = '';
  public static CURRENT_TAB='';

  //Comparing Variables
  public static PROJECT_NAME_ERROR_MSG = 'Project name already present';
  public static CLIENT_OPCO_ERROR_MSG = 'Client is not in selected Opco'
  // Error msg
  public static PROJECT_NAME_EXISTS = 'Engagement name already present';
  public static CLIENT_OPCO_MISMATCH = 'Client is not in selected Opco';
  public static DUPLICATE_WEEKENDINGDATE_EXISTS =
    // tslint:disable-next-line: max-line-length
    'Report has been created already for the selected date. If you want to update the content for this particular week. Please edit from the Status history.';
  public static DELETE_NOTIFICATION = 'Are You Sure you want to DELETE ?';
  public static UPDATED_SUCCESS_MESSAGE =
    'Report has been updated successfully!!';
  public static SECURITY_PROFILE_ERROR_NOT_COMPLETED =
    // tslint:disable-next-line: max-line-length
    'The completion of the Security Profile is required for all engagements. Please Navigate to the Security Profile page and answer all questions.';
  public static SECURITY_PROFILE_ERROR_PASS_DUE =
    // tslint:disable-next-line: max-line-length
    'It has been over 90 days since the Security Profile has been reviewed and validated. If there are no changes to the Security Profile information, please click on “No Updates Needed” for confirmation. If changes are necessary, Please navigate to the Security Profile to make your updates.';
  public static DELIVERY_RISK_INDICATOR_ERROR_NOT_COMPLETED =
    'The completion of the Risk Survey is required for all engagements. Please Navigate to the Risk Survey page and answer all questions.';
  // Risk Criteria
  public static IS_WARRANTY_APPLICABLE =
    'Do warranty conditions established in the contract or MSA apply to this product or service?';
  public static LIABILITY_LIMITS =
    'What are the liability limits established by all related contracts and MSAs?';
  public static CONTRACT_TYPE = 'What is the contract type (financial)?';
  public static CUSTOMER_CREDIT_SCORE = 'What is the customer’s credit score?';
  public static SENSITIVE_DATA =
    'Does the solution require access to and/or handling of sensitive data (PII, PHI, confidential customer information)?';
  public static IS_COMPLIANCE_ASSOCIATED =
    'Are there regulatory compliance requirements associated with the product or service provided?';
  public static HARDWARE_AND_EQUIPMENT =
    'Who will supply the hardware and equipment required for solution implementation/service operations?';
  public static IS_COVERED =
    'Must the product or service be covered by an operational Business Continuity/Disaster Recovery redundancy solution?';
  public static WHAT_LOCATION = 'What location are services provided from?';
  public static PROVIDED_TO_CUSTOMER =
    'What type of product or service is being provided to the customer?';
  public static CONTRACTUAL_DURATION =
    'What is the contractual duration for the services provided?';
  public static IS_ESTABLISHED_ACCOUNT =
    'Is this an established key account for TEKsystems Global Services?';
  public static TOTAL_PROJECTED_REVENUE =
    'What is the total projected revenue for this engagement?';
  public static ENGAGEMENT_WITH_TEK =
    'How long has TEKsystems Global Services been engaged with this account?';
  public static IS_3RD_PARTY_DEPENDENT =
    'Is solution delivery dependent on a 3rd party company?';
  public static HAS_UNIQUE_CHALLENGES =
    'Does the delivery location, model, or practice engagement present unique challenges?';
  public static HIGH_RISK_INDICATOR =
    'Is there additional risk criteria, not addressed above, which you believe forces this engagement into the High Risk Category?';
  public static SECURITY_EXCEL_DOWNLOAD_POPUP=
    'You have unanswered question(s) in this Security Profile tab. If you want to proceed to download excel report of this project, please fill all questions before generating excel';

  // dashboard
  public static ALL_EM = 'All EM / DL / PC Names';
  public static ALL_GDM = 'All GDM Names';
  public static ALL_PrgM = 'All PrgM Names';
  public static ALL_GDD = 'All GDD Names';
  public static ALL_BU = 'All Business Units';
  public static FLEXIT_NORTHAMERICA = 'Flexible Capacity';
}
