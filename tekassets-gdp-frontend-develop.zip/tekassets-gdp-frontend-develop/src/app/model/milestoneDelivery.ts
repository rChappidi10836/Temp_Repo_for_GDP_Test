export interface MilestoneDelivery {
  description: string;
  type: string;
  startDate: Date;
  endDate: Date;
  status: string;
  comments: string;
  lastUpdatedAt: string;
  lastUpdatedBy: string;
  id: any;
}
