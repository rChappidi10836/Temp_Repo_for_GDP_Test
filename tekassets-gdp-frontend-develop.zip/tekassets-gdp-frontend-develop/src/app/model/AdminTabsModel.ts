export interface AdminDropdownModel {
  name: string;
  action: any;
}
export interface RequestedTabModel {
  id: any;
  name: string;
  active: any;
  
}

export interface ClientModel {
  id: any;
  name: string;
  active: any;
  opcoId:any;
}

export interface ManageAccessModel {
  id: any;
  employeeId: any;
  employeeName: string;
  username: string;
  jobCode: string;
  jobTitle: string;
  location: string;
  supervisor: string;
  hireDate: any;
  terminationDate: any;
  access: any;
  opcoName: String;
}
