export interface ReportLog {
    lastUpdatedBy: string ;
    dateAndTime: string;
}
