export interface OpportunityDetails {
    opportunityName: string;
    accountName: string;
    opportunityId: string;
    startDate: string;
    closedDate: string;
    gsOpportunity: string;
    primaryService: string;
    deliveryModel: string;
    practice: string;
}
