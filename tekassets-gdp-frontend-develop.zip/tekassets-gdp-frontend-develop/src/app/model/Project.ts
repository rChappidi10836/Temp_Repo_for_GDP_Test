export interface Project {
    projectName: number ;
    accountName: string;
    gdm: string;
    csl: string;
    statusDate: string;
    status: string;
    statusSummary: string;
}
