export interface AgileSprint {
  track: string;
  sprint: string;
  startDate: string;
  endDate: string;
  deliveredStories: string;
  committedStoryPoints: string;
  deliveredStoryPoints: string;
  addedStories: string;
  removedStories: string;
  capacity: string;
  estimate: string;
  sprintStatus: string;
  lastUpdatedBy: string;
  lastUpdatedAt: string;
  agileSprintActions: string;
  id: any;
  goalMet: string;
}
