export class ProjectClientName {
    projectName: string ;
    accountName: string ;
}
