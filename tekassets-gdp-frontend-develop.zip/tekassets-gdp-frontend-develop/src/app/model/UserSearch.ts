export class UserSearch {
    resourceId: number;
    resourceRoleId: number;
    fullName: string ;
    firstName: string;
    lastName: string;
    userId: string;
}
