export interface StatusReport {
  weekEndingDate: string;
  overAllStatus: string;
  statusSummary: string;
}
