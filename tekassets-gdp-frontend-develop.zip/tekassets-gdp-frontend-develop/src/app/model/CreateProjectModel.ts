export interface CreateProjectModel {
    projectName: string ;
    startDate: Date ;
    accountName: string ;
    endDate: Date ;
    peopleSoftEngagementId: string ;
    selectedSalesOrganizationId: number ;
    peopleSoftId: string ;
    selectedStaffingSaleRegionId: number ;
    opportunityId: string ;
    selectedBusinessId: number ;
    gdpId: string ;
    linkToSMPSite: string ;
    globalDeliveryManager: string ;
    nationalAccountOwner: string ;
    customerSuccessLead: string ;
    osgPoa: string ;
    solutionEngineer: string ;
    osgBoa: string ;
    bdm: string ;
    selectedPracticeEngagementId: number ;
    selectedLocationOfServicesId: number ;
    selectedDeliveryModelId: number ;
    selectedContractTypeId: number ;
    selectedPrimaryServiceTypeId: number[] ;

    otherTeamMembers: TeamMembers[] ;
}

export class TeamMembers {
    name: string ;
    role: string ;
}
