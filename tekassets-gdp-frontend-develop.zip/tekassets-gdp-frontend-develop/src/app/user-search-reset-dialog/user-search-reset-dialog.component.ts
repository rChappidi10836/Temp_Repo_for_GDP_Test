import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-user-search-reset-dialog',
  templateUrl: './user-search-reset-dialog.component.html',
  styleUrls: ['./user-search-reset-dialog.component.scss']
})
export class UserSearchResetDialogComponent implements OnInit {
  notificationMessage: string;
  resetValueOf: string;
  clearValue = false;

  constructor(private dialogRef: MatDialogRef<UserSearchResetDialogComponent>,
              @Inject(MAT_DIALOG_DATA) data) {
                this.resetValueOf = data.fieldName;
               }

  ngOnInit(): void {
      this.notificationMessage = 'Are you sure you want to remove';
  }

  onClickOfYes() {
    this.clearValue = true;
    this.dialogRef.close(this.clearValue);
  }

  onClickOfNo() {
    this.clearValue = false;
    this.dialogRef.close(this.clearValue);
  }
}
