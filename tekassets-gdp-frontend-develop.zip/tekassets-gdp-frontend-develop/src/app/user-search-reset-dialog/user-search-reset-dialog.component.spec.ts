import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSearchResetDialogComponent } from './user-search-reset-dialog.component';

describe('UserSearchResetDialogComponent', () => {
  let component: UserSearchResetDialogComponent;
  let fixture: ComponentFixture<UserSearchResetDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserSearchResetDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSearchResetDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
