import { TestBed } from '@angular/core/testing';

import { RiskSurveyService } from './services/risk-survey.service';

describe('RiskSurveyService', () => {
  let service: RiskSurveyService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RiskSurveyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
