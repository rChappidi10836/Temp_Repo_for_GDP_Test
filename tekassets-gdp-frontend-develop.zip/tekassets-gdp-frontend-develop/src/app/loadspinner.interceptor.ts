import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { SpinnerService } from 'src/app/services/spinner.service';
import { finalize } from 'rxjs/operators';
import { apiUri } from 'src/environments/environment';

@Injectable()
export class LoadspinnerInterceptor implements HttpInterceptor {

  constructor(private _loadingService: SpinnerService) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // if (request.url.match(`${apiUri}roles/my-role`)) {
    //   return next.handle(request).pipe(
    //     finalize(() => this._loadingService.hideSpinner())
    //   );
    // }
    this._loadingService.showSpinner();
    return next.handle(request).pipe(
      finalize(() => this._loadingService.hideSpinner())
    );
  }
}
