import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { faTimes, IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { ManageAccessService } from '../services/manage-access.service';
import { AdminDropdownService } from '../services/admin-dropdown.service';

@Component({
  selector: 'app-manage-access-user',
  templateUrl: './manage-access-user.component.html',
  styleUrls: ['./manage-access-user.component.scss'],
})
export class ManageAccessUserComponent implements OnInit {
  searchGDP: boolean=false;
  disableRevoke: boolean;
  constructor(
    public dialogRef: MatDialogRef<ManageAccessUserComponent>,
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private manageAccessService: ManageAccessService,
    private adminService:AdminDropdownService
  ) { }
  faTimes: IconDefinition = faTimes;
  roleGrant = this.fb.group({
    employeeName: [{ value: null, disabled: true }],
    employeeId: [{ value: null, disabled: true }],
  });
  roles: string[] = ['Admin', 'Global Edit Access', 'Global View Access', 'Executive', 'Revoke Access'];

  selectedRoles: string;
  username:string
  /**
   * opening dialog with diffrent roles
   */
  ngOnInit(): void {
    this.roleGrant.controls['employeeName'].setValue(
      this.data.data.employeeName
    );
    this.roleGrant.controls['employeeId'].setValue(this.data.data.employeeId);
    this.selectedRoles = this.data.data.access;
    this.username=this.data.data.username
    this.adminService.searchGDPUser(this.username,this.data.data.id).subscribe((data)=>{
      console.log(data.successMessage.trim()==="User Found".trim())
      if(data.successMessage.trim()=="User Found".trim()){
        this.searchGDP=true;
      }else{
        this.searchGDP=false;
      }
    })
  }
  /**
   * closing the dialog
   */
  close(row) {
    this.dialogRef.close(row);
  }
  /**
   * saving changes to roles
   */
  onSubmit() {
    const data = {
      access: this.selectedRoles,
      resourceId: this.data.data.id,
    };
    this.manageAccessService.userRoleService(data).subscribe((res) => {
      this.close(0);
    });
  }
}
