import { AfterViewInit, Component, OnInit, TemplateRef } from '@angular/core';

import {
  IconDefinition,
  faPen,
  faCircle,
} from '@fortawesome/free-solid-svg-icons';

import { ActivatedRoute, Router } from '@angular/router';
import { SecurityProfileService } from '../services/security-profile.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CreateProjectDialogComponent } from '../create-project-dialog/create-project-dialog.component';
import { MatTableDataSource } from '@angular/material/table';
import { ReportLog } from '../model/ReportLog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { ViewChild } from '@angular/core';
import { AuthGuardService } from '../services/auth_guard.service';
import { AccessLevel } from '../enums/access_level';
import { Constants } from '../model/Constants';
import { HttpErrorResponse } from '@angular/common/http';
import { SecurityExcelDialogComponent } from '../security-excel-dialog/security-excel-dialog.component';
@Component({
  selector: 'app-security-profile',
  templateUrl: './security-profile.component.html',
  styleUrls: ['./security-profile.component.scss'],
})
export class SecurityProfileComponent implements OnInit {
  newsecurityProfileForm = [];
  valueCheckBoolean = {};
  valueCheck: boolean;
  commentCheck: any;
  errorMessage: string;
  hasError: boolean;

  @ViewChild('errorDialogTemplate') errorDialogTemplate!: TemplateRef<any>;

  constructor(
    private fb: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private securityProfileService: SecurityProfileService,
    public matDialog: MatDialog,
    private authService: AuthGuardService
  ) {
    this.securityProfileForm = this.fb.group({
      securityProfileFormArray: this.fb.array([]),
    });
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;
  faPen: IconDefinition = faPen;
  id: number;
  projectId = '';
  projectName = '';
  accountName = '';
  isAnswerListPresent = false;
  globalDeliveryManager = '';
  customerSuccessLeader = '';
  deliveryRiskIndicator = '';
  securityProfileStatus = '';
  showOnSave = false;
  questions = [];
  reportLogdata = [];
  allOptionsList = [];
  allCommentsList = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}];
  commentListHasData = false;
  resultList = [];
  cloneOfResultList = [];
  selectedAnswerIdsFromDb = [];
  data: Array<any> = [];
  securityProfileProjectData: Array<any> = [];
  allAnswersList = [];
  datasource = new MatTableDataSource<any>();
  reportLogErrorMessage = '';
  opportunityData = null;
  buttonText = 'Save';
  disable = true;
  manadatory = false;
  isHover = false;
  mandComment = '';
  headerData = [];
  isTableEditable = false;
  showLabel = false;
  routedData: any;
  questionIndex: number;
  question: string;
  globalRequestSource: string;
  securityProfileForm: FormGroup;
  securityProfileFormArray: FormArray;
  backup: any;
  lastUpdatedBy = '';
  lastUpdatedAt = '';
  showAsterisk = false;
  questionPosition = 6;
  ansLength: any;
  selectedValue: any;
  optsecurityAns: any;
  valueYes;
  valueNo;
  tableHasData = true; // make it false later
  displayedColumns: string[] = ['lastUpdatedBy', 'dateAndTime', 'summary'];
  hasEditAccess = false;
  current_username = 'GDPuser';
  unAnswerdList = [];
  isAnySelectInvalid: boolean;



  async ngOnInit(): Promise<void> {
    this.activatedRoute.params.subscribe(async (params) => {
      this.id = params.projectId;
      this.getLastUpdatedBy(this.id);


      this.current_username = (await this.authService.getUserMail()).split("@")[0];

      if (this.id !== null && this.id && this.id !== undefined) {
        this.getHeaderUserData(this.id);
        this.getSecurityProfileForAllProjects();
        this.showOnSave = true;
        this.getReportLog(this.id);
      }
    });
    this.hasEditAccess = await this.authService.doesUserHaveAccessToRole(
      AccessLevel.EDIT_ACCESS
    );
  }

  get getSecurityProfileFormArray(): FormArray {
    return this.securityProfileForm.get(
      'securityProfileFormArray'
    ) as FormArray;
  }

  initGroup() {
    const rows = this.securityProfileForm.get(
      'securityProfileFormArray'
    ) as FormArray;
    rows.push(
      this.fb.group({
        index: [''],
        question: [''],
        status: [],
        comments: [''],
        isMultiSelect: [''],
      })
    );
  }

  // write service to get data regarding project
  /**
   * fetch & set the header information of project
   * @param id
   */
  getHeaderUserData(id) {
    this.securityProfileService.getHeaderUserData(id).subscribe((data) => {
      this.projectName = data.data[0].projectName;
      this.accountName = data.data[0].accountName;
      this.customerSuccessLeader = data.data[0].customerSuccessLeader;
      this.deliveryRiskIndicator = data.data[0].deliveryRiskIndicator;
      if (this.deliveryRiskIndicator === null) {
        this.deliveryRiskIndicator = 'Not Completed';
      }
      this.globalDeliveryManager = data.data[0].globalDeliveryManager;
      this.securityProfileStatus = data.data[0].securityProfileStatus;
    });
      }
  /**
   * get answer (status) for projects
   * @param sortedDataFromApi
   * @returns answer(status) for questions
   */
  getResultList(sortedDataFromApi) {
    const resultList: Array<any> = [];
    let securityAnswerListForEachObject: Array<any> = [];
    sortedDataFromApi.forEach((object) => {
      securityAnswerListForEachObject = [...object.securityAnswers];
      const resultListItem = securityAnswerListForEachObject.map((item) => {
        return {
          securityAnswerId: item.securityAnswerId,
          selected: false,
          comments: null,
        };
      });
      resultList.push(...resultListItem);
    });
    return resultList;
  }
  /**
   * populating questions and answers(status & comments)
   */
  getSecurityProfileForAllProjects() {
    this.securityProfileService
      .getSecurityProfileAllAnswers()
      .subscribe((data) => {
        this.data = data.data;
        this.questions = this.data; // used in report log
        this.data = this.data.sort((a, b) =>
          a.position > b.position ? 1 : -1
        );
        this.allOptionsList = this.data.map((project) => {
          return {
            options: [...project.securityAnswers], // send list in securityAnswers into options
          };
        });
        this.isAnswerListPresent = true;
        this.resultList = this.getResultList(this.data);
        let index = 0;
        const formArrayControl = this.securityProfileForm.controls
          .securityProfileFormArray['controls'];
        this.data.forEach((item) => {
          const isMultiSelect = item.multiselect;
          const position = item.position;
          const question = item.securityQuestion;
          const comments = item.comments;
          this.allAnswersList = item.securityAnswers;
          const addRowObject = {
            objectPosition: position,
            objectQuestion: question,
            objectComments: comments,
            objectisMultiselect: isMultiSelect,
            objectAllAnswersList: this.allAnswersList,
          };
          if (
            item.position === 7 &&
            item.securityAnswers[0].securityAnswer === 'Yes'
          ) {
            this.valueYes = item.securityAnswers[0].securityAnswerId;
            this.valueNo = item.securityAnswers[1].securityAnswerId;
          }
          this.initGroup();
          this.patchValues(index, addRowObject);
          formArrayControl[index].controls.index.disable();
          formArrayControl[index].controls.question.disable();
          ++index;
        });
        this.backup=this.securityProfileForm.value;
                this.securityProfileFormDisable();
        this.getSecurityProfileByProjectId();
      });
  }
  /**
   * for read only mode
   */
  securityProfileFormDisable() {
    this.securityProfileForm.disable();
  }

  patchValues(i, value) {
    const x = (this.securityProfileForm.controls[
      'securityProfileFormArray'
    ] as FormArray).at(i);

    x.patchValue({
      index: value.objectPosition,
      question: value.objectQuestion,
      status: value.objectAllAnswersList,
      comments: value.objectComments,
      isMultiSelect: value.objectisMultiselect,
    });
  }

  patchComments(i, comment) {
    const x = (this.securityProfileForm.controls[
      'securityProfileFormArray'
    ] as FormArray).at(i);
    x.patchValue({
      comments: comment === null ? '' : comment,
    });
  }
  /**
   * mapping data (status & comments) according to project id from services
   */
  getSecurityProfileByProjectId() {
    this.securityProfileService
      .getSecurityProfile(Number(this.id))
      .subscribe((data) => {

        if (data !== null && data !== undefined && data.data.length > 0) {
          this.securityProfileProjectData = data.data;

          /**sorting the fetched data **/
          this.securityProfileProjectData = this.securityProfileProjectData.sort((a, b) =>
            a.position > b.position ? 1 : -1
          );

          /**checking and mapping missing answerIDs */
          if (this.securityProfileProjectData.length < this.questions.length) {

            /**finding missing postion and answer IDs */

            const Optionsset: number[] = this.securityProfileProjectData.map(item => item.position).sort();
            const mySet: number[] = this.questions.map(item => item.position).filter(position => !Optionsset.includes(position));

            /**listing answer IDs */
            for (let newpo of mySet) {
              this.unAnswerdList.push(...this.allOptionsList[newpo - 1].options.map(option => option.securityAnswerId));
            }

            /* Calling End Point to map the unmapped and fetching the updated data*/

            const requestbody = {
              unAnsweredlist: this.unAnswerdList,
              current_Username: this.current_username
            };

            this.securityProfileService
              .mapSecurityProfile(Number(this.id), requestbody).subscribe(() => { },
                (error) => { },
                () => { this.getSecurityProfileByProjectId(); });

          }
          if (
            this.securityProfileProjectData !== null &&
            this.securityProfileProjectData !== undefined
          ) {
            this.securityProfileProjectData = this.securityProfileProjectData.sort(
              (a, b) => (a.position > b.position ? 1 : -1)
            );
            this.allCommentsList = this.securityProfileProjectData.map(
              (project) => {
                return {
                  options: project.comments, // send list in securityAnswers into options
                };
              }
            );
            this.commentListHasData = true;
            this.setStatusAndCommentsInFormArray(
              this.securityProfileProjectData
            );
          }
        } else {
          this.onEdit();
        }
      },
        (error: HttpErrorResponse) => {
          if (error.status === 404) {
            console.error('Id not found: ', error.message);
            this.errorMessage = 'ID not found';
            this.hasError = true;
          } else {
            console.error('API Error:', error.message);
            this.errorDialogBox('ID NOT FOUND');
            this.hasError = true;
          }
        }
      );
  }

  errorDialogBox(message: string) {
    const dialogRef = this.dialog.open(this.errorDialogTemplate, {
      data: { message }, // Pass data to the template
      disableClose: true,
    });
  }
  closeDialogAndNavigate() {
    this.dialog.closeAll();
    this.router.navigate(['dashboard']);
  }


  setStatusAndCommentsInFormArray(securityProfileProjectData) {

    securityProfileProjectData = securityProfileProjectData.map((item) => {
      const filteredAnswers = item.securityAnswers.filter((answer) => answer.selected);
      return { ...item, securityAnswers: filteredAnswers };
    });
    
    let index = 0;
    const formArrayControl = this.securityProfileForm.controls
      .securityProfileFormArray['controls'];

    securityProfileProjectData.forEach((row) => {
      this.patchComments(index, row.comments);
      const x = (this.securityProfileForm.controls[
        'securityProfileFormArray'
      ] as FormArray).at(index);
      const isMultiselect = x.value.isMultiSelect;
      if (!isMultiselect) {
        // is single-select
        if (
          row.position === 7 &&
          row.securityAnswers[0].securityAnswerId === this.valueYes
        ) {
          this.selectedValue = this.valueYes;
          this.showAsterisk = false;
        } else
          if (
            row.position === 7 &&
            row.securityAnswers[0].securityAnswerId === this.valueNo
          ) {
            this.selectedValue = this.valueNo;
            this.showAsterisk = true;
          }
        formArrayControl[index].controls.status.setValue(
          row.securityAnswers[0].securityAnswerId
        );
      } else {
        // is multi-select
        const AnswerIds: Array<any> = [];
        const selectedAnswerList = row.securityAnswers;
        selectedAnswerList.forEach((answer) => {
          AnswerIds.push(answer.securityAnswerId);
        });
        formArrayControl[index].controls.status.setValue(AnswerIds);
      }
      index++;
    });
    this.checkingAnySelectInvalid();
    if(this.isAnySelectInvalid && this.disable){
      this.onUnFilledAnswers();
    }
    }

  formatFunction(secArray) {
    let secString = '';
    if (secArray.length === 1) {
      return secArray[0].securityAnswer;
    } else {
      secArray.forEach((x) => {
        secString += x.securityAnswer;
        secString += ',';
      });
      return secString;
    }
  }
  /**
   * logging the changes made in profile
   */
  onOpenOfReportLog() {
    this.getReportLog(this.id);
  }
  getLastUpdatedBy(id) {
    this.securityProfileService
      .getSecurityProfileReportLogById(id)
      .subscribe((data) => {
        this.lastUpdatedAt = data.data[0].dateAndTime;
        this.lastUpdatedBy = data.data[0].lastUpdatedBy;
      });
  }

  getReportLog(id) {
    this.securityProfileService
      .getSecurityProfileReportLogById(id)
      .subscribe((data) => {
        this.reportLogdata = data.data;
        this.reportLogdata.forEach((x) => {
          x.summary.forEach((sum) => {
            let flag = 1;
            this.questions.forEach((y) => {
              if (sum.updatedSecurityQuestion === y.securityQuestion) {
                sum['position'] = flag;
              }
              flag++;
            });
          });
        });
        this.datasource = new MatTableDataSource<ReportLog>(this.reportLogdata);
        if (this.datasource.data.length > 0) {
          this.tableHasData = true;
        } else {
          this.tableHasData = false;
          this.reportLogErrorMessage = 'No logs found!';
        }
      });
  }
  /**
   * forms enter into edit mode from read only
   */
  onEdit() {
    this.isTableEditable = !this.isTableEditable;
    this.showOnSave = false;
    this.disable = false;
    this.buttonText = 'Update';
    this.enableSecurityProfileForm();
    const formArrayControl = this.securityProfileForm.controls
      .securityProfileFormArray['controls'];
    
    Object.assign(this.valueCheckBoolean, this.securityProfileForm.value);
    
    this.securityProfileForm.valueChanges.subscribe((selectedValue) => {
      this.newsecurityProfileForm = selectedValue;
      this.commentCheck =
        formArrayControl[this.questionPosition].controls.comments.value;
      this.valuechange();
      return selectedValue;
    });
  }

  enableSecurityProfileForm() {
    this.securityProfileForm.enable();
    const formArrayControl = this.securityProfileForm.controls
      .securityProfileFormArray['controls'];
    let i = 0;
    while (i <= 9) {
      formArrayControl[i].controls.index.disable();
      formArrayControl[i].controls.question.disable();
      if (i === this.questionPosition) {
        formArrayControl[i].controls.comments.touched = true;
        this.showAsterisk = true;
        if (formArrayControl[i].controls.status.value === this.valueYes) {
          this.selectedValue = this.valueYes;
          this.showAsterisk = false;
        }
      }
      ++i;
    }
  }
  valuechange() {
    if (
      JSON.stringify(this.newsecurityProfileForm) ===
      JSON.stringify(this.valueCheckBoolean)
    ) {
      this.valueCheck = true;
    } else {
      this.valueCheck = false;
    }
    
  }

  checkingAnySelectInvalid(){
    this.isAnySelectInvalid =  this.securityProfileForm.value
    .securityProfileFormArray.some((control)=>{
      return  control.status.length == 0 ;
    });
  }

  onProjectDetails() {
    if (this.id !== null && this.id && this.id !== undefined) {
      this.router.navigate(['dashboard/project-details', this.id], {
        state: {
          source: 'project-details',
        },
      });
    }
  }

  // navigate to status report
  onStatusReport() {
    if (this.id !== null && this.id && this.id !== undefined) {
      this.router.navigate(['dashboard/status-report', this.id], {
        state: {
          source: 'project-details',
        },
      });
    }
  }

  // navigate to risksurvey
  onRiskSurvey() {
    if (this.id !== null && this.id && this.id !== undefined) {
      this.router.navigate(['dashboard/risk-survey', this.id], {
        state: {
          source: 'project-details',
        },
      });
    }
  }
  /**
   * dialog on click of cancel
   * @param tab
   */
  openModal(tab) {
    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = 'confirm-dialog-component';
    dialogConfig.height = '250px';
    dialogConfig.width = '600px';
    dialogConfig.data = {
      title:'Notification',
      description:
        'You have unsaved changes in this ' +
        'Security Profile' +
        ` tab. If you want to proceed to another tab without saving,
      Click "Proceed" (or) click "Cancel" to stay on the same tab.`,
    };
    const dialogRef = this.matDialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        if (tab === '1') {
          this.onProjectDetails();
        } else {
          if (tab === '2') {
            this.onStatusReport();
          } else {
            if (tab === '3') {
              this.onRiskSurvey();
            }
          }
        }
      }
    });
  }

  /**
   * guidance message to download excel
   */
  onUnFilledAnswers(){
    this.dialog.open(SecurityExcelDialogComponent, {
      data: { 
        msg: Constants.SECURITY_EXCEL_DOWNLOAD_POPUP
      } 
    });
  }
  
  /**
   * switching bewteen tabs
   * @param tab
   */
  onEditMode(tab) {
    if (
      this.showOnSave === false &&
      this.securityProfileForm.touched &&
      this.securityProfileForm.dirty &&
      !this.valueCheck
    ) {
      this.openModal(tab);
    } else {
      if (tab === '1') {
        this.onProjectDetails();
      } else {
        if (tab === '2') {
          this.onStatusReport();
        } else {
          if (tab === '3') {
            this.onRiskSurvey();
          }
        }
      }
    }
  }
  onCancel() {
    const dialogRef = this.dialog.open(CreateProjectDialogComponent);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        // this.securityProfileForm.disable();
        this.onReset();
        this.securityProfileFormDisable();
        this.showOnSave = true;
        this.getReportLog(this.id);
        this.disable=true
        this.checkingAnySelectInvalid();
      } else if (data === false) {
        // nothing to do
      }
    });
  }

  onReset() {
      if(this.securityProfileProjectData.length == 0){
                this.securityProfileForm.patchValue(this.backup);
        if(!this.showAsterisk){
        this.showAsterisk=true
        }
        this.securityProfileForm.markAsPristine();
        this.checkingAnySelectInvalid();
       }else{
        this.setStatusAndCommentsInFormArray(this.securityProfileProjectData);
       }
  }

  // for mandatory required class
  someMethod(value, sol) {
    if (value === 'Yes') {
      this.manadatory = true;
    } else {
      this.manadatory = false;
    }
  }

  findByAnswerIdInResultList(id) {
    for (const item of this.resultList) {
      if (item.securityAnswerId === id) {
        return item;
      }
    }
  }
  /**
   * saving changes in the form
   */
  saveUpdatedData() {
    const updatedAnswerList = this.securityProfileForm.value
      .securityProfileFormArray;
    let resultListObject: any;
    let multiSelectSelectedAnswerList: [];
    updatedAnswerList.forEach((answer) => {
      if (answer.isMultiSelect === false) {
        // is single-select
        resultListObject = this.findByAnswerIdInResultList(answer.status);
        resultListObject.selected = true;
        resultListObject.comments = answer.comments;
      } else {
        // is multi-select
        multiSelectSelectedAnswerList = answer.status;
        multiSelectSelectedAnswerList.forEach((selectedAnswerId) => {
          resultListObject = this.findByAnswerIdInResultList(selectedAnswerId);
          resultListObject.selected = true;
          resultListObject.comments = answer.comments;
        });
      }
    });
    const editRequestObject = {
      projectId: this.id,
      securityAnswersList: this.resultList,
    };
    this.securityProfileService
      .editSecurityProfile(editRequestObject)
      .subscribe((data) => {
        this.securityProfileStatus = 'Updated';
        this.securityProfileForm.markAsPristine();
        this.securityProfileForm.markAsUntouched();
        this.getLastUpdatedBy(this.id);
        this.securityProfileFormDisable();
        this.showOnSave = true;
        this.getReportLog(this.id);
        this.resetResultList();
      },
      (error)=>{},
      ()=>{this.getSecurityProfileByProjectId();});
      this.disable = true;
      this.checkingAnySelectInvalid();
  }

  resetResultList() {
    this.resultList.forEach((item) => {
      item.selected = false;
      item.comments = null;
    });
  }

  trimComment(str) {
    if (str.length > 45) {
      let newStr = str.slice(0, 45);
      newStr += '.....';
      return newStr;
    } else {
      return str;
    }
  }
  /** 
   * trigger excel report download
   */
  onExportToExcel() {
    if(this.isAnySelectInvalid || !this.disable || this.securityProfileProjectData.length==0){ // check either user is in edit mode or any question is unanswered
      this.onUnFilledAnswers();
    }
    else{
      // handle opportunity id requests
      const projectIdForExcel =
        this.id === null ||
          this.id === undefined ||
          this.globalRequestSource === 'opportunity'
          ? -1
          : this.id;
      this.securityProfileService
        .exportToExcelSecurityProfile(projectIdForExcel)
        .subscribe((data) => {
          const blob = new Blob([data], {
            type:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          });
          if (window.navigator && window.navigator.msSaveBlob) {
            window.navigator.msSaveBlob(blob);
            return;
          }
          const sheetUrl = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = sheetUrl;
          link.download = 'Security Profile.xlsx';
          link.dispatchEvent(
            new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window,
            })
          );
        });
    }
  }
  /**
   * displying as mandatory field if selected option is yes
   * @param event
   */
  onSelectOf7thQuestion(event) {
    if (event.value === this.valueYes) {
      this.showAsterisk = false;
      this.selectedValue = this.valueYes;
    } else if (event.value === this.valueNo) {
      this.showAsterisk = true;
      this.selectedValue = this.valueNo;
    }
  }
  /**
   * to display multiselect status in single row
   * @param data
   * @param index
   * @returns all multiselected status
   */
  showContent(data, index) {
    let str = '';
    this.checkingAnySelectInvalid();
    const values = this.securityProfileForm.controls.securityProfileFormArray
      .value[index].status;
    values.forEach((x) => {
      data.forEach((y) => {
        if (x === y.securityAnswerId && y.selected) {
          str = str + y.securityAnswer + ', ';
        }
      });
    });
    str = str.slice(0, -2);
      return str;
  }
  /**
   * checks if form is edited to enable the update or save button
   * @returns true or false
   */
  checkForm() {
    if (this.securityProfileStatus === 'Not Completed') {
      let flag = 0;
      this.getSecurityProfileFormArray.controls.forEach((x) => {
        if (x.get('status').pristine) {
          flag = 1;
        }
      });
      if (flag === 1) {
        return true;
      } else {
        return false;
      }
    } else {
      if (this.securityProfileForm.dirty) {
        return false;
      } else {
        return true;
      }
    }
  }


}
