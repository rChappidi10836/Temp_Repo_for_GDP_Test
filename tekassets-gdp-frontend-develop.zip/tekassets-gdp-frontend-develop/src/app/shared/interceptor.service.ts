import { Injectable } from '@angular/core';
import { LoaderService } from './loader.service';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { HttpRequest, HttpHandler, HttpEvent, HttpResponse, HTTP_INTERCEPTORS } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService {

  constructor(private loaderService: LoaderService, public snackBar: MatSnackBar) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let requestMethod: string = req.method;
    requestMethod = requestMethod.toLowerCase();

    this.showLoader();
    const method = req.method;
    const urlLastSegment = req.url.substr(req.url.lastIndexOf('/') + 1);
    const config = new MatSnackBarConfig();
    config.duration = 4000;
    config.verticalPosition = 'bottom';
    config.horizontalPosition = 'center';
    config.panelClass = 'center-text';
    return next.handle(req).pipe(tap((event: HttpEvent<any>) => {
      if (event instanceof HttpResponse) {
        this.onEnd();
        if (method === 'PUT') {
            this.snackBar.open('Data Edited Successfully', '', config);
        } else if (method === 'POST') {
          this.snackBar.open('Data Saved Successfully', '', config);
        } else if (method === 'DELETE') {
          this.snackBar.open('Data Deleted Successfully', '', config);
        }
      }
    },
      // Error handling in interceptor
      (err: any) => {
        this.onEnd();
        const errormessage = err.error;
        this.snackBar.open('Operation Failed', '', config);
      }));
  }


  private onEnd(): void {
    this.hideLoader();
  }

  private showLoader(): void {
    this.loaderService.show();
  }

  private hideLoader(): void {
    this.loaderService.hide();
  }
}
