import { Component, OnInit } from '@angular/core';
import { DemoService } from '../services/demo.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { Project } from '../model/Project';

@Component({
  selector: 'app-project-form',
  templateUrl: './project-form.component.html',
  styleUrls: ['./project-form.component.scss'],
})
export class ProjectFormComponent implements OnInit {
  projects: Observable<Project[]>;

  constructor(
    private demoService: DemoService,
    private activatedRoute: ActivatedRoute
  ) {}

  projectForm = new FormGroup({
    projectName: new FormControl(['']),
    clientName: new FormControl(['']),
    uniqueProjectId: new FormControl(['']),
  });

  id: number;

  ngOnInit() {
    this.id = this.activatedRoute.snapshot.params.projectId;
    if (this.id) {
      this.demoService.getProjectById(this.id).subscribe((data: any) => {
        this.projectForm.patchValue(data.data[0]);
      });
    }
  }

  onSubmit() {
    this.demoService.saveProject(this.projectForm.value).subscribe(
      (response) => console.log('saved successfully', response),
      (error) => console.log('error', error)
    );
  }

  updateProject() {
    this.demoService.updateProject(this.projectForm.value, this.id).subscribe(
      (data) => console.log(data),
      (error) => console.log(error)
    );
  }
}
