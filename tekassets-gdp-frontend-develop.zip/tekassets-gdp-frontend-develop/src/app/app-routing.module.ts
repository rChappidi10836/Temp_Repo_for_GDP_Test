import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DataTableComponent } from './data-table/data-table.component';
import { FormComponent } from './form/form.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProjectFormComponent } from './project-form/project-form.component';
import { OpportunitiesComponent } from './opportunities/opportunities.component';
import { CreateProjectComponent } from './create-project/create-project.component';
import { RiskSurveyComponent } from './risk-survey/risk-survey.component';
import { StatusReportComponent } from './status-report/status-report.component';
import { SecurityProfileComponent } from './security-profile/security-profile.component';
import { ManageAccessComponent } from './manage-access/manage-access.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { AdminComponentsComponent } from './admin-components/admin-components.component';
import { LoginComponent } from './login/login.component';
import { ReportLogComponent } from './report-log/report-log.component';
import { AuthGuardService as AuthGuard } from './services/auth_guard.service';
import { EngagementSoftDeleteComponent } from './engagement-soft-delete/engagement-soft-delete.component';
import { AdminOptionsComponent } from './admin-options/admin-options.component';
const routes: Routes = [
  {
    path: 'dashboard',
    data: { breadcrumb: 'Home' },
    canActivate: [AuthGuard],
    children: [
      { path: '', component: DashboardComponent, data: { breadcrumb: '' } },

      {
        path: 'project-details/:projectId',
        component: CreateProjectComponent,
        pathMatch: 'full',
        data: {
          breadcrumb: 'Engagement Details',
        },
      },

      {
        path: 'risk-survey/:projectId',
        component: RiskSurveyComponent,
        pathMatch: 'full',
        data: {
          breadcrumb: 'Risk Survey',
        },
      },
      {
        path: 'security-profile/:projectId',
        component: SecurityProfileComponent,
        pathMatch: 'full',
        data: {
          breadcrumb: 'Security Profile',
        },
      },
      {
        path: 'risk-survey',
        component: RiskSurveyComponent,
        pathMatch: 'full',
        data: {
          breadcrumb: 'Risk Survey',
        },
      },
      {
        path: 'security-profile',
        component: SecurityProfileComponent,
        pathMatch: 'full',
        data: {
          breadcrumb: 'Risk Survey',
        },
      },

      {
        path: 'status-report',
        component: StatusReportComponent,
        pathMatch: 'full',
        data: {
          breadcrumb: 'Status Report',
        },
      },

      {
        path: 'status-report/:projectId',
        component: StatusReportComponent,
        pathMatch: 'full',
        data: {
          breadcrumb: 'Status Report',
        },
      },

      {
        path: 'available-opportunities',
        data: { breadcrumb: 'Available Opportunities' },
        children: [
          {
            path: '',
            component: OpportunitiesComponent,
            data: { breadcrumb: '' },
          },

          {
            path: 'create-project-manually',
            data: { breadcrumb: 'Add New Engagement' },
            children: [
              {
                path: '',
                component: CreateProjectComponent,
                data: { breadcrumb: '' },
              },
            ],
          },
        ],
      },
    ],
  },
  {
    path: 'login',
    component: LoginComponent,
    pathMatch: 'full',
    data: {
      breadcrumb: 'login',
    },
  },

  {
    path: 'manage-access',
    canActivate: [AuthGuard],
    component: ManageAccessComponent,
    pathMatch: 'full',
    data: {
      breadcrumb: 'Admin',
    },
  },
  {
    path: 'employee-details',
    canActivate: [AuthGuard],
    component: ManageAccessComponent,
    pathMatch: 'full',
    data: {
      breadcrumb: 'Employee Details',
    },
  },
  {
    path: 'employee-details/add-employee',
    canActivate: [AuthGuard],
    component: AddEmployeeComponent,
    pathMatch: 'full',
    data: {
      breadcrumb: 'Admin',
    },
  },
  {
    path: 'employee-details/edit-employee',
    canActivate: [AuthGuard],
    component: AddEmployeeComponent,
    pathMatch: 'full',
    data: {
      breadcrumb: 'Admin',
    },
  },
  {
    path: 'table',
    canActivate: [AuthGuard],
    component: ProjectFormComponent,
    data: {
      breadcrumb: 'Table',
    },
  },
  // {
  //   path: 'form',
  //   component: FormComponent,
  //   data: {
  //     breadcrumb: 'Form',
  //   },
  // },
  {
    path: 'report',
    canActivate: [AuthGuard],
    component: ReportLogComponent,
    data: {
      breadcrumb: 'Reports',
    },
  },
  {
    path: 'admin',
    canActivate: [AuthGuard],
    component: AdminOptionsComponent,
   data: {
     breadcrumb: 'Admin',
   },
  },
  {
    path: 'admin/:requestedTab',
    canActivate: [AuthGuard],
    component: AdminComponentsComponent,
    data: {
      breadcrumb: 'Admin',
    },
  },
  {
    path: 'admin/bulk/engagementSoftDelete',
    canActivate: [AuthGuard],
    component: EngagementSoftDeleteComponent,
    data: {
      breadcrumb: 'Admin',
    },
  },
  {
    path: 'help',
    canActivate: [AuthGuard],
    component: FormComponent,
    data: {
      breadcrumb: 'Help',
    },
  },
  {
    path: 'dummy-project',
    component: ProjectFormComponent,
  },
  {
    path: 'table/:projectId',
    canActivate: [AuthGuard],
    component: ProjectFormComponent,
  },
  {
    path: 'table/:projectName',
    canActivate: [AuthGuard],
    component: ProjectFormComponent,
  },
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full',
  },
  {
    path: '**',
    component: PageNotFoundComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
export const routingComponents = [
  DashboardComponent,
  DataTableComponent,
  FormComponent,
];
