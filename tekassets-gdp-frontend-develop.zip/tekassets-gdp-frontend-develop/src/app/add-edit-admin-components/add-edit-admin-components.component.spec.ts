import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditAdminComponentsComponent } from './add-edit-admin-components.component';

describe('AddEditAdminComponentsComponent', () => {
  let component: AddEditAdminComponentsComponent;
  let fixture: ComponentFixture<AddEditAdminComponentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditAdminComponentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditAdminComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
