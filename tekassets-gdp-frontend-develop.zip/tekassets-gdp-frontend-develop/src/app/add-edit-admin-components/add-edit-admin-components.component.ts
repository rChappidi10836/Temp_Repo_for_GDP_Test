import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, Validators } from '@angular/forms';
import { IconDefinition, faTimes } from '@fortawesome/free-solid-svg-icons';
import { Inject } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { AdminDropdownService } from '../services/admin-dropdown.service';
import { Router } from '@angular/router';
import { DemoService } from '../services/demo.service';
import { SharedService } from '../services/shared.service';

@Component({
  selector: 'app-add-edit-admin-components',
  templateUrl: './add-edit-admin-components.component.html',
  styleUrls: ['./add-edit-admin-components.component.scss'],
})
export class AddEditAdminComponentsComponent implements OnInit {
  faTimes: IconDefinition = faTimes;
  field = this.fb.group({
    fieldName: [null],
    active: [null],
    opcomp:[null]
  });

  value: string;
  requestedTab: string;
  buttonText: string;
  id = null;
  newField: any;
  valueCheckBoolean = {};
  valueCheck = true;
  operatingCompanyDropdown: any;
  selectedOperatingCompany: any;
  opco_id:any;
  accountName: any;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddEditAdminComponentsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private adminDropdownService: AdminDropdownService,
    private router: Router,
    private demoService:DemoService,
    private sharedService:SharedService
  ) {}

  ngOnInit(): void {
    this.value = this.data.action;
    this.requestedTab = this.data.requestedTab;
    this.id = this.data.id;
    console.log(this.data);
    this.accountName=this.data.fieldName;
    this.field.controls['fieldName'].setValue(this.data.fieldName);
    this.field.controls['active'].setValue(this.data.active);
    this.field.controls['opcomp'].setValue(this.data.opco_id);
    Object.assign(this.valueCheckBoolean, this.field.value);
    if(this.data.description === 'Account Name'){
    this.opco_id=this.sharedService.sharedDataSubject.value||this.data.opco_id||1;
    
    this.field.controls['opcomp'].setValue(this.opco_id);
    this.getOpcoDropdown();
    }
    this.onChangeText();
  }
  getOpcoDropdown() {
    this.demoService.getOpcoDropdown()
      .subscribe((data) => {
        this.operatingCompanyDropdown = data.data;
      });
  }
  /**
   *
   * @param row closing dialog
   */
  close(row) {
    this.dialogRef.close(row);
  }
/**
 * case of adding new item
 * checks boolean value while saving
 */
  valuechange() {
    if (
      JSON.stringify(this.newField) === JSON.stringify(this.valueCheckBoolean)
    ) {
      this.valueCheck = true;
    } else {
      this.valueCheck = false;
    }
  }
/**
 * saving the changes
 */
  onSubmit() {
    const requestedTabData = {
      id: this.id,
      name: this.field.controls['fieldName'].value,
      active: this.field.controls['active'].value,
    };
    this.adminDropdownService
      .saveToRequestedTabData(requestedTabData, this.requestedTab)
      .subscribe((data) => {
        this.router
          .navigateByUrl('/admin', { skipLocationChange: true })
          .then(() => {
            this.router.navigate(['admin/', this.data.requestSource], {
              state: {},
            });
          });
      });
    this.close(0);
  }
  onOpcoSelection(id:any){
    this.opco_id=id;    
  }
  onClientSave(){
    
      this.adminDropdownService.getAccountName(this.field.controls['fieldName'].value,this.field.controls['active'].value,this.field.controls['opcomp'].value).subscribe((data) => {
        if (data === true&&this.accountName!==this.field.controls['fieldName'].value) {
          this.field.controls['fieldName'].markAsTouched();
          this.field.get('fieldName').setErrors({
            exist: true,
          });
        } else {
        
          const requestedTabData = {
            id: this.id,
            name: this.field.controls['fieldName'].value,
            active: this.field.controls['active'].value,
            opcoId:this.field.controls['opcomp'].value
          };
          this.adminDropdownService
            . saveClient(requestedTabData, this.requestedTab)
            .subscribe((data) => {
              this.router
                .navigateByUrl('/admin', { skipLocationChange: true })
                .then(() => {
                  this.router.navigate(['admin/', this.data.requestSource], {
                    state: {},
                  });
                });
            });
          this.close(0);
        
      }});
    
    }
    
/**
 * change button text for addNew and edit
 */
  onChangeText() {
    this.field.valueChanges.subscribe((selectedValue) => {
      this.newField = this.field.value;
      this.valuechange();
      return selectedValue;
    });
    if (this.value === 'Add New') {
      this.buttonText = 'Save';
    } else {
      this.buttonText = 'Update';
    }
  }

}
