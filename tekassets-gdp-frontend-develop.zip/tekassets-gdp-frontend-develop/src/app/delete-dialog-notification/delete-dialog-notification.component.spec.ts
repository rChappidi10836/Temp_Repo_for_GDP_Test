import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteDialogNotificationComponent } from './delete-dialog-notification.component';

describe('DeleteDialogNotificationComponent', () => {
  let component: DeleteDialogNotificationComponent;
  let fixture: ComponentFixture<DeleteDialogNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteDialogNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteDialogNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
