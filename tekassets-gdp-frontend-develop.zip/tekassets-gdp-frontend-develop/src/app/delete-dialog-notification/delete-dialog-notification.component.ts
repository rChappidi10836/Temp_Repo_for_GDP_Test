import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StatusReportComponent } from '../status-report/status-report.component';
@Component({
  selector: 'app-delete-dialog-notification',
  templateUrl: './delete-dialog-notification.component.html',
  styleUrls: ['./delete-dialog-notification.component.scss'],
})
export class DeleteDialogNotificationComponent implements OnInit {
  isNo = false;
  manageAccess: boolean;
  constructor(
    public dialogRef: MatDialogRef<StatusReportComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    if (this.data !== null) {
      this.manageAccess = true;
    } else if (this.data === null) {
      this.manageAccess = false;
    }
  }
/**
 * on click of no for delete dialog
 */
  onClick(): void {
    this.dialogRef.close(this.isNo);
  }
/**
 * on click of yes for delete dialog
 */
  onClickOfYes(): void {
    this.isNo = true;
    this.dialogRef.close(this.isNo);
  }
}
