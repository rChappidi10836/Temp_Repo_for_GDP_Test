import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { StatusReportComponent } from '../status-report/status-report.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-id-not-present-dialog',
  templateUrl: './id-not-present-dialog.component.html',
  styleUrls: ['./id-not-present-dialog.component.scss']
})
export class IdNotPresentDialogComponent implements OnInit {
  constructor(
    private router: Router,
    public dialogRef: MatDialogRef<IdNotPresentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { message: string, id: string }
  ) {
                
  }
  ngOnInit(): void {
    console.log(this.data.message)
    console.log(this.data.id)
  }


closeDialogAndNavigate(): void {
  this.dialogRef.close();
  this.router.navigate(['dashboard']);
   
}


}
