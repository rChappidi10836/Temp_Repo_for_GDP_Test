import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IdNotPresentDialogComponent } from './id-not-present-dialog.component';

describe('IdNotPresentDialogComponent', () => {
  let component: IdNotPresentDialogComponent;
  let fixture: ComponentFixture<IdNotPresentDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IdNotPresentDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IdNotPresentDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
