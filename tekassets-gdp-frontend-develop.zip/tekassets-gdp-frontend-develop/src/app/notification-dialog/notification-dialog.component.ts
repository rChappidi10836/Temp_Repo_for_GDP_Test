import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-notification-dialog',
  templateUrl: './notification-dialog.component.html',
  styleUrls: ['./notification-dialog.component.scss'],
})
export class NotificationDialogComponent implements OnInit {
  clearValue = false;
  message: string;
  source: string;
  showOKButton = true;

  constructor(
    private dialogRef: MatDialogRef<NotificationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) data
  ) {
    this.message = data.value;
    this.source = data.source;
  }

  ngOnInit(): void {
    if (
      this.source === 'project-updated' ||
      this.source === 'create-project' ||
      this.source === 'status-report'
    ) {
      this.showOKButton = true;
    } else {
      this.showOKButton = false;
    }
  }

  onClickOfOk() {
    this.dialogRef.close();
  }

  onClickOfYes() {
    this.clearValue = true;
    this.dialogRef.close(this.clearValue);
  }

  onClickOfNo() {
    this.clearValue = false;
    this.dialogRef.close(this.clearValue);
  }
}
