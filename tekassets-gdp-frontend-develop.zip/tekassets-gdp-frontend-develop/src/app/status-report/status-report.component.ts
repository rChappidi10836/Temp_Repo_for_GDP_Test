import {
  Component,
  OnInit,
  ViewChild,
  AfterViewInit,
  OnChanges,
  ChangeDetectorRef,
  Inject,
  LOCALE_ID,
  TemplateRef,
} from '@angular/core';
import { FormArray, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Constants } from '../model/Constants';
import { CreateProjectDialogComponent } from '../create-project-dialog/create-project-dialog.component';
import { StatusReport } from '../model/statusReport';
import { StatusReportServiceService } from '../services/status-report-service.service';
import {
  IconDefinition,
  faCircle,
  faPlus,
  faPen,
} from '@fortawesome/free-solid-svg-icons';
import { NotificationDialogComponent } from '../notification-dialog/notification-dialog.component';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MilestoneDelivery } from '../model/milestoneDelivery';
import { AgileSprint } from '../model/AgileSprint';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { DeleteDialogNotificationComponent } from '../delete-dialog-notification/delete-dialog-notification.component';
import { CreateProjectService } from '../services/create-project.service';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { AuthGuardService } from '../services/auth_guard.service';
import { AccessLevel } from '../enums/access_level';
import { HttpErrorResponse } from '@angular/common/http';
import { SharedService } from '../services/shared.service';

@Component({
  selector: 'app-status-report',
  templateUrl: './status-report.component.html',
  styleUrls: ['./status-report.component.scss'],
})
export class StatusReportComponent implements AfterViewInit, OnInit, OnChanges {
  statusOptions = ['Red', 'Yellow', 'Green'];
  currentPhaseOptions = [
    'Startup',
    'Execution',
    'Closeout',
    'Closed',
    'On Hold',
  ];


  displayedColumnsOfStatusHistory: string[] = [
    'weekEndingDate',
    'overAllStatus',
    'statusSummary',
    'actions',
  ];
  displayedAgileSprintColumns: string[] = [
    'track',
    'sprint',
    'startDate',
    'endDate',
    'deliveredStories',
    'committedStoryPoints',
    'deliveredStoryPoints',
    'addedStories',
    'removedStories',
    'capacity',
    'estimate',
    'goalMet',
    'sprintStatus',
    'lastUpdatedBy',
    'agileSprintActions',
  ];

  displayedMilestoneColumns: string[] = [
    'description',
    'type',
    'startDate',
    'endDate',
    'status',
    'comments',
    'lastUpdatedBy',
    'milestoneActions',
  ];

  milestoneTypeOptions = ['Delivery', 'Agile Sprint'];
//
  existingPhase: string | null = null;

  stateOptionsFilterSource = ['Active', 'Completed', 'Not Started'];
  masterStateOptionsFilterSource = ['Active', 'Completed', 'Not Started', 'All'];

  goalMetOptions = ['Yes', 'No'];

  typeOptions: Array<any> = [];

  // page size options
  pageSizeOptions = [10, 20, 50, 100];

  maxlenth: number = 0;
  maxperpage: number = 100;

  // icons
  faCircle: IconDefinition = faCircle;
  faPlus: IconDefinition = faPlus;
  faPen: IconDefinition = faPen;
  faChevronRight: IconDefinition = faChevronRight;

  // datasource
  statusReportArray = new MatTableDataSource<StatusReport>();
  milestoneDataSource = new MatTableDataSource<MilestoneDelivery>();
  agileDataSource = new MatTableDataSource<AgileSprint>();

  saveButtonText = '';
  currentStatus = 'Active'
  id: any;
  globalRequestSource: string;
  projectName: string;
  accountName: string;
  routedData: any;
  currentPage = 0;
  postPerPage = 10;
  totalPages: number;
  headerLastUpdatedAt = '';
  headerLastUpdatedBy = '';
  derivedOverAllStatus: string;
  milestoneText = '';
  currentDeliveryPage = 0;
  postDeliveryPerPage = 10;
  currentAgilePage = 0;
  postAgilePerPage = 10;
  agileData: any;
  deliveryData: any;
  filterDeliveryData: Array<any> = [];
  filterAgileData: Array<any> = [];
  totalCountDelivery: number;
  totalCountAgile: number;
  apiData: any;
  errorMessage: string;
  editedRowIndex: any;
  deliveryRiskIndicator: any;
  securityProfileStatus: any;
  securityAlert: string;
  securityAlertMessage: string;
  riskIndicatorAlert: string;
  riskIndicatorAlertMessage: string;
  statusReportFormUpdated: any;
  deliveryChangedValue: any;
  deliveryOriginalValue = {};
  deliveryOriginalValueForCancel: Array<any> = [];
  agileOriginalValueForCancel: Array<any> = [];
  agileOriginalValue = {};
  statusReportFormOriginal = {};
  agileChangedValue: any;
  deletedDeliveryRows: Array<any> = [];
  deletedAgileRows: Array<any> = [];
  hoursData: any;
  hoursDataCreation: any;
  hoursDataRecords: any;
  deliveryHoursRecords: any;
  opcoIdLabel = Constants.OPCO_ID;

  selectedOpcoId: any;
  currentrole = Constants.CURRENT_ROLE;


  // boolean
  statusHistorytableHasData = false;
  onCreateNewCheck = false;
  tableHasDeliveryData = false;
  tableHasAgileData = false;
  passDueDate = false;
  isTableEditable = false;
  securityProfileAlert = false;
  securityWarningProfileAlert = false;
  deliveryRiskIndicatorAlert = false;
  valueCheck = true;
  practiceEngagementBoolean = true;
  onCreateCopyCheck = false;
  isMielstoneInvalid = false;
  createCopyButtonVisible = true;

  // boolean for status details comments
  asterisk = false;
  scheduleCommentsCheck = false;
  csatCommentsCheck = false;
  budgetCommentsCheck = false;
  projectRiskCommentsCheck = false;
  resourcesCommentsCheck = false;

  milestoneTextChange = true;
  headerEditButton = false;
  hasEditAccess = false;
  enopco: any;
  // max date for weekending date.
  maxDate: Date;

  // flag for add milestones button.
  isEditingCurrentWeek = false;

  // flag to disable button when saving data
  isSavingData = false;

  numberPattern = /^\d+$/;
  hasError: boolean;
  @ViewChild('errorDialogTemplate') errorDialogTemplate!: TemplateRef<any>;
  clickedit: boolean = false;
  deliveryenable: any;
  initialFormData: any;
  isFormChanged: any;
  milestoneAdd: boolean;
  storageKey = 'deliveryenable';
  

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private statusReportService: StatusReportServiceService,
    private createProjectService: CreateProjectService,
    public dialog: MatDialog,
    public matDialog: MatDialog,
    private ref: ChangeDetectorRef,
    private sharedService: SharedService,
    private authService: AuthGuardService,
    @Inject(LOCALE_ID) private locale: string
  ) {

    // this.deliveryData=this.sharedService.observer3.subscribe((data)=>{
    //   if(this.deliveryData){
    // this.deliveryenable = this.sharedService.deliverymodel.value

    //   }
    // })
    // console.log(this.deliveryenable)
    // setting max weekending date as current week + 4 weeks.
    const date = new Date();
    this.maxDate = new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate() + 35
    );


    this.statusReportForm.valueChanges.subscribe((selectedValue) => {
      this.statusReportFormUpdated = this.statusReportForm.value;
      this.valuechange();
      return selectedValue;
    });
  }


  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('t1Sort') t1Sort: MatSort;
  @ViewChild('t2Sort') t2Sort: MatSort;
  @ViewChild('t3Sort') t3Sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  statusReportForm = this.fb.group({
    scheduleStatus: [null, Validators.required],
    csatStatus: [null, Validators.required],
    budgetStatus: [null, Validators.required],
    projectRiskStatus: [null, Validators.required],
    resourcesStatus: [null, Validators.required],
    scheduleComments: [''],
    csatComments: [''],
    budgetComments: [''],
    projectRiskComments: [''],
    resourcesComments: [''],
    deliveryRiskIndicator: [null],
    securityProfileStatus: [null],
    weekEndingDate: [{ value: new Date() }, Validators.required],
    currentPhase: [null, Validators.required],
    statusSummary: ['', Validators.required],
    projectId: [null],
    overAllStatus: [null],
    statusReportFormArray: this.fb.array([]),
  });

  getPageSizeOptions(): number[] {
    if (this.maxlenth > this.maxperpage)
      return [10, 20, 50, this.maxperpage, this.maxlenth];
    else
      return [10, 20, 50, this.maxperpage];
  }

  validateInput(event: any) {
    const userInput = event.target.value;

    const keyboardPattern = /^[a-zA-Z0-9\s!"#$%&'()*+,-./:;<=>?@[\\\]^_`{|}~]*$/;
    this.isMielstoneInvalid = false;

    if (!keyboardPattern.test(userInput)) {


      this.statusReportForm.get('statusSummary').setErrors({ 'invalidInput': true });

    }
    else {
      this.statusReportForm.get('statusSummary').setErrors(null);
    }
  }
  async ngOnInit() {

     const stored = localStorage.getItem(this.storageKey);
     const fallback = stored !== null ? JSON.parse(stored) as boolean : null;
    

     if (this.sharedService.deliverymodel.value === null && fallback !== null) {
      this.sharedService.emitdelivery(fallback);
      
    }
   
    this.sharedService.observer3.subscribe(flag => {       
      this.deliveryenable = flag;     
       localStorage.setItem(this.storageKey, JSON.stringify(flag));
      });

   

    if (Constants.CURRENT_ROLE == 'Admin' || Constants.CURRENT_ROLE == 'Executive') {
      if (this.sharedService.shareengopco.value == null) {
        const raw = localStorage.getItem('engagementOpco');
        this.selectedOpcoId = raw !== null ? JSON.parse(raw) as number : null;
        // console.log(this.selectedOpcoId)
      } else {
        this.selectedOpcoId = this.sharedService.shareengopco.value;
        localStorage.setItem('engagementOpco', JSON.stringify(this.sharedService.shareengopco.value));
      }
    } else {
      this.selectedOpcoId = Constants.OPCO_ID;
    }
    this.saveButtonText = 'Save';
    this.activatedRoute.params.subscribe((params) => {
      this.id = params.projectId;
      
     

      // console.log("widnow", window.history.state.opcoId)
      // console.log("shared service", this.sharedService.shareengopco.value)
      // console.log("localstorage", localStorage.getItem('engagementOpco'))
      if (window.history.state.opcoId == 2) {
        // console.log('also here')
        this.selectedOpcoId = window.history.state.opcoId;
      }
      // console.log(typeof (this.selectedOpcoId), this.selectedOpcoId, "diff", localStorage.getItem('engagementOpco'));
      console.log(params);
      if (this.id !== null && this.id && this.id !== undefined) {
        const requestSource = window.history.state.source;
        this.globalRequestSource = requestSource;
        this.getStatusReport();
      }
    });
    this.getAllDeliveryMilestoneTypes();
    this.hasEditAccess = await this.authService.doesUserHaveAccessToRole(
      AccessLevel.EDIT_ACCESS
    );
    this.initialFormData = { ...this.statusReportForm.value };
    console.log(typeof (this.initialFormData))


  }


  ngAfterViewInit() {
    this.statusReportArray.sort = this.t2Sort;
    this.milestoneDataSource.sort = this.t1Sort;
    this.agileDataSource.sort = this.t3Sort;
  }

  ngOnChanges() {
    this.statusReportArray.sort = this.t2Sort;
    this.milestoneDataSource.sort = this.t1Sort;
    this.agileDataSource.sort = this.t3Sort;
  }

  ngAfterViewChecked() {
    this.statusReportArray.sort = this.t2Sort;
    this.milestoneDataSource.sort = this.t1Sort;
    this.agileDataSource.sort = this.t3Sort;
  }

  get getStatusReportFormArray(): FormArray {
    return this.statusReportForm.get('statusReportFormArray') as FormArray;
  }

  initGroup() {
    const rows = this.statusReportForm.get(
      'statusReportFormArray'
    ) as FormArray;
    rows.push(
      this.fb.group({
        name: [''],
        hours: [''],
        resourceId: [''],
        id: [''],
        resourceRole: new FormControl({ value: '', disabled: true }, Validators.required),
      })
    );
  }

  patchValues(i, value) {
    const x = (this.statusReportForm.controls[
      'statusReportFormArray'
    ] as FormArray).at(i);

    x.patchValue({
      name: value.objectName,
      hours: value.objectHours === null ? '' : value.objectHours,
      resourceId: value.objectResourceId,
      id: value.objectId === undefined ? null : value.objectId,
      resourceRole: value.objectResourceRole === undefined ? null : value.objectResourceRole
    });
  }

  enableStatusReportArrayForm() {
    const formArrayControl = this.statusReportForm.controls
      .statusReportFormArray['controls'];
    let i = 0;
    while (i < this.hoursDataRecords) {
      formArrayControl[i].controls.resourceRole.disable();
      formArrayControl[i].controls.name.disable();
      formArrayControl[i].controls.hours.enable();
      i++;
    }
  }

  setHeaderData() {
    this.projectName = this.apiData.projectName;
    this.accountName = this.apiData.accountName;
    this.deliveryRiskIndicator = this.apiData.deliveryRiskIndicator;
    if (this.deliveryRiskIndicator === null) {
      this.deliveryRiskIndicator = 'Not Completed';
    }
    this.statusReportForm.controls['deliveryRiskIndicator'].setValue(
      this.deliveryRiskIndicator
    );
    this.securityProfileStatus = this.apiData.securityProfileStatus;
    this.statusReportForm.controls['securityProfileStatus'].setValue(
      this.securityProfileStatus
    );
    this.onAlert();
    this.totalPages = this.apiData.totalCount;
    this.headerLastUpdatedAt = this.apiData.lastUpdatedAt
      ? this.apiData.lastUpdatedAt
      : '';
    this.headerLastUpdatedBy = this.apiData.lastUpdatedBy
      ? this.apiData.lastUpdatedBy
      : '';
  }

  getStatusReport() {

    if (this.id !== undefined && this.id && this.id !== 'NaN') {
      this.statusReportService
        .getSampleStatusReport(this.id, this.currentPage, this.postPerPage)
        .subscribe((data) => {
          console.log(data)
          this.apiData = data.data[0];
          
          this.maxlenth = data.data[0].totalCount;
          this.setHeaderData();
          if (this.apiData.weeklyStatus.length === 0) {
            this.getDefaultView();
            this.headerEditButton = true;
            this.createCopyButtonVisible = false;
            this.getDeliveryTeamHoursProjects();
          } else {
            this.createCopyButtonVisible = true;
            this.setDataInStatusReportForm(this.apiData.weeklyStatus[0]);
            this.initializeDatasourceOfStatusHistory(this.apiData.weeklyStatus);           
           
          }
        },
          (error: HttpErrorResponse) => {
            if (error.status === 404) {
              console.error('Id not found: ', error.message);
              this.errorMessage = 'ID not found';
              this.errorDialogBox('ID NOT FOUND');
              this.hasError = true;
            } else {
              console.error('API Error:', error.message);
              // this.showSnackBar('ID not found');
              this.errorDialogBox('ID NOT FOUND');
              this.hasError = true;
            }
          }
        );

    }
  }
  
errorDialogBox(message: string) {
    const dialogRef = this.dialog.open(this.errorDialogTemplate, {
      data: { message }, // Pass data to the template
      disableClose: true,
    });
  }
  closeDialogAndNavigate() {
    this.dialog.closeAll();
    this.router.navigate(['dashboard']);
  }

  async onEditHeader() {
    this.clickedit = true;

    this.statusReportForm.enable();

    this.onEdit(this.apiData.weeklyStatus[0]);
    // this.enableForm();
    this.headerEditButton = true;
    this.valueCheck = true;

    // changes
    this.saveButtonText = 'Update';

    this.activatedRoute.params.subscribe((params) => {
      this.id = params.projectId;
      if (this.id !== null && this.id && this.id !== undefined) {
        const requestSource = window.history.state.source;
        this.globalRequestSource = requestSource;
        this.getStatusReport();
      }
    });
    this.getAllDeliveryMilestoneTypes();
    this.hasEditAccess = await this.authService.doesUserHaveAccessToRole(
      AccessLevel.EDIT_ACCESS
    );
  }



  setDataInStatusReportForm(latestStatusReport) {
    if (this.apiData.weeklyStatus[0] === latestStatusReport) {
      this.headerEditButton = false;
    }
    this.statusReportForm.controls['weekEndingDate'].setValue(
      new Date(latestStatusReport.weekEndingDate).toISOString()
    );

    // To store existing phase
    this.existingPhase = latestStatusReport.currentPhase;

    this.statusReportForm.controls['currentPhase'].setValue(
      latestStatusReport.currentPhase
    );
    this.statusReportForm.controls['statusSummary'].setValue(
      latestStatusReport.summary
    );

    this.statusReportForm.controls['scheduleStatus'].setValue(
      latestStatusReport.schedule
    );
    if (
      latestStatusReport.schedule === 'Red' ||
      latestStatusReport.schedule === 'Yellow'
    ) {
      this.changedStatusComment('scheduleStatus');
    }

    this.statusReportForm.controls['csatStatus'].setValue(
      latestStatusReport.csat
    );
    if (
      latestStatusReport.csat === 'Red' ||
      latestStatusReport.csat === 'Yellow'
    ) {
      this.changedStatusComment('csatStatus');
    }

    this.statusReportForm.controls['budgetStatus'].setValue(
      latestStatusReport.budget
    );
    if (
      latestStatusReport.budget === 'Red' ||
      latestStatusReport.budget === 'Yellow'
    ) {
      this.changedStatusComment('budgetStatus');
    }

    this.statusReportForm.controls['projectRiskStatus'].setValue(
      latestStatusReport.projectRisk
    );
    if (
      latestStatusReport.projectRisk === 'Red' ||
      latestStatusReport.projectRisk === 'Yellow'
    ) {
      this.changedStatusComment('projectRiskStatus');
    }

    this.statusReportForm.controls['resourcesStatus'].setValue(
      latestStatusReport.resources
    );
    if (
      latestStatusReport.resources === 'Red' ||
      latestStatusReport.resources === 'Yellow'
    ) {
      this.changedStatusComment('resourcesStatus');
    }

    if (
      latestStatusReport.scheduleComments !== null &&
      latestStatusReport.scheduleComments
    ) {
      this.statusReportForm.controls['scheduleComments'].setValue(
        latestStatusReport.scheduleComments
      );
    }
    if (
      latestStatusReport.csatComments !== null &&
      latestStatusReport.csatComments
    ) {
      this.statusReportForm.controls['csatComments'].setValue(
        latestStatusReport.csatComments
      );
    }
    if (
      latestStatusReport.budgetComments !== null &&
      latestStatusReport.budgetComments
    ) {
      this.statusReportForm.controls['budgetComments'].setValue(
        latestStatusReport.budgetComments
      );
    }
    if (
      latestStatusReport.projectRiskComments !== null &&
      latestStatusReport.projectRiskComments
    ) {
      this.statusReportForm.controls['projectRiskComments'].setValue(
        latestStatusReport.projectRiskComments
      );
    }
    if (
      latestStatusReport.resourcesComments !== null &&
      latestStatusReport.resourcesComments
    ) {
      this.statusReportForm.controls['resourcesComments'].setValue(
        latestStatusReport.resourcesComments
      );
    }
    this.getOverAllStatus()
    if (!this.clickedit) {
      this.disableForm();
    }


    if (this.saveButtonText !== 'Update') {
      this.getDeliveryMilestoneData();
    }
    this.getDeliveryTeamHoursProjects();

  }

  initializeDatasourceOfStatusHistory(statusHistoryTableData) {
    this.statusReportArray = new MatTableDataSource<StatusReport>(
      statusHistoryTableData
    );
    this.sortDate();
    this.statusReportArray.sort = this.t2Sort;
    if (this.statusReportArray.data.length > 0) {
      this.statusHistorytableHasData = true;
    } else {
      this.statusHistorytableHasData = false;
    }
  }

  getDeliveryTeamHoursProjects() {
    this.setDeliveryHours();
  }

 async setDeliveryHours() {
    const weekEndingDate = this.statusReportForm.controls['weekEndingDate'].value.value ?? this.statusReportForm.controls['weekEndingDate'].value;
    
    this.statusReportService.getDeliveryHoursByWED(
      this.id,
      this.convertISOStringToDateString(weekEndingDate)
    ).subscribe((response) => {

      let deliveryHours = response.data ;   
      if (deliveryHours != null && deliveryHours.length > 0) {
        this.practiceEngagementBoolean =  false ;
        
      } else {
         this.practiceEngagementBoolean =  true ;
         this.disableForm();
      }

      let i = 0;
      deliveryHours.forEach((item) => {
        if (item.id == null && !this.onCreateCopyCheck) {
          item.hours = '';
        }
        this.setStatusReportFormArray(item, i);
        // tslint:disable-next-line: no-unused-expression
        i++ < this.hoursDataRecords;
      });
      if (this.onCreateNewCheck) {  
        this.enableForm(); };
    });
  }

  setStatusReportFormArray(item, index) {
    const formArrayControl = this.statusReportForm.controls
      .statusReportFormArray['controls'];
    const name = item.name;
    const hours = item.hours;
    const resourceId = item.resourceId;
    const id = item.id;
    const resourceRole = item.resourceRole;
    let canAdd = true;
    formArrayControl.forEach(formItem => {
      if (formItem.value.resourceId === resourceId) {
        canAdd = false;
      }
    });
    if (name === undefined || name === '') {
      canAdd = false;
    }
    if (!canAdd) return;
    const addRowObject = {
      objectName: name,
      objectHours: hours,
      objectResourceId: resourceId,
      objectId: id,
      objectResourceRole: resourceRole
    };
    this.initGroup();
    this.patchValues(index, addRowObject);
    formArrayControl[index].controls.name.disable();
    formArrayControl[index].controls.hours.disable();
  }

  clearDeliveryHours() {
    const frmArray = this.statusReportForm.get(
      'statusReportFormArray'
    ) as FormArray;
    frmArray.clear();
  }

  disableForm() {
    this.statusReportForm.disable();
  }

  enableForm() {
    this.statusReportForm.enable();
    this.checkMilestoneValidity();
    this.enableStatusReportArrayForm();
  }

  getDefaultView() {
    this.statusReportForm.controls['scheduleStatus'].setValue('Green');
    this.statusReportForm.controls['csatStatus'].setValue('Green');
    this.statusReportForm.controls['budgetStatus'].setValue('Green');
    this.statusReportForm.controls['projectRiskStatus'].setValue('Green');
    this.statusReportForm.controls['resourcesStatus'].setValue('Green');
    this.milestoneText = 'Delivery';
    this.getOverAllStatus();
  }

  getOverAllStatus() {
    const derivedScheduleStatus = this.statusReportForm.controls[
      'scheduleStatus'
    ].value;
    const derivedCsatStatus = this.statusReportForm.controls['csatStatus']
      .value;
    const derivedBudgetStatus = this.statusReportForm.controls['budgetStatus']
      .value;
    const derivedProjectRiskStatus = this.statusReportForm.controls[
      'projectRiskStatus'
    ].value;
    const derivedResourcesStatus = this.statusReportForm.controls[
      'resourcesStatus'
    ].value;
    if (
      derivedScheduleStatus === 'Red' ||
      derivedCsatStatus === 'Red' ||
      derivedBudgetStatus === 'Red' ||
      derivedProjectRiskStatus === 'Red' ||
      derivedResourcesStatus === 'Red'
    ) {
      this.derivedOverAllStatus = 'Red';
      this.asterisk = true;
    } else if (
      derivedScheduleStatus === 'Yellow' ||
      derivedCsatStatus === 'Yellow' ||
      derivedBudgetStatus === 'Yellow' ||
      derivedProjectRiskStatus === 'Yellow' ||
      derivedResourcesStatus === 'Yellow'
    ) {
      this.derivedOverAllStatus = 'Yellow';
      this.asterisk = true;
    } else if (
      derivedScheduleStatus === 'Green' &&
      derivedCsatStatus === 'Green' &&
      derivedBudgetStatus === 'Green' &&
      derivedProjectRiskStatus === 'Green' &&
      derivedResourcesStatus === 'Green'
    ) {
      this.derivedOverAllStatus = 'Green';
      this.asterisk = false;
    }

    return this.derivedOverAllStatus;
  }

  changedStatusComment(value) {
    if (value === 'scheduleStatus') {
      this.scheduleCommentsCheck = true;
      const derivedScheduleStatus = this.statusReportForm.controls[
        'scheduleStatus'
      ].value;
      if (derivedScheduleStatus === 'Green') {
        this.scheduleCommentsCheck = false;
      }
    }
    if (value === 'csatStatus') {
      this.csatCommentsCheck = true;
      const derivedCsatStatus = this.statusReportForm.controls['csatStatus']
        .value;
      if (derivedCsatStatus === 'Green') {
        this.csatCommentsCheck = false;
      }
    }
    if (value === 'budgetStatus') {
      this.budgetCommentsCheck = true;
      const derivedBudgetStatus = this.statusReportForm.controls['budgetStatus']
        .value;
      if (derivedBudgetStatus === 'Green') {
        this.budgetCommentsCheck = false;
      }
    }
    if (value === 'projectRiskStatus') {
      this.projectRiskCommentsCheck = true;
      const derivedProjectRiskStatus = this.statusReportForm.controls[
        'projectRiskStatus'
      ].value;
      if (derivedProjectRiskStatus === 'Green') {
        this.projectRiskCommentsCheck = false;
      }
    }
    if (value === 'resourcesStatus') {
      this.resourcesCommentsCheck = true;
      const derivedResourcesStatus = this.statusReportForm.controls[
        'resourcesStatus'
      ].value;
      if (derivedResourcesStatus === 'Green') {
        this.resourcesCommentsCheck = false;
      }
    }
  }

  onChangedPageOfStatusHistory(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex;
    this.postPerPage = pageData.pageSize;
    this.getStatusReport();
  }

  onView(row) {
    this.headerEditButton = true;
    this.editedRowIndex = row;
    const emptyString = '';
    this.setDefaultValueInFormControlsOfComments(emptyString);
    this.setDataInStatusReportForm(row);
    this.clearDeliveryHours();
    this.setDeliveryHours();
  }

  getWeekNumber(d: Date): number {
    d = new Date(+d);
    d.setHours(0, 0, 0);
    // Set to nearest Thursday: current date + 4 - current day number
    // Make Sunday's day number 7
    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
    // Get first day of year
    const yearStart = new Date(d.getFullYear(), 0, 1);
    // Calculate full weeks to nearest Thursday
    const weekNo = Math.ceil(
      ((d.valueOf() - yearStart.valueOf()) / 86400000 + 1) / 7
    );
    // Return array of year and week number
    return weekNo;
  }

  onEdit(row) {
    
    this.existingPhase = row.currentPhase;  
    Object.assign(this.statusReportFormOriginal, this.statusReportForm.value);
    this.editedRowIndex = row;
    const emptyString = '';
    this.onCreateNewCheck = true;
    this.isTableEditable = true;
    this.saveButtonText = 'Update';
    this.isEditingCurrentWeek =
      this.getWeekNumber(new Date(row.weekEndingDate)) + 1 >=
      this.getWeekNumber(new Date());
    this.setDefaultValueInFormControlsOfComments(emptyString);
    this.setDataInStatusReportForm(row);
    this.enableForm();
    this.statusReportForm.controls['weekEndingDate'].enable();
    this.statusReportForm.markAsDirty();
    this.ref.detectChanges();
    this.statusReportFormUpdated = this.statusReportForm.value;
    this.statusReportForm.valueChanges.subscribe((selectedValue) => {
      this.statusReportFormUpdated = this.statusReportForm.value;
      this.valuechange();
      return selectedValue;
    });
    this.clearDeliveryHours();
    this.setDeliveryHours();
    this.initialFormData = { ...this.statusReportForm.value };
  }

  setCommentsToEmpty() {
    // tslint:disable-next-line: no-unused-expression
    this.statusReportFormUpdated.budgetComments === null
      ? ''
      : this.statusReportFormUpdated.budgetComments;
    // tslint:disable-next-line: no-unused-expression
    this.statusReportFormUpdated.csatComments === null
      ? ''
      : this.statusReportFormUpdated.csatComments;
    // tslint:disable-next-line: no-unused-expression
    this.statusReportFormUpdated.projectRiskComments === null
      ? ''
      : this.statusReportFormUpdated.projectRiskComments;
    // tslint:disable-next-line: no-unused-expression
    this.statusReportFormUpdated.resourcesComments === null
      ? ''
      : this.statusReportFormUpdated.resourcesComments;
    // tslint:disable-next-line: no-unused-expression
    this.statusReportFormUpdated.scheduleComments === null
      ? ''
      : this.statusReportFormUpdated.scheduleComments;
  }

  valuechange() {
    // if (
    //   JSON.stringify(this.statusReportFormUpdated) ===
    //   JSON.stringify(this.statusReportFormOriginal) &&
    //   (this.deliveryChangedValue === null ||
    //     this.deliveryChangedValue === undefined
    //     ? true
    //     : JSON.stringify(this.deliveryChangedValue.filteredData) ===
    //     JSON.stringify(this.deliveryOriginalValue)) &&
    //   (this.agileChangedValue === null || this.agileChangedValue === undefined
    //     ? true
    //     : JSON.stringify(this.agileChangedValue.filteredData) ===
    //     JSON.stringify(this.agileOriginalValue))
    // ) {
    //   this.valueCheck = true;
    // } else {
    //   this.valueCheck = false;
    // }
    if (this.saveButtonText === 'Update') {
      this.statusReportForm.valueChanges.subscribe(() => {
        this.isFormChanged = this.isFormDataChanged();
        if (this.isFormChanged
        ) {
          this.valueCheck = false;
        }
        else {
          this.valueCheck = true;
        }
      });
    }
  }
  isFormDataChanged(): boolean {
    const currentFormData = { ...this.statusReportForm.value };
    return JSON.stringify(currentFormData) != JSON.stringify(this.initialFormData);
  }
  deleteRow(row) {
    const dialogRef = this.dialog.open(DeleteDialogNotificationComponent);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        this.onDelete(row);
      }
    });
  }

  onDelete(row) {
    this.enableForm();
    if (Number(this.id) !== undefined && Number(this.id) && this.id !== 'NaN') {
      this.statusReportForm.controls['projectId'].setValue(Number(this.id));
    }
    this.statusReportForm.controls['weekEndingDate'].setValue(
      this.convertISOStringToDateString(new Date(row.weekEndingDate))
    );
    this.statusReportService
      .deleteStatusReport(this.statusReportForm.value)
      .subscribe((data) => {
        this.disableForm();
        this.getStatusReport();
        this.deleteDataSourceOfStatusHistory(row.weekEndingDate);
      });
  }

  deleteDataSourceOfStatusHistory(date) {
    const updatedStatusHistory = this.apiData.weeklyStatus.filter(
      (project) => project.weekEndingDate !== date
    );
    this.statusReportArray = new MatTableDataSource(updatedStatusHistory);
    this.sortDate();
  }

  getConvertedWeekEndingDateOnUpdate(date) {
    let weekEndingDateArray = date.split('T', 1).toString();
    weekEndingDateArray = weekEndingDateArray.split('-');
    // tslint:disable-next-line: radix
    const addedDay = parseInt(weekEndingDateArray[2]) + 1;
    return (
      weekEndingDateArray[1] +
      '-' +
      addedDay.toString() +
      '-' +
      weekEndingDateArray[0]
    );
  }

  async onSave(milestoneDataSource, agileSprintDataSource) {
    this.isSavingData = true;
    if (Number(this.id) !== undefined && Number(this.id) && this.id !== 'NaN') {
      this.statusReportForm.controls['projectId'].setValue(Number(this.id));
    }
    this.statusReportForm.controls['weekEndingDate'].enable();
    if (this.statusReportForm.valid) {
      let saveFailed = false;
      const convertedWeekEndingDate = this.statusReportForm.controls[
        'weekEndingDate'
      ].value;
      const date = new Date(this.convertISOStringToDateString(convertedWeekEndingDate));
      if (date.getDay() == 0) {
        date.setDate(date.getDate() - 1);
      }
      this.statusReportForm.controls['weekEndingDate'].setValue(
        date.toISOString().substring(0, 10)
      );
      this.statusReportForm.controls['overAllStatus'].setValue(
        this.derivedOverAllStatus
      );
      const formValue = this.statusReportForm.value;
      if (this.saveButtonText === 'Save') {
        saveFailed = await new Promise<boolean>(resolve => this.statusReportService
          .saveStatusReport(this.statusReportForm.value)
          .subscribe(
            (data) => {
              this.isSavingData = false;
              this.onCreateNewCheck = false;
              if (
                this.deletedDeliveryRows.length > 0 &&
                milestoneDataSource.filteredData !== null
              ) {
                this.deletedDeliveryRows.forEach((item) => {
                  if (item.id !== null) {
                    milestoneDataSource.filteredData.push(item);
                  }
                });
              }
              if (
                this.deletedAgileRows.length > 0 &&
                agileSprintDataSource.filteredData !== null
              ) {
                this.deletedAgileRows.forEach((item) => {
                  if (item.id !== null) {
                    agileSprintDataSource.filteredData.push(item);
                  }
                });
              }

              const DATA_MILESTONE = this.removeWeekEndingDateAndIdsFromMilestoneDate();

              this.statusReportService
                .saveMilestoneStatusReport(DATA_MILESTONE)
                .subscribe((res) => {
                  const commentValue = '';
                  this.isTableEditable = false;
                  this.onCreateNewCheck = false;
                  this.setDefaultValueInFormControlsOfComments(commentValue);
                  this.getStatusReport();
                  this.totalCountDelivery =
                    milestoneDataSource.filteredData.length -
                    this.deletedDeliveryRows.length;
                  this.totalCountAgile =
                    agileSprintDataSource.filteredData.length -
                    this.deletedAgileRows.length;
                  this.getDeliveryMilestoneData();
                });
              resolve(false);
            },
            (error) => {
              this.isSavingData = false;
              this.errorMessage = Constants.DUPLICATE_WEEKENDINGDATE_EXISTS;
              const dialogConfig = new MatDialogConfig();
              dialogConfig.autoFocus = true;
              dialogConfig.width = '500px';
              dialogConfig.data = {
                value: this.errorMessage,
                source: 'status-report',
              };
              const dialogRef = this.dialog.open(
                NotificationDialogComponent,
                dialogConfig
              );
              dialogRef.afterClosed().subscribe((_) => {
                this.onCreateNewCheck = true;
                this.enableForm();
                this.statusReportForm.controls['weekEndingDate'].enable();
                this.saveButtonText = 'Save';
              });
              this.statusReportForm.controls['weekEndingDate'].setValue(
                convertedWeekEndingDate
              );
              resolve(true);
            }
          ));
      } else {
        this.statusReportForm.controls['weekEndingDate'].setValue(
          this.convertISOStringToDateString(convertedWeekEndingDate)
        );
        saveFailed = await new Promise<boolean>(resolve => this.statusReportService
          .updateStatusReport(this.statusReportForm.value)
          .subscribe(
            (data) => {
              this.isSavingData = false;
              if (
                this.deletedDeliveryRows.length > 0 &&
                milestoneDataSource.filteredData !== null
              ) {
                this.deletedDeliveryRows.forEach((item) => {
                  if (item.id !== null) {
                    milestoneDataSource.filteredData.push(item);
                  }
                });
              }
              if (
                this.deletedAgileRows.length > 0 &&
                agileSprintDataSource.filteredData !== null
              ) {
                this.deletedAgileRows.forEach((item) => {
                  if (item.id !== null) {
                    agileSprintDataSource.filteredData.push(item);
                  }
                });
              }
              const DATA_MILESTONE = {
                deliveryMilestoneDto:
                  milestoneDataSource.filteredData === null ||
                    milestoneDataSource.filteredData === undefined
                    ? null
                    : milestoneDataSource.filteredData,
                agileSprintMilestoneDto:
                  agileSprintDataSource.filteredData === null ||
                    agileSprintDataSource.filteredData === undefined
                    ? null
                    : agileSprintDataSource.filteredData,
                projectId: Number(this.id),
              };
              this.statusReportService
                .saveMilestoneStatusReport(DATA_MILESTONE)
                .subscribe((element) => {
                  const commentValue = '';
                  this.isTableEditable = false;
                  this.onCreateNewCheck = false;
                  this.setDefaultValueInFormControlsOfComments(commentValue);
                  this.getStatusReport();
                  this.totalCountDelivery =
                    milestoneDataSource.filteredData.length -
                    this.deletedDeliveryRows.length;
                  this.totalCountAgile =
                    agileSprintDataSource.filteredData.length -
                    this.deletedAgileRows.length;
                  this.getDeliveryMilestoneData();
                });
              resolve(false);
              const dialogConfig = new MatDialogConfig();
              dialogConfig.autoFocus = true;
              this.clickedit = false
              dialogConfig.data = {
                value: Constants.UPDATED_SUCCESS_MESSAGE,
                source: 'status-report',
              };
              const dialogRef = this.dialog.open(
                NotificationDialogComponent,
                dialogConfig
              );
            },
            (error) => {
              this.isSavingData = false;
              this.errorMessage = 'Unable to update.';
              const dialogConfig = new MatDialogConfig();
              dialogConfig.autoFocus = true;
              dialogConfig.width = '500px';
              dialogConfig.data = {
                value: this.errorMessage,
                source: 'status-report',
              };
              const dialogRef = this.dialog.open(
                NotificationDialogComponent,
                dialogConfig
              );
              dialogRef.afterClosed().subscribe((_) => {
                this.onEditHeader();
              });
              resolve(true);
            }
          ));
      }
      if (saveFailed) {
        return;
      };
      this.statusReportForm.controls['weekEndingDate'].setValue(
        this.getConvertedWeekEndingDate(convertedWeekEndingDate)
      );
      // no need to call for saving delivery hours if not flexible capacity project
      if (this.practiceEngagementBoolean) return;
      const deliveryHoursRequestObject = {
        projectId: this.id,
        resourceHours: this.statusReportForm.controls.statusReportFormArray
          .value,
        weekEndingDate: this.statusReportForm.controls['weekEndingDate'].value,
      };
      deliveryHoursRequestObject.weekEndingDate = this.getWeekEndingDate();
      this.statusReportService
        .saveDeliveryHours(deliveryHoursRequestObject)
        .subscribe((data) => {
          this.clearDeliveryHours();
          this.getStatusReport();
        });
    }
  }

  onCancel() {
    const dialogRef = this.dialog.open(CreateProjectDialogComponent);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        const commentValue = '';
        this.isTableEditable = false;
        this.onCreateNewCheck = false;
        this.onCreateCopyCheck = false;
        this.milestoneDataSource = new MatTableDataSource<MilestoneDelivery>(
          this.deliveryOriginalValueForCancel
        );
        this.sortDescription(this.milestoneDataSource);
        this.agileDataSource = new MatTableDataSource<AgileSprint>(
          this.agileOriginalValueForCancel
        );
        this.sortDescription(this.agileDataSource);
        this.setDefaultValueInFormControlsOfComments(commentValue);
        this.setDataInStatusReportForm(this.apiData.weeklyStatus[0]);
        this.initializeDatasourceOfStatusHistory(this.apiData.weeklyStatus);

        this.clearDeliveryHours();
        this.setDeliveryHours();
      }
    });
  }

  onReset() {
    this.statusReportForm.reset();
    if (this.saveButtonText === 'Save' && this.onCreateCopyCheck === false) {
      this.onCreateNew();
      this.editModeShuffle();
      
    } else if (
      this.saveButtonText === 'Save' &&
      this.onCreateCopyCheck === true
    ) {
      if (this.editedRowIndex !== undefined) {
        this.setDataInStatusReportForm(this.editedRowIndex);
        this.editModeShuffle();
        this.onCreateCopy();
      } else {
        this.setDataInStatusReportForm(this.apiData.weeklyStatus[0]);
        this.editModeShuffle();
        this.onCreateCopy();
      }
    } else {
      const commentValue = '';
      this.isTableEditable = false;
      this.onCreateNewCheck = false;
      this.setDefaultValueInFormControlsOfComments(commentValue);
      this.setDataInStatusReportForm(this.editedRowIndex);
      Object.assign(this.statusReportFormOriginal, {
        weekEndingDate: this.statusReportForm.controls['weekEndingDate'].value,
      });
    }
    this.enableForm();
    this.clearDeliveryHours();
    this.setDeliveryHours();
    this.setHeaderData();
    this.enableStatusReportArrayForm();
    this.getDeliveryMilestoneData();
    this.milestoneDataSource = new MatTableDataSource<MilestoneDelivery>(
      this.deliveryOriginalValueForCancel
    );
    this.sortDescription(this.milestoneDataSource);
    this.getAgileData();
    this.agileDataSource = new MatTableDataSource<AgileSprint>(
      this.agileOriginalValueForCancel
    );
    this.sortDescription(this.agileDataSource);
    this.valuechange();
    this.changeCommentMandatoryStatus();
    if (this.saveButtonText === 'Update' && this.onCreateCopyCheck === false) {
      this.onEditHeader();


    }
  }

  onCreateNew() {
    this.saveButtonText = 'Save';
    this.onCreateCopyCheck = false;
    this.onCreateNewCheck = true;
    this.isEditingCurrentWeek = true;
    this.enableForm();
    this.setDefaultValueInFormControls();
    this.editModeShuffle();
    this.clearDeliveryHours();
    this.setDeliveryHours();
    this.enableStatusReportArrayForm();
    this.statusReportForm.controls['currentPhase'].setValue(
      this.existingPhase ?? this.currentPhaseOptions[0]
    );
    this.clearMilestonesTable();
  }

  setDefaultValueInFormControlsOfComments(commentValue) {
    this.statusReportForm.controls['csatComments'].setValue(commentValue);
    this.statusReportForm.controls['budgetComments'].setValue(commentValue);
    this.statusReportForm.controls['projectRiskComments'].setValue(
      commentValue
    );
    this.statusReportForm.controls['resourcesComments'].setValue(commentValue);
    this.statusReportForm.controls['scheduleComments'].setValue(commentValue);
  }

  setDefaultValueInFormControls() {
    const emptyString = '';
    const defaultStatus = 'Green';
    this.statusReportForm.controls['currentPhase'].setValue(emptyString);
    this.statusReportForm.controls['statusSummary'].setValue(emptyString);
    this.setDefaultValueInFormControlsOfComments(emptyString);
    this.statusReportForm.controls['csatStatus'].setValue(defaultStatus);
    this.statusReportForm.controls['budgetStatus'].setValue(defaultStatus);
    this.statusReportForm.controls['scheduleStatus'].setValue(defaultStatus);
    this.statusReportForm.controls['projectRiskStatus'].setValue(defaultStatus);
    this.statusReportForm.controls['resourcesStatus'].setValue(defaultStatus);
    this.statusReportForm.controls['overAllStatus'].setValue(defaultStatus);
    this.statusReportForm.controls['weekEndingDate'].setValue(
      this.getNextSaturdayDate()
    );
    this.getOverAllStatus();
    this.changeCommentMandatoryStatus();
  }

  getNextSaturdayDate() {
    const curr = new Date(); // get current date
    const first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
    const last = first + 6; // last day is the first day + 6
    return new Date(curr.setDate(last));
  }

  getConvertedPassDateForMilestone(currentDate) {
    const yyyy = currentDate.getFullYear().toString();
    const mm = (currentDate.getMonth() + 1).toString();
    const dd = currentDate.getDate().toString();
    const mmChars = mm.split('');
    const ddChars = dd.split('');
    return (
      yyyy +
      '-' +
      (mmChars[1] ? mm : '0' + mmChars[0]) +
      '-' +
      (ddChars[1] ? dd : '0' + ddChars[0])
    );
  }

  getConvertedWeekendForMilestone(convertedMilestoneWeekEndingDate) {
    const milestoneWeekEndingDAteArray = convertedMilestoneWeekEndingDate
      .toLocaleString()
      .split(':', 1);
    convertedMilestoneWeekEndingDate = String(
      milestoneWeekEndingDAteArray
    ).substr(0, 10);
    return convertedMilestoneWeekEndingDate;
  }

  getConvertedWeekEndingDate(date) {
    const weekEndingDAteArray = date.toLocaleString().split(',', 1);
    date = weekEndingDAteArray[0].replaceAll('/', '-');
    return date;
  }

  onCreateCopy() {
    const emptyString = '';
    this.onCreateCopyCheck = true;
    this.onCreateNewCheck = true;
    this.isEditingCurrentWeek = true;
    this.enableForm();
    this.statusReportForm.controls['weekEndingDate'].setValue(
      this.getNextSaturdayDate()
    );
    this.statusReportForm.controls['statusSummary'].setValue(emptyString);
    this.editModeShuffle();
    this.clearDeliveryHours();
    this.setDeliveryHours();
    this.enableStatusReportArrayForm();
    this.saveButtonText = 'Save';
  }

  getDeliveryMilestoneData() {
    this.clearMilestonesTable();
    const requestedWeekEndingDate = this.getWeekEndingDate();
    const milestoneRequestObject = {
      pageNumber: this.milestoneText == 'Agile Sprint' ? this.currentAgilePage : this.currentDeliveryPage,
      pageSize: this.milestoneText == 'Agile Sprint' ? this.postAgilePerPage : this.postDeliveryPerPage,
      projectId: Number(this.id),
      weekEndingDate: requestedWeekEndingDate,
    };
    this.statusReportService
      .getMilestoneDeliveryReport(milestoneRequestObject)
      .subscribe(
        (data1) => {
          if (this.milestoneTextChange) {
            this.milestoneText = data1.data[0].defaultMilestone;
            this.milestoneTextChange = false;
          }
          this.totalCountDelivery =
            data1.data[0].deliveryMilestoneDto.totalCount;
          this.deliveryData =
            data1.data[0].deliveryMilestoneDto.deliveryMilestoneReadOnlyDtoList;
          this.agileData =
            data1.data[0].agileSprintMilestoneDto.agileSprintMilestonesReadOnlyDtoList;
          this.totalCountAgile =
            data1.data[0].agileSprintMilestoneDto.totalCount;
          this.getMilestoneData();
          this.getAgileData();
        },
        (error) => {
          if (this.milestoneText === '') {
            this.milestoneText = 'Delivery';
          }
        }
      );
  }

  getMilestoneData() {
    if (this.deliveryData !== null && this.deliveryData !== undefined) {
      if (this.currentStatus !== 'All') {
        this.filterDeliveryData = this.deliveryData.filter(
          (project) => project.status === this.currentStatus
        );
      } else {
        this.filterDeliveryData = this.deliveryData
      }
    } else {
      this.filterDeliveryData = [];
    }
    this.milestoneDataSource = new MatTableDataSource<MilestoneDelivery>(
      this.filterDeliveryData
    );
    this.sortDescription(this.milestoneDataSource);
    this.deliveryOriginalValue = JSON.parse(
      JSON.stringify(this.milestoneDataSource.filteredData)
    );

    this.deliveryOriginalValueForCancel = JSON.parse(
      JSON.stringify(this.filterDeliveryData)
    );
    this.deliveryChangedValue = this.milestoneDataSource;
    // this.totalCountDelivery = this.milestoneDataSource.data.length;
    this.milestoneDataSource.sort = this.t1Sort;

    if (this.totalCountDelivery > 0) {
      this.tableHasDeliveryData = true;
    } else {
      this.tableHasDeliveryData = false;
    }
  }

  getAgileData() {
    if (this.agileData !== null && this.agileData !== undefined) {
      if (this.currentStatus !== 'All') {
        this.filterAgileData = this.agileData.filter(
          (project) => project.sprintStatus === this.currentStatus
        );
      } else {
        this.filterAgileData = this.agileData
      }
    } else {
      this.filterAgileData = [];
    }
    this.agileDataSource = new MatTableDataSource<AgileSprint>(
      this.filterAgileData
    );
    this.sortDescription(this.agileDataSource);
    this.agileOriginalValue = JSON.parse(
      JSON.stringify(this.agileDataSource.filteredData)
    );
    this.agileOriginalValueForCancel = JSON.parse(
      JSON.stringify(this.filterAgileData)
    );
    this.agileChangedValue = this.agileDataSource;
    // this.totalCountAgile = this.agileDataSource.data.length;
    this.agileDataSource.sort = this.t3Sort;

    if (this.totalCountAgile > 0) {
      this.tableHasAgileData = true;
    } else {
      this.tableHasAgileData = false;
    }
  }

  milestoneOnSelectionChange(event) {
    this.pushNewlyAddedMilestonesIntoDataOnTabChange();
    if (event.value === 'Delivery') {
      this.milestoneText = 'Delivery';
      this.getMilestoneData();
    } else {
      this.milestoneText = 'Agile Sprint';
      this.getAgileData();
    }
  }

  pushNewlyAddedMilestonesIntoDataOnTabChange() {
    this.agileData = this.agileData ?? [];
    this.deliveryData = this.deliveryData ?? [];
    const newlyAddedAgileData = this.getNewlyAddedMilestoneFilteredData(this.agileDataSource.filteredData) ?? [];
    newlyAddedAgileData.forEach(element => {
      if (this.agileData.indexOf(element) < 0) {
        this.agileData.push(element);
      }
    });
    const newlyAddedRecords = this.getNewlyAddedMilestoneFilteredData(this.milestoneDataSource.filteredData) ?? [];
    newlyAddedRecords.forEach(element => {
      if (this.deliveryData.indexOf(element) < 0) {
        this.deliveryData.push(element);
      }
    });
  }

  onSelectOfStatus(event) {
    this.pushNewlyAddedMilestonesIntoDataOnTabChange();
    this.currentStatus = event.value
    if (
      this.milestoneText === 'Delivery' &&
      this.deliveryData !== null &&
      this.deliveryData !== undefined
    ) {
      if (event.value !== 'All') {
        this.milestoneDataSource.data = this.deliveryData.filter(
          (project) => project.status === event.value
        );
      } else {
        this.milestoneDataSource.data = this.deliveryData;
      }
      // this.totalCountDelivery = this.milestoneDataSource.data.length;
    } else {
      if (this.agileData !== null && this.agileData !== undefined) {
        if (event.value !== 'All') {
          this.agileDataSource.data = this.agileData.filter(
            (project) => project.sprintStatus === event.value
          );
        } else {
          this.agileDataSource.data = this.agileData;
        }
        // this.totalCountAgile = this.agileDataSource.data.length;
      }
    }
  }

  onChangeMilestoneTable() {
    this.valuechange();
    this.checkMilestoneValidity();
    this.setMilestoneDateToUTCDate();

  }

  deleteTableRow(row) {
    if (this.milestoneAdd === true) {
      this.valueCheck = false;
    }
    if (this.onCreateNewCheck) {
      const dialogRef = this.dialog.open(DeleteDialogNotificationComponent);
      dialogRef.afterClosed().subscribe((data) => {
        if (data === true) {
          this.deleteMilestoneTableRow(row);
        }
      });
    }
  }

  deleteMilestoneTableRow(row) {
    row.active = false;
    this.statusReportForm.markAsDirty();
    if (this.milestoneText === 'Delivery') {
      this.filterDeliveryData = this.filterDeliveryData.filter(
        (activeRow) => activeRow.active === true
      );
      this.deletedDeliveryRows.push(row);
      // this.totalCountDelivery = this.filterDeliveryData.length;
      this.milestoneDataSource = new MatTableDataSource(
        this.filterDeliveryData
      );
      this.sortDescription(this.milestoneDataSource);
    } else if (this.milestoneText === 'Agile Sprint') {
      this.filterAgileData = this.filterAgileData.filter(
        (activeRow) => activeRow.active === true
      );
      this.deletedAgileRows.push(row);
      // this.totalCountAgile = this.filterAgileData.length;
      this.agileDataSource = new MatTableDataSource(this.filterAgileData);
      this.sortDescription(this.agileDataSource);
    }
  }

  findInDatasource(id) {
    if (this.milestoneText === 'Delivery') {
      for (const item of this.deliveryData) {
        if (item.id === id) {
          return item;
        }
      }
    } else {
      for (const item of this.agileData) {
        if (item.id === id) {
          return item;
        }
      }
    }
  }

  passDateCheck(row) {
    const currDate = new Date();
    const convertedCurrDate = this.getConvertedPassDateForMilestone(currDate);
    if (row.endDate < convertedCurrDate) {
      this.passDueDate = true;
    } else {
      this.passDueDate = false;
    }
    return this.passDueDate;
  }

  editModeShuffle() {
    this.isTableEditable = !this.isTableEditable;
  }

  onChangedDeliveryPage(pageData: PageEvent) {
    this.currentDeliveryPage = pageData.pageIndex;
    this.postDeliveryPerPage = pageData.pageSize;
    this.getDeliveryMilestoneData();
  }

  onChangedAgilePage(pageData: PageEvent) {
    this.currentAgilePage = pageData.pageIndex;
    this.postAgilePerPage = pageData.pageSize;
    this.getDeliveryMilestoneData();
  }

  onSecurityProfile(value) {
    if (value === 'No Updates Needed') {
      // call api to update security profile logs
      if (
        Number(this.id) !== undefined &&
        Number(this.id) &&
        this.id !== 'NaN'
      ) {
        this.statusReportService
          .updateStatusReportForPassDue(Number(this.id))
          .subscribe((data) => {
            this.securityProfileAlert = false;
            this.securityWarningProfileAlert = false;
            this.securityProfileStatus = 'Updated';
            this.statusReportForm.controls['securityProfileStatus'].setValue(
              'Updated'
            );
          });
        this.securityAlert = '' //to allow the next navigation to securityprofile after update
      }
    } else {
      if (this.id !== null && this.id && this.id !== undefined) {
        this.router.navigate(['dashboard/security-profile', Number(this.id)], {
          state: {
            projectId: Number(this.id),
            source: 'project-details',
          },
        });
      }
    }
  }

  onRiskSurvey() {
    if (this.id !== null && this.id && this.id !== undefined) {
      this.router.navigate(['dashboard/risk-survey', Number(this.id)], {
        state: {
          projectId: Number(this.id),
          source: 'project-details',
        },
      });
    }
  }

  onProjectDetails() {

    if (this.id !== null && this.id && this.id !== undefined) {
      this.router.navigate(['dashboard/project-details', this.id], {
        state: {
          source: 'project-details',
        },
      });
    }
  }

  onEditMode(tab) {
    if (
      this.isTableEditable === true &&
      this.statusReportForm.dirty &&
      !this.valueCheck
    ) {
      this.openModal(tab);
    } else {
      if (tab === '1') {
        this.onProjectDetails();
      } else {
        if (tab === '2') {
          this.onSecurityProfile(this.securityAlert);
        } else {
          if (tab === '3') {
            this.onRiskSurvey();
          }
        }
      }
    }
  }

  openModal(tab) {
    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = 'confirm-dialog-component';
    dialogConfig.height = '250px';
    dialogConfig.width = '600px';
    dialogConfig.data = {
      title: 'Notification',
      description:
        'You have unsaved changes in this ' +
        'Status Report' +
        ` tab. If you want to proceed to another tab without saving,
    Click 'Proceed' (or) click 'Cancel' to stay on the same tab.`,
    };
    const dialogRef = this.matDialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        if (tab === '1') {
          this.onProjectDetails();
        } else {
          if (tab === '2') {
            this.onSecurityProfile(this.securityAlert);
          } else {
            if (tab === '3') {
              this.onRiskSurvey();
            }
          }
        }
      }
    });
  }

  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    return (
      day !== 0 && day !== 1 && day !== 2 && day !== 3 && day !== 4 && day !== 5
    );
  }

  addMilestoneRow() {
    if (this.valueCheck === false) {
      this.milestoneAdd = true;
      this.valueCheck = true;
    } else {
      this.milestoneAdd = false;
    }
    if (this.milestoneText === 'Delivery') {
      const ELEMENT_DELIVERY_DATA = {
        active: true,
        comments: null,
        description: null,
        endDate: new Date(),
        startDate: new Date(),
        lastUpdatedAt: null,
        lastUpdatedBy: null,
        status: 'Active',
        type: null,
        id: null,
        weekEndingDate: this.getWeekEndingDate(),
      };
      if (
        this.filterDeliveryData === null ||
        this.filterDeliveryData === undefined
      ) {
        this.filterDeliveryData.push(ELEMENT_DELIVERY_DATA);
      } else {
        this.filterDeliveryData.unshift(ELEMENT_DELIVERY_DATA);
      }
      this.milestoneDataSource = new MatTableDataSource<MilestoneDelivery>(
        this.filterDeliveryData
      );
      // this.totalCountDelivery = this.milestoneDataSource.data.length;
      this.checkMilestoneValidity();
      this.sortDescription(this.milestoneDataSource);
    } else if (this.milestoneText === 'Agile Sprint') {
      const ELEMENT_AGILE_SPRINT_DATA = {
        active: true,
        addedStories: null,
        capacity: null,
        committedStoryPoints: null,
        deliveredStories: null,
        deliveredStoryPoints: null,
        estimate: null,
        id: null,
        lastUpdatedAt: null,
        lastUpdatedBy: null,
        removedStories: null,
        sprint: null,
        sprintStatus: 'Active',
        startDate: new Date(),
        endDate: new Date(),
        track: null,
        weekEndingDate: this.getWeekEndingDate(),
      };
      if (this.filterAgileData === null || this.filterAgileData === undefined) {
        this.filterAgileData.push(ELEMENT_AGILE_SPRINT_DATA);
      } else {
        this.filterAgileData.unshift(ELEMENT_AGILE_SPRINT_DATA);
      }
      this.agileDataSource = new MatTableDataSource<AgileSprint>(
        this.filterAgileData
      );
      // this.totalCountAgile = this.agileDataSource.data.length;
      this.sortDescription(this.agileDataSource);
    }
  }

  onAlert() {
    if (this.securityProfileStatus === 'Not Completed') {
      this.securityProfileAlert = true;
      this.securityWarningProfileAlert = true;
      this.securityAlert = 'Go to Security Profile ->';
      this.securityAlertMessage =
        Constants.SECURITY_PROFILE_ERROR_NOT_COMPLETED;
    } else if (this.securityProfileStatus === 'Past Due') {
      this.securityProfileAlert = true;
      this.securityWarningProfileAlert = true;
      this.securityAlert = 'No Updates Needed';
      this.securityAlertMessage = Constants.SECURITY_PROFILE_ERROR_PASS_DUE;
    }
    if (this.deliveryRiskIndicator === 'Not Completed') {
      this.deliveryRiskIndicatorAlert = true;
      this.riskIndicatorAlert = 'Go to Risk Survey ->';
      this.riskIndicatorAlertMessage =
        Constants.DELIVERY_RISK_INDICATOR_ERROR_NOT_COMPLETED;
    }
  }

  sortDescription(datasource) {
    datasource.sortingDataAccessor = (data, sortHeaderId) =>
      data[sortHeaderId].toLocaleLowerCase?.();
  }

  sortDate() {
    this.statusReportArray.sortingDataAccessor = (
      item,
      property
    ): string | number => {
      switch (property) {
        case 'weekEndingDate':
          return Number(new Date(item.weekEndingDate));
        default:
          return item[property];
      }
    };
  }

  getMilestoneTypeName(id) {
    const typeName = '';
    for (const item of this.typeOptions) {
      if (item.id === id) {
        return item.type;
      }
    }
    return typeName;
  }

  getAllDeliveryMilestoneTypes() {
    this.statusReportService.getDeliveryMilestoneTypes().subscribe((data) => {
      this.typeOptions = data.data;
    });
  }

  changeCommentMandatoryStatus() {
    const derivedScheduleStatus = this.statusReportForm.controls[
      'scheduleStatus'
    ].value;
    const derivedCsatStatus = this.statusReportForm.controls['csatStatus']
      .value;
    const derivedBudgetStatus = this.statusReportForm.controls['budgetStatus']
      .value;
    const derivedProjectRiskStatus = this.statusReportForm.controls[
      'projectRiskStatus'
    ].value;
    const derivedResourcesStatus = this.statusReportForm.controls[
      'resourcesStatus'
    ].value;

    this.scheduleCommentsCheck = derivedScheduleStatus !== 'Green';
    this.csatCommentsCheck = derivedCsatStatus !== 'Green';
    this.budgetCommentsCheck = derivedBudgetStatus !== 'Green';
    this.projectRiskCommentsCheck = derivedProjectRiskStatus !== 'Green';
    this.resourcesCommentsCheck = derivedResourcesStatus !== 'Green';
  }

  checkMilestoneValidity() {
    this.isMielstoneInvalid = false;
    this.milestoneDataSource.data.forEach((milestone) => {
      if (!milestone.description) {
        this.isMielstoneInvalid = true;
        return;
      }
    });
  }

  getWeekEndingDate() {
    const date = new Date(this.statusReportForm.controls['weekEndingDate'].value);
    const offset = date.getTimezoneOffset();
    if (offset < 0) {
      date.setHours(12, 0, 0);
    }
    return date.toISOString().substring(0, 10);
  }


  convertISOStringToDateString(date) {
    date = new Date(date);
    const offset = date.getTimezoneOffset?.();
    if (offset === undefined) return date;
    if (offset < 0) {
      date.setHours(12, 0, 0);
    }
    return date.toISOString().substring(0, 10);
  }


  setMilestoneDateToUTCDate() {
    this.milestoneDataSource.data.forEach((milestone) => {
      if (milestone.startDate) {
        milestone.startDate = this.convertISOStringToDateString(milestone.startDate);
      }
      if (milestone.endDate) {
        milestone.endDate = this.convertISOStringToDateString(milestone.endDate);
      }
    });
    this.agileDataSource.data.forEach((agileData) => {
      if (agileData.startDate) {
        agileData.startDate = this.convertISOStringToDateString(new Date(agileData.startDate));
      }
      if (agileData.endDate) {
        agileData.endDate = this.convertISOStringToDateString(new Date(agileData.endDate));
      }
    });
  }

  removeWeekEndingDateAndIdsFromMilestoneDate(): {
    deliveryMilestoneDto: any;
    agileSprintMilestoneDto: any;
    projectId: number;
    weekEndingDate: string;
  } {
    const lastUsedMilestoneText = this.milestoneText;
    this.milestoneOnSelectionChange({ value: 'Delivery' });
    this.onSelectOfStatus({ value: 'All' });
    const copiedMilestoneData = this.milestoneDataSource.filteredData.map((milestone: any) => {
      return {
        active: true,
        comments: milestone.comments,
        description: milestone.description,
        endDate: milestone.endDate,
        startDate: milestone.startDate,
        lastUpdatedAt: milestone.lastUpdatedAt,
        lastUpdatedBy: milestone.lastUpdatedBy,
        status: milestone.status,
        typeId: milestone.typeId,
        id: null,
        weekEndingDate: null,
      };
    });
    this.milestoneOnSelectionChange({ value: 'Agile Sprint' });
    this.onSelectOfStatus({ value: 'All' });
    const copiedAgileMilestoneData = this.agileDataSource.filteredData.map((agileMilestone: AgileSprint) => {
      return {
        active: true,
        addedStories: agileMilestone.addedStories,
        capacity: agileMilestone.capacity,
        committedStoryPoints: agileMilestone.committedStoryPoints,
        deliveredStories: agileMilestone.deliveredStories,
        deliveredStoryPoints: agileMilestone.deliveredStoryPoints,
        estimate: agileMilestone.estimate,
        id: null,
        lastUpdatedAt: agileMilestone.lastUpdatedAt,
        lastUpdatedBy: agileMilestone.lastUpdatedBy,
        removedStories: agileMilestone.removedStories,
        sprint: agileMilestone.sprint,
        sprintStatus: agileMilestone.sprintStatus,
        startDate: agileMilestone.startDate,
        endDate: agileMilestone.endDate,
        track: agileMilestone.track,
        weekEndingDate: null,
        agileSprintActions: agileMilestone.agileSprintActions,
        goalMet: agileMilestone.goalMet
      };
    });
    this.milestoneOnSelectionChange({ value: lastUsedMilestoneText });
    this.onSelectOfStatus({ value: 'Active' });
    return {
      deliveryMilestoneDto: copiedMilestoneData,
      agileSprintMilestoneDto: copiedAgileMilestoneData,
      projectId: Number(this.id),
      weekEndingDate: this.getWeekEndingDate()
    }
  }

  getNewlyAddedMilestoneFilteredData(filteredData) {
    return filteredData.filter((m) => m.id === null);
  }

  clearMilestonesTable() {
    // clear delivery milestones data.
    this.deliveryData = [];
    this.filterDeliveryData = [];
    this.milestoneDataSource = new MatTableDataSource<MilestoneDelivery>(
      this.filterDeliveryData
    );
    this.sortDescription(this.milestoneDataSource);
    this.deliveryOriginalValue = JSON.parse(
      JSON.stringify(this.milestoneDataSource.filteredData)
    );

    this.deliveryOriginalValueForCancel = JSON.parse(
      JSON.stringify(this.filterDeliveryData)
    );
    this.deliveryChangedValue = this.milestoneDataSource;
    // this.totalCountDelivery = this.milestoneDataSource.data.length;
    this.milestoneDataSource.sort = this.t1Sort;

    if (this.totalCountDelivery > 0) {
      this.tableHasDeliveryData = true;
    } else {
      this.tableHasDeliveryData = false;
    }

    // clear agile milestones data
    this.agileData = [];
    this.filterAgileData = [];
    this.agileDataSource = new MatTableDataSource<AgileSprint>(
      this.filterAgileData
    );
    this.sortDescription(this.agileDataSource);
    this.agileOriginalValue = JSON.parse(
      JSON.stringify(this.agileDataSource.filteredData)
    );
    this.agileOriginalValueForCancel = JSON.parse(
      JSON.stringify(this.filterAgileData)
    );
    this.agileChangedValue = this.agileDataSource;
    // this.totalCountAgile = this.agileDataSource.data.length;
    this.agileDataSource.sort = this.t3Sort;

    if (this.totalCountAgile > 0) {
      this.tableHasAgileData = true;
    } else {
      this.tableHasAgileData = false;
    }
  }

  isNumberKey(evt) {
    const charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
      evt.preventDefault();
  }

}

