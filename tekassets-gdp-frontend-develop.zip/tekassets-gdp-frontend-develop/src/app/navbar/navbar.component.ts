import { AfterViewInit, Component, Input, OnDestroy, OnInit, } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { map, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import {
  IconDefinition,
  faQuestionCircle,
} from '@fortawesome/free-regular-svg-icons';
import { faAngleDown, faAngleRight, faFileExcel, faHome, faIdCard, faFilePdf, faBars, faArrowCircleRight } from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';
import { AuthGuardService } from '../services/auth_guard.service';
import { AccessLevel } from '../enums/access_level';
import { environment } from '../../environments/environment';
import { HelpGuideService } from '../services/help-guide.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { NotificationDialogComponent } from '../notification-dialog/notification-dialog.component';
import { MsalService } from '@azure/msal-angular';
import { SharedService } from '../services/shared.service';
import { DemoService } from '../services/demo.service';



import { Constants } from '../model/Constants';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  toggleFirst = 0;
  showAfterCollapse = true;
  showBeforeCollapse = false;
  date = new Date();
  // icons
  faQuestionCircle: IconDefinition = faQuestionCircle;
  faHome: IconDefinition = faHome;
  faAngleDown: IconDefinition = faAngleDown;
  faAngleRight: IconDefinition = faAngleRight;
  faFileExcel: IconDefinition = faFileExcel;
  faIdCard: IconDefinition = faIdCard;
  faFilePdf: IconDefinition = faFilePdf;
  faMenu: IconDefinition = faBars;
  faArrowCircleRight: IconDefinition = faArrowCircleRight;
  linkToServiceNow;
  operatingCompanyDropdown: any[];


  public currentUser = 'GDP User';
  public currentUserMail;
  public currentUserRole;
  adminTabVisible = false;
  globaleditvisible = false;
  opcoTabVisible = false;
  selectedOperatingCompany:string
  
  public widthSideBar = 47;
  public widthSideBarExpanded = 47;
  public widthSideBarCollapsed = 200;
  @Input() public parentData;

  isHandset$: Observable<boolean> = this.breakpointObserver
    .observe(Breakpoints.Handset)
    .pipe(
      map((result) => result.matches),
      shareReplay()
    );

  selectedOpcoId: string = null;
  opco_id : string;
  currentrole : any;

 
  opcoTabVisibleAdmin: boolean;
  opcoTabVisibleExecutive: boolean;
  options: any[];
  sharedDataNavbar: any;

  constructor(
    private breakpointObserver: BreakpointObserver,
    public router: Router,
    private authService: AuthGuardService,
    private helpGuideService: HelpGuideService,
    public dialog: MatDialog,
    private msalService: MsalService,
    private demoService:DemoService,
    private sharedService:SharedService
  ) { 
   
    this.sharedDataNavbar=this.sharedService.navbarObserver.subscribe((data)=>{     
      if(this.sharedDataNavbar){
      this.selectedOpcoId=this.sharedService.sharedDataNavbar.value;          
      }     
      })

  }
  async ngOnInit() {
  this.currentUser = await this.authService.getUserName();
  this.currentUser = this.currentUser.replace(/(,)\s/g, "$1"); // removing space after ,
  this.adminTabVisible = await this.authService.doesUserHaveAccessToRole(
    AccessLevel.ADMIN_ACCESS
  );
   await this.authService.doesUserHaveAccessToRole(
    AccessLevel.EDIT_ACCESS || AccessLevel.VIEWER_ACCESS
  );
    if(this.selectedOpcoId===null||this.selectedOpcoId===undefined){
      if(Constants.CURRENT_ROLE==='Executive'||Constants.CURRENT_ROLE==='Admin'){
        this.opco_id='1'
      }else{
      this.opco_id=Constants.OPCO_ID; 
      }    
    }
    else{
      this.opco_id=this.selectedOpcoId;
    }
  this.opcoTabVisibleExecutive = await this.authService.doesUserHaveAccessToRole(
    AccessLevel.EXECUTIVE_ACCESS
  );
  this.opcoTabVisibleAdmin=await this.authService.doesUserHaveAccessToRole(
    AccessLevel.ADMIN_ACCESS
  );
  if(this.opcoTabVisibleAdmin||this.opcoTabVisibleExecutive){
  this.getOpcoDropdown();
  this.opcoTabVisible=(this.opcoTabVisibleAdmin||this.opcoTabVisibleExecutive)
  }

  this.linkToServiceNow = environment.linkToServiceNow;
  this.currentUserMail = await this.authService.getUserMail();
  this.currentUserRole = this.authService.currentUserRole().subscribe((data) => {
    this.currentUserRole = data[0].substring(5);
  });
  this.currentrole = Constants.CURRENT_ROLE; 
}
 
 
  onOpcoSelection(id:any){
    this.selectedOpcoId=id;
    this.sharedService.emitData(id);  
    if(Constants.CURRENT_TAB==='dashboard'){
      localStorage.setItem('opcoId','');
      this.router.navigate(['dashboard']);
    }
    else if(Constants.CURRENT_TAB==='reports'){
      this.router.navigate(['report']);
    }else if(Constants.CURRENT_TAB==='employee-details'){
      this.router.navigate(['employee-details']);
    }else if(Constants.CURRENT_TAB==='admin'){

      this.router.navigate(['admin']);
    }else if(Constants.CURRENT_TAB===''){

      this.router.navigate(['dashboard']);
    }
  }
  /**
   * expanding and collapsing side nav
   */
  toggleSideBar() {
    if (this.widthSideBar === this.widthSideBarExpanded) {
      this.widthSideBar = this.widthSideBarCollapsed;
    } else {
      this.widthSideBar = this.widthSideBarExpanded;
    }

    if (this.toggleFirst === 1) {
      this.toggleFirst = 0;
      this.showAfterCollapse = true;
      this.showBeforeCollapse = false;
    } else {
      this.showAfterCollapse = false;
      this.showBeforeCollapse = true;
      this.toggleFirst = 1;
    }
  }
  getOpcoDropdown() {
    this.demoService.getOpcoDropdown()
      .subscribe((data) => {
        this.operatingCompanyDropdown = data.data;
        for(let option of this.operatingCompanyDropdown){
          console.log(this.opco_id)
          if(option.id==this.opco_id){
                this.selectedOperatingCompany=option.opcoName
                console.log(this.selectedOperatingCompany)
            }
          }
      });
  }
  /**
   * for different options for admin tab
   * @param value
   */

  /**
   * downloading user guide
   */
  downloadHelpGuide() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      value: 'User Guide is downloading',
      source: 'project-updated',
    };
    this.dialog.open(NotificationDialogComponent, dialogConfig);
    this.helpGuideService.downloadHelpGuidePDF().subscribe((data) => {
      const blob = new Blob([data], {
        type: 'application/pdf',
      });
      if (window.navigator && window.navigator.msSaveBlob) {
        window.navigator.msSaveBlob(blob);
        return;
      }
      const sheetUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = sheetUrl;
      link.download = 'GDPUserGuide.pdf';
      link.dispatchEvent(
        new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window,
        })
      );
    });
  }
  /**
   * logging out existing user
   */
  logout() {
    this.msalService.logout();
  }


}
