import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttachOpportunityToExistingProjectComponent } from './attach-opportunity-to-existing-project.component';

describe('AttachOpportunityToExistingProjectComponent', () => {
  let component: AttachOpportunityToExistingProjectComponent;
  let fixture: ComponentFixture<AttachOpportunityToExistingProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttachOpportunityToExistingProjectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttachOpportunityToExistingProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
