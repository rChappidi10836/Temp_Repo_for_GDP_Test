import { Component, OnInit, Inject, ViewChild, NgZone, AfterViewInit } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogConfig,
} from '@angular/material/dialog';
import { FormBuilder, Validators } from '@angular/forms';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { debounceTime, take } from 'rxjs/operators';
import { IconDefinition, faTimes } from '@fortawesome/free-solid-svg-icons';
// tslint:disable-next-line: max-line-length
import { ProjectAttachedSuccessfullyDialogComponent } from '../project-attached-successfully-dialog/project-attached-successfully-dialog.component';
import { OpportunityService } from '../services/opportunity.service';
import { MatAutocompleteSelectedEvent, MatAutocompleteTrigger } from '@angular/material/autocomplete';


export class AttachToExistingProjectModel {
  opportunityId: number;
  projectId: number;
  targetTechnologyPlatform: string

  public AttachToExistingProjectModel() {
    this.opportunityId = null;
    this.projectId = null;
    this.targetTechnologyPlatform = null;
  }
}


@Component({
  selector: 'app-attach-opportunity-to-existing-project',
  templateUrl: './attach-opportunity-to-existing-project.component.html',
  styleUrls: ['./attach-opportunity-to-existing-project.component.scss'],
})
export class AttachOpportunityToExistingProjectComponent implements OnInit, AfterViewInit {
  faTimes: IconDefinition = faTimes;

  opportunityName: string;
  opportunityPk: number;
  allProjectDetails: any[];
  allClientNames: any[];
  filteredClientNames: any[];
  allProjectNames: any[];
  filteredProjectNames: any[];
  selectedClient: any[];
  selectedProjectId: number;
  opportunityToBeAttached: AttachToExistingProjectModel;
  ttp: any;


  constructor(
    private opportunityService: OpportunityService,
    public dialog: MatDialog,
    private ngZone: NgZone,
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<
      AttachOpportunityToExistingProjectComponent
    >,
    @Inject(MAT_DIALOG_DATA) data
  ) {
    this.opportunityName = data.rowData.opportunityName;
    this.opportunityPk = data.rowData.opportunityPk;
    this.ttp = data.rowData.target_Technology_Platform;
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;
  @ViewChild('clientInput') clientInput: any;
  @ViewChild('projectInput') projectInput: any;
  @ViewChild(MatAutocompleteTrigger) autocompleteTrigger: MatAutocompleteTrigger;

  attachToExistingProjectForm = this.fb.group({
    selectedOpportunity: [{ value: this.opportunityName, disabled: true }],
    clientNameFilter: [null],
    project: [null, Validators.required],
  });



  ngOnInit() {
    this.opportunityToBeAttached = new AttachToExistingProjectModel();
    this.getAllProjectDetails();
    this.attachToExistingProjectForm.controls['selectedOpportunity'].setValue(
      this.opportunityName
    );
    this.initForm();
  }

  ngAfterViewInit() {
    this.clientInput.nativeElement.addEventListener('focus', () => {
      this.openAutocomplete();
    });
    this.projectInput.nativeElement.addEventListener('focus2', () => {
      this.openAutocomplete();
    });
  }

  initForm() {
    this.attachToExistingProjectForm.get('clientNameFilter').valueChanges
      .pipe(debounceTime(300))
      .subscribe(response => {
        this.filterClientData(response);
      });
    this.attachToExistingProjectForm.get('project').valueChanges
      .pipe(debounceTime(300))
      .subscribe(response => {
        this.filterProjectData(response);
      });
  }

  filterClientData(enteredData) {
    if (!enteredData) {
      this.resetProjectList();
      this.filteredClientNames = this.allClientNames;
    } else {
      this.filteredClientNames = this.allClientNames.filter((item) => {
        return item.name.toLowerCase().indexOf(enteredData.toLowerCase()) > -1
      })
    }
  }

  filterProjectData(enteredData) {
    if (!enteredData) {
      this.filteredProjectNames = this.allProjectNames;
    } else {
      this.filteredProjectNames = this.allProjectNames.filter((item) => {
        return item.name.toLowerCase().indexOf(enteredData.toLowerCase()) > -1
      })
    }
  }

  openAutocomplete() {
    setTimeout(() => {
      this.autocompleteTrigger.openPanel();
    }, 0);
  }

  Onselect(event: MatAutocompleteSelectedEvent) {
    this.attachToExistingProjectForm.controls['project'].setValue(null);
    if (event.option.id !== undefined && event.option.id) {
      this.selectedClient = this.allProjectDetails.filter(
        (project) => project.clientId === event.option.id
      );
      this.allProjectNames = this.selectedClient.map((eachProject) => {
        return { name: eachProject.projectName, id: eachProject.projectId };
      });
      this.allProjectNames = this.removeDuplicates(this.allProjectNames, 'name');
      this.allProjectNames = this.allProjectNames.sort((a, b) => a.name.localeCompare(b.name));
      this.filteredProjectNames = this.allProjectNames;
    }
    else {
      this.resetProjectList();
    }
  }

  resetProjectList() {
    this.allProjectNames = this.allProjectDetails.map((eachProject) => {
      return { name: eachProject.projectName, id: eachProject.projectId };
    });
    this.allProjectNames = this.removeDuplicates(this.allProjectNames, 'name');
    this.allProjectNames = this.allProjectNames.sort((a, b) => a.name.localeCompare(b.name));
    this.filteredProjectNames = this.allProjectNames;
  }

  OnProjectselect(event) {
    this.selectedProjectId = event.option.id;
  }

  getAllProjectDetails() {
    this.opportunityService.getAttachOpportunityDropdown().subscribe((data) => {
      this.allProjectDetails = data.data;
      this.allClientNames = this.allProjectDetails.map((eachProject) => {
        return { name: eachProject.clientName, id: eachProject.clientId };
      });
      this.allClientNames = this.removeDuplicates(this.allClientNames, 'name');
      this.filteredClientNames = this.allClientNames;

      this.allProjectNames = this.allProjectDetails.map((eachProject) => {
        return { name: eachProject.projectName, id: eachProject.projectId };
      });
      this.allProjectNames = this.removeDuplicates(this.allProjectNames, 'name');
      this.allProjectNames = this.allProjectNames.sort((a, b) => a.name.localeCompare(b.name));
      this.filteredProjectNames = this.allProjectNames;
    });
  }

  removeDuplicates(originalArray, prop) {
    const newArray = [];
    const lookupObject = {};

    // tslint:disable-next-line: forin
    for (const i in originalArray) {
      lookupObject[originalArray[i][prop]] = originalArray[i];
    }

    // tslint:disable-next-line: forin
    for (const i in lookupObject) {
      newArray.push(lookupObject[i]);
    }
    return newArray;
  }


  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable
      .pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  onClose() {
    this.dialogRef.close();
  }

  OnAttachOpportunity() {
    if (this.opportunityPk !== undefined && this.opportunityPk) {
      this.opportunityToBeAttached.opportunityId = this.opportunityPk;
    }
    if (this.selectedProjectId !== undefined && this.selectedProjectId) {
      this.opportunityToBeAttached.projectId = this.selectedProjectId;
    }
    if (this.ttp !== undefined && this.ttp) {
      this.opportunityToBeAttached.targetTechnologyPlatform = this.ttp
    }
    this.opportunityService.attachOpportunityToExistingProject(this.opportunityToBeAttached).subscribe(
      (data) => {
        this.dialogRef.close();
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = { projectId: this.selectedProjectId };
        dialogConfig.autoFocus = true;
        dialogConfig.width = '567px';
        dialogConfig.height = '190px';
        dialogConfig.disableClose = true;
        const dialogRef = this.dialog.open(
          ProjectAttachedSuccessfullyDialogComponent,
          dialogConfig
        );
      }
    );
  }
}
