import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavbarComponent } from './navbar/navbar.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { DataTableComponent } from './data-table/data-table.component';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { FormComponent } from './form/form.component';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DemoService } from './services/demo.service';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProjectFormComponent } from './project-form/project-form.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { OpportunitiesComponent } from './opportunities/opportunities.component';
import { MdePopoverModule } from '@material-extended/mde';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CreateProjectComponent } from './create-project/create-project.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { CreateProjectDialogComponent } from './create-project-dialog/create-project-dialog.component';
import { MatDialogModule } from '@angular/material/dialog';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { UserSearchDialogComponent } from './user-search-dialog/user-search-dialog.component';
import { UserSearchResetDialogComponent } from './user-search-reset-dialog/user-search-reset-dialog.component';
import { NotificationDialogComponent } from './notification-dialog/notification-dialog.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { MsalModule, MsalInterceptor } from '@azure/msal-angular';

// tslint:disable-next-line: max-line-length
import { AttachOpportunityToExistingProjectComponent } from './attach-opportunity-to-existing-project/attach-opportunity-to-existing-project.component';
import { TextFieldModule } from '@angular/cdk/text-field';
// tslint:disable-next-line: max-line-length
import { ProjectAttachedSuccessfullyDialogComponent } from './project-attached-successfully-dialog/project-attached-successfully-dialog.component';
import { RiskSurveyComponent } from './risk-survey/risk-survey.component';
import { StatusReportComponent } from './status-report/status-report.component';
import { SecurityProfileComponent } from './security-profile/security-profile.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { DeleteDialogNotificationComponent } from './delete-dialog-notification/delete-dialog-notification.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ManageAccessComponent } from './manage-access/manage-access.component';
import { AdminComponentsComponent } from './admin-components/admin-components.component';
import { AddEditAdminComponentsComponent } from './add-edit-admin-components/add-edit-admin-components.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { AdminNotificationComponent } from './admin-notification/admin-notification.component';
import { ManageAccessUserComponent } from './manage-access-user/manage-access-user.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { LoginComponent } from './login/login.component';
import { ReportLogComponent } from './report-log/report-log.component';
const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { apiUri, environment } from 'src/environments/environment';
import { AuthGuardService } from './services/auth_guard.service';
import { EngagementSoftDeleteComponent } from './engagement-soft-delete/engagement-soft-delete.component';
import { PopUpComponent } from './pop-up/pop-up.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { LoadspinnerInterceptor } from './loadspinner.interceptor';
import { SummarypopupComponent } from './summarypopup/summarypopup.component';
import { StylePaginatorDirective } from './directive/stylePaginatorDirective';
import { AdminOptionsComponent } from './admin-options/admin-options.component';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { SafeHtml } from './pipe/domSanitizer';
import { SharedService } from './services/shared.service';
import { IdNotPresentDialogComponent } from './id-not-present-dialog/id-not-present-dialog.component';
import { SecurityExcelDialogComponent } from './security-excel-dialog/security-excel-dialog.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    DashboardComponent,
    DataTableComponent,
    FormComponent,
    PageNotFoundComponent,
    ProjectFormComponent,
    OpportunitiesComponent,
    CreateProjectComponent,
    CreateProjectDialogComponent,
    BreadcrumbComponent,
    UserSearchDialogComponent,
    UserSearchResetDialogComponent,
    NotificationDialogComponent,
    AttachOpportunityToExistingProjectComponent,
    ProjectAttachedSuccessfullyDialogComponent,
    RiskSurveyComponent,
    StatusReportComponent,
    SecurityProfileComponent,
    ConfirmDialogComponent,
    DeleteDialogNotificationComponent,
    ManageAccessComponent,
    AdminComponentsComponent,
    AddEditAdminComponentsComponent,
    AdminNotificationComponent,
    ManageAccessUserComponent,
    AddEmployeeComponent,
    LoginComponent,
    ReportLogComponent,
    EngagementSoftDeleteComponent,
    PopUpComponent,
    SpinnerComponent,
    SummarypopupComponent,
    StylePaginatorDirective,
    AdminOptionsComponent,
    SafeHtml,
    IdNotPresentDialogComponent,
    SecurityExcelDialogComponent,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatPaginatorModule,
    FontAwesomeModule,
    NgxMatSelectSearchModule,
    MatAutocompleteModule,
    MdePopoverModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatDialogModule,
    TextFieldModule,
    MatExpansionModule,
    MatSnackBarModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    LazyLoadImageModule,
    MsalModule.forRoot({
      auth: environment.authProperties,
      cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: isIE, // Set to true for Internet Explorer 11
      },
    }, {
      popUp: !isIE,
      consentScopes: [
        'user.read',
        'openid',
        'profile',
      ],
      unprotectedResources: [],
      protectedResourceMap: [
        [apiUri, [
          'openid',
        ]],
        ['https://graph.microsoft.com/v1.0/me', ['user.read']]
      ],
      extraQueryParameters: {}
    })

  ],
  providers:
    [SharedService, DemoService, AuthGuardService, {
      provide: HTTP_INTERCEPTORS,
      useClass: LoadspinnerInterceptor,
      multi: true
    },
      {
        provide: HTTP_INTERCEPTORS,
        useClass: MsalInterceptor,
        multi: true
      }
    ],
  bootstrap: [AppComponent],
})
export class AppModule { }
