import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-admin-notification',
  templateUrl: './admin-notification.component.html',
  styleUrls: ['./admin-notification.component.scss'],
})
export class AdminNotificationComponent implements OnInit {
  clearValue = false;
  message: string;
  source: string;
  showOKButton = true;

  constructor(
    private dialogRef: MatDialogRef<AdminNotificationComponent>,
    @Inject(MAT_DIALOG_DATA) data
  ) {
    this.message = data.value;
    this.source = data.source;
  }

  ngOnInit(): void {
    if (this.source === 'requestedTab-delete') {
      this.showOKButton = true;
    } else {
      this.showOKButton = false;
    }
  }
/**
 * for updating
 */
  onClickOfOk() {
    this.dialogRef.close();
  }
/**
 * for deletion
 */
  onClickOfYes() {
    this.clearValue = true;
    this.dialogRef.close(this.clearValue);
  }
/**
 * for deletion
 */
  onClickOfNo() {
    this.clearValue = false;
    this.dialogRef.close(this.clearValue);
  }
}
