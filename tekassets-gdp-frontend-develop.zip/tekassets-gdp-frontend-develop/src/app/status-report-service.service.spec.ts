import { TestBed } from '@angular/core/testing';

import { StatusReportServiceService } from './services/status-report.service';

describe('StatusReportServiceService', () => {
  let service: StatusReportServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StatusReportServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
