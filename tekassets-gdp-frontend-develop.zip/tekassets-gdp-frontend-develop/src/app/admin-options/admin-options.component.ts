import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { HelpGuideService } from '../services/help-guide.service';
import { NotificationDialogComponent } from '../notification-dialog/notification-dialog.component';
import { SvgService } from '../services/svgImages.service';
import { Constants } from '../model/Constants';

@Component({
  selector: 'app-admin-options',
  templateUrl: './admin-options.component.html',
  styleUrls: ['./admin-options.component.scss']
})
export class AdminOptionsComponent implements OnInit {
  loaded: number = 0;
  imgs = new Array();
  svgUrls: string[] = [
    './assets/images/Practice.svg', './assets/images/DeliveryModel.svg', './assets/images/ServiceType.svg',
    './assets/images/LocationOfDelivery.svg', './assets/images/ContractType.svg', './assets/images/SalesOrganization.svg',
    './assets/images/StaffingSalesRegion.svg', './assets/images/EngagementSoftDelete.svg', './assets/images/MilestoneTypes.svg',
    './assets/images/AccountName.svg', './assets/images/ProjectArchive.svg'];
  // Add more SVG URLs as needed
  loading: boolean = true;
  svgs: string[] = [];
  constructor(public router: Router,
    public dialog: MatDialog,
    private helpGuideService: HelpGuideService, private svgService: SvgService
  ) {

  }
  ngOnInit(): void {
    Constants.CURRENT_TAB='admin';
    this.loadSvgImages();
  }
  softDelete() {

    this.router.navigate(['admin/bulk/engagementSoftDelete']
    );
  }

  practiceEngagement(value) {
    if (value === 'practiceEngagement') {
      this.router.navigate(['/admin/practiceEngagement'], {
        state: {
          requestedTab: 'practiceEngagement',
        },
      });
    } else if (value === 'deliveryModel') {
      this.router.navigate(['/admin/deliveryModel'], {
        state: {
          requestedTab: 'deliveryModel',
        },
      });
    } else if (value === 'serviceType') {
      this.router.navigate(['/admin/serviceType'], {
        state: {
          requestedTab: 'serviceType',
        },
      });
    } else if (value === 'locationOfServices') {
      this.router.navigate(['/admin/locationOfServices'], {
        state: {
          requestedTab: 'locationOfServices',
        },
      });
    } else if (value === 'contractType') {
      this.router.navigate(['/admin/contractType'], {
        state: {
          requestedTab: 'contractType',
        },
      });
    } else if (value === 'salesOrganization') {
      this.router.navigate(['/admin/salesOrganization'], {
        state: {
          requestedTab: 'salesOrganization',
        },
      });
    } else if (value === 'staffingSalesRegion') {
      this.router.navigate(['/admin/staffingSalesRegion'], {
        state: {
          requestedTab: 'staffingSalesRegion',
        },
      });
    } else if (value === 'deliveryMilestones') {
      this.router.navigate(['/admin/deliveryMilestones'], {
        state: {
          requestedTab: 'deliveryMilestones',
        },
      });
    } else if (value === 'accountName') {
      this.router.navigate(['/admin/accountName'], {
        state: {
          requestedTab: 'accountName',
        },
      });
    }
  }

  downloadArchiveDate() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      value: 'Project Archive is downloading',
      source: 'project-updated',
    };
    this.dialog.open(NotificationDialogComponent, dialogConfig);
    this.helpGuideService.downloadProjectArchive().subscribe((data) => {
      const blob = new Blob([data], {
        type:
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      if (window.navigator && window.navigator.msSaveBlob) {
        window.navigator.msSaveBlob(blob);
        return;
      }
      const sheetUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = sheetUrl;
      link.download = 'ProjectArchive.xlsx';
      link.dispatchEvent(
        new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window,
        })
      );
    });
  }

  cards = [
    {
      title: 'Practice',
      description: 'Defines the new practices based on identification.',
      img: './assets/images/Practice.svg'
    },
    {
      title: 'Delivery Model',
      description: 'The high-level categorization of the services provided to a customer.',
      img: './assets/images/DeliveryModel.svg'
    },
    {
      title: 'Service Type',
      description: 'A defined offering delivered by a practice.',
      img: './assets/images/ServiceType.svg'
    },
    {
      title: 'Location of Delivery',
      description: 'Defines the location of the delivery to the customers.',
      img: './assets/images/LocationOfDelivery.svg'
    },
    {
      title: 'Contract Type',
      description: 'Defines the list of contract types available for finalization by the customers.',
      img: './assets/images/ContractType.svg'
    },
    {
      title: 'Sales Organization',
      description: 'Defines the list of sales regions available to serve customers.',
      img: './assets/images/SalesOrganization.svg'
    },
    {
      title: 'Staffing Sales Region',
      description: 'Defines the list of staffing sales regions available.',
      img: './assets/images/StaffingSalesRegion.svg'
    },
    {
      title: 'Engagement Soft Delete',
      description: 'Admins can use this automated service to perform closeout operations.',
      img: './assets/images/EngagementSoftDelete.svg'
    },
    {
      title: 'Milestone Types',
      description: 'Defines the list of delivery environments for customers.',
      img: './assets/images/MilestoneTypes.svg'
    },
    {
      title: 'Account Name',
      description: 'Defines the list of customer accounts for operations.',
      img: './assets/images/AccountName.svg'
    },
    {
      title: 'Project Archive',
      description: 'Defines the customer project s sources of data.',
      img: './assets/images/ProjectArchive.svg'
    },

  ];

  private loadSvgImages(): void {
    this.svgService.loadSvg(this.svgUrls).subscribe(
      (data: string[]) => {
        this.svgs = data;
        if (this.svgs) {
          this.loading = false;          
        }
        else {
          this.loading = true;
        }

      },
      (error: any) => {
        console.error('Error loading SVG images:', error);
      }
    );
  }

}