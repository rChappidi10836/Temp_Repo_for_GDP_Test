import { TestBed } from '@angular/core/testing';

import { RiskAssessmentCalculationService } from './risk-assessment-calculation.service';

describe('RiskAssessmentCalculationService', () => {
  let service: RiskAssessmentCalculationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RiskAssessmentCalculationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
