import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { MsalGuard, MsalService } from '@azure/msal-angular';
import { apiUri } from 'src/environments/environment';
import { AccessLevel } from 'src/app/enums/access_level';
import { Observable } from 'rxjs';
import { Constants } from '../model/Constants';
import { promise } from 'protractor';
import { InteractionRequiredAuthError } from 'msal';

@Injectable()
export class AuthGuardService implements CanActivate {
  constructor(
    public auth: MsalGuard,
    public router: Router,
    private authService: MsalService,
    private http: HttpClient
  ) { }
 requestObj = { scopes: ['user.read']};



 async redirect(): Promise<any>{
  return this.authService.acquireTokenRedirect(this.requestObj);
 }
  async canActivate(): Promise<boolean> {
    let tokenExist = false;
    await this.authService
      .acquireTokenSilent(this.requestObj)
      .then(async (tokenResponse) => {
        // Callback code here
        tokenExist =
          true &&
          (await this.doesUserHaveAccessToRole(AccessLevel.VIEWER_ACCESS));
        // console.log(tokenResponse.accessToken);
      })
      .catch((error) => {
          this.redirect().then
         (async ()=>{tokenExist =
          true &&
          (await this.doesUserHaveAccessToRole(AccessLevel.VIEWER_ACCESS));}) 
      }).catch((error) => {
        this.router.navigate(['login']);
        tokenExist = false;

      });
    return tokenExist;
  }

  async getUserName(): Promise<string> {
    return await this.authService.getAccount().name;
  }
  async getUserMail(): Promise<string> {
    return await this.authService.getAccount().userName;
  }
  apiUri = apiUri;
  Opcoid: string;
  currentRole: string;
  currentUserRole(): Observable<any> {
    return this.http.get<any>(this.apiUri + 'roles/my-current-role');
  }

  async doesUserHaveAccessToRole(accessLevel: AccessLevel): Promise<boolean> {
    return new Promise((resolve, reject) => {
      this.http.get(`${apiUri}roles/my-role`).subscribe(
        (response: any) => {
          if (!response.data[0][0]) {
            this.Opcoid = response.opcoid;
            Constants.OPCO_ID = this.Opcoid;
            this.currentRole = response.data[0][0].substring(5);
            Constants.CURRENT_ROLE = this.currentRole;
            resolve(false);
          }
          if (
            accessLevel === AccessLevel.ADMIN_ACCESS &&
            (response.data[0][0] === 'ROLE_Admin')

          ) {
            this.Opcoid = response.opcoid;
            Constants.OPCO_ID = this.Opcoid;
            this.currentRole = response.data[0][0].substring(5);
            Constants.CURRENT_ROLE = this.currentRole;
            resolve(true);
          } else if (
            accessLevel === AccessLevel.EDIT_ACCESS &&
            (response.data[0][0] === 'ROLE_Admin' ||
              response.data[0][0] === 'ROLE_Global Edit Access' ||
              response.data[0][0] === 'ROLE_Executive')
          ) {
            this.Opcoid = response.opcoid;
            Constants.OPCO_ID = this.Opcoid;
            this.currentRole = response.data[0][0].substring(5);
            Constants.CURRENT_ROLE = this.currentRole;
            resolve(true);
          } else if (
            accessLevel === AccessLevel.VIEWER_ACCESS &&
            (response.data[0][0] === 'ROLE_Admin' ||
              response.data[0][0] === 'ROLE_Global Edit Access' ||
              response.data[0][0] === 'ROLE_Global View Access' ||
              response.data[0][0] === 'ROLE_Executive')
          ) {
            this.Opcoid = response.opcoid;
            Constants.OPCO_ID = this.Opcoid;
            this.currentRole = response.data[0][0].substring(5);
            Constants.CURRENT_ROLE = this.currentRole;
            resolve(true);
          } else if (
            accessLevel === AccessLevel.EXECUTIVE_ACCESS &&
            response.data[0][0] === 'ROLE_Executive'
          ) {
            this.Opcoid = response.opcoid;
            Constants.OPCO_ID = this.Opcoid;
            this.currentRole = response.data[0][0].substring(5);
            Constants.CURRENT_ROLE = this.currentRole;
            resolve(true);
          }
          else {
            resolve(false);
          }
        },
        (error) => {
          resolve(false);
        }
      );
    });
  }
}
