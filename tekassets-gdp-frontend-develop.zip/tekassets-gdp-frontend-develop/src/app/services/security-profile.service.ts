import { Injectable } from '@angular/core';
import { apiUri } from 'src/environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SecurityProfileService {

  apiUri = apiUri;
  subUrl1 = 'security-profile/';

  constructor(private http: HttpClient) { }
/**
 * downloading excel of security profile for a project
 * @param id
 */
  exportToExcelSecurityProfile(id: number): Observable<Blob> {
    return this.http.get(this.apiUri + this.subUrl1 + 'get-security-profile-excel' + `/${id}`, {responseType: 'blob'});
  }
/**
 * @param project id
 * @returns project header information as per project id
 */
  getHeaderUserData(id: number): Observable<any> {
    return this.http.get<any>(this.apiUri + this.subUrl1 + 'get-security-profile-header' + `/${id}`);
  }
/**
 * @param project id
 * @returns security profile as per project id
 */
  getSecurityProfile(id: number): Observable<any> {
    return this.http.get<any>(this.apiUri + this.subUrl1 + 'get-security-profile' + `/${id}`);
  }
  /**
   * @param project id
   * @returns security progile changes logged
   */
  getSecurityProfileReportLogById(id: number): Observable<any> {
    return this.http.get<any[]>(this.apiUri + this.subUrl1 + 'get-security-profile-report-log' + `/${id}`);
  }
/**
 * @returns saved answers or status or comments for projects
 */
  getSecurityProfileAllAnswers(): Observable<any> {
    return this.http.get<any[]>(this.apiUri + this.subUrl1 + 'get-security-profile-all-answers');
  }
/**
 * for saving the changes after edit
 * @param data
 * @returns the saved changes
 * data: { projectId: number; securityAnswersList: any[]; }
 */
  editSecurityProfile(data): Observable<any> {
    return this.http.post<any>(this.apiUri + this.subUrl1 + 'edit-security-profile', data);
  }

  /**
   * for mapping the unmapped answers
   * @param data
   * @returns the mapped changes
   */
  mapSecurityProfile(id: number,data:{ unAnsweredlist: any[], current_Username: string}): Observable<any> {
    console.log("d_unans = ",data.unAnsweredlist)
    
    console.log("c_un = ",data.current_Username);
    console.log("req bod = ",data);
    return this.http.post<any>(this.apiUri + this.subUrl1 + 'map-Security-Profile' + `/${id}`,data);
  }

}
