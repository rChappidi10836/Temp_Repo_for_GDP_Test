// shared.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable(
    {
        providedIn:'root'
    }
)
export class SharedService {
    sharedDataSubject=new BehaviorSubject<any>(null);
    observer$=this.sharedDataSubject.asObservable();
    emitData(data:string):void{
        this.sharedDataSubject.next(data);  
    }

    sharedDataNavbar=new BehaviorSubject<any>(null);
    navbarObserver=this.sharedDataNavbar.asObservable();
    emitDataNavbar(data:string):void{
    this.sharedDataNavbar.next(data);  
    }
    
    shareOpcoIdfromcpc=new BehaviorSubject<any>(null);
    observer1=this.shareOpcoIdfromcpc.asObservable();
    emitOpco(data:Number):void{
        this.shareOpcoIdfromcpc.next(data);  
    }

    shareengopco= new BehaviorSubject<any>(null);
    observer2=this.shareengopco.asObservable();
    emitengOpco(data:String):void{
        this.shareengopco.next(data);  
    }
    
    viewengopco= new BehaviorSubject<any>(null);
    viewengobserver=this.viewengopco.asObservable();
    emitviewengOpco(data:String):void{
        this.viewengopco.next(data);
    }

    deliverymodel = new BehaviorSubject<any>(null);
    observer3 = this.deliverymodel.asObservable();
    emitdelivery(data:any):void{
        this.deliverymodel.next(data);
    }
    
}
