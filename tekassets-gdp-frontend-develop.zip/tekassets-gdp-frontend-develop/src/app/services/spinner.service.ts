import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SpinnerService {
  loading$ = new BehaviorSubject(false);
  taskcount=0
  constructor() { }

  showSpinner() {
    this.taskcount++;
    this.loading$.next(true);
  }

  hideSpinner() {
    this.taskcount--;
    if(this.taskcount===0){
    this.loading$.next(false);
    }
  }
}
