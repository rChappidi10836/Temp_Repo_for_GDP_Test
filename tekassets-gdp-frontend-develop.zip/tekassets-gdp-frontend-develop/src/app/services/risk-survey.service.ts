import { Injectable } from '@angular/core';
import { apiUri } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RiskSurveyService {

  apiUri = apiUri;
  subUrl1 = 'risk-survey/';

  constructor(private http: HttpClient) { }
/**
 * @param id
 * @returns risk survey deatils according to project id
 */
  getRiskSurveyWithProjectId(id: number): Observable<any> {
    return this.http.get<any>(this.apiUri + this.subUrl1 + 'get-risk-survey' + `/${id}`);
  }
/**
 * saving the changes made
 * @param data
 * @returns risk survey with updated data
 */
  saveRiskSurvey(data): Observable<any> {
    return this.http.post<any>(this.apiUri + this.subUrl1 + 'save-risk-survey', data);
  }


}
