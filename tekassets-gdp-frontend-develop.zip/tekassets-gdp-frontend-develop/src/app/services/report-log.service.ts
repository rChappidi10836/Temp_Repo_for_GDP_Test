import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUri } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ReportLogService {
  apiUri = apiUri;
  constructor(private httpService: HttpClient) {}
  /**
   * project data export  report (active / All)
   * @param distinguish between Active / All
   * @returns report according to boolean
   */
  projectDataExportAll(val: boolean,opcoId:string): Observable<Blob> {
    return this.httpService.get(
      this.apiUri + 'reports/project-data?excludeInActive=' + val+"&opcoId="+opcoId,
      { responseType: 'blob' }
    );
  }

   /**

     * stakeholders data export  report (active / All)

     * @param distinguish between Active / All

     * @returns report according to boolean

     */

     stakeHoldersDataExport(val: boolean,opcoId:string): Observable<Blob> {

      return this.httpService.get(

        this.apiUri + 'reports/all-stakeholders-data?excludeInActive=' + val+"&opcoId="+opcoId,

        { responseType: 'blob' }

      );

    }

  /**
   * milestone delivery report (Active / All)
   * @param distinguish between Active / All
   * @returns report according to boolean
   */
  milestonesDeliveryReportAll(val: boolean,opcoId:string): Observable<Blob> {
    return this.httpService.get(
      this.apiUri + 'reports/milestone-delivery-report?onlyActiveStatus=' + val+"&opcoId="+opcoId,
      { responseType: 'blob' }
    );
  }
  /**
   * milestone agile sprint report (Active / All)
   * @param distinguish between Active / All
   * @returns report according to boolean
   */
  milestonesAgileSprintReportAll(val: boolean,opcoId:string): Observable<Blob> {
    return this.httpService.get(
      this.apiUri +
        'reports/milestone-agile-sprint-report?onlyActiveStatus=' +
        val+"&opcoId="+opcoId,
      { responseType: 'blob' }
    );
  }
  /**
   * tgs IS security profile report (Active / All)
   * @param distinguish between Active / All
   * @returns report according to boolean
   */
  tgsISSecurityProfileReportAll(val: boolean,opcoId:string): Observable<Blob> {
    return this.httpService.get(
      this.apiUri + 'reports/security-profile-report?onlyActiveStatus=' + val+"&opcoId="+opcoId,
      { responseType: 'blob' }
    );
  }
  /**
   * pmlc scorecard report
   * @returns pmlc scorecard
   */
  pmlcScorecardReport(opcoId:string): Observable<Blob> {
    return this.httpService.get(this.apiUri + 'reports/pmlc-scorecard-report?'+"opcoId="+opcoId, {
      responseType: 'blob',
    });
  }
  /**
   *Trend Report Changes
   */
  trendDataReport(activeFlag: boolean,startDate: any,endDate: any,opcoId:string):Observable<Blob>{
    return this.httpService.get(this.apiUri + 'reports/trend-report?excludeInActive='+activeFlag +'&fromDate=' + startDate +'&nextDate='+endDate+"&opcoId="+opcoId, {
      responseType: 'blob',
    });

  }
}
