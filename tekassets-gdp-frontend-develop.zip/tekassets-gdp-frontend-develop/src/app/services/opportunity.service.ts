import { Injectable } from '@angular/core';
import { apiUri } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class OpportunityService {

  apiUri = apiUri;
  subUrl1 = 'opportunity/';
  subUrl2 = 'attach-opportunity/';
  subUrl3 = 'excel/';

  constructor(private http: HttpClient) { }
/**
 * downloading excel for all Opportunities
 * @returns deatils of all opportunity
 */
  exportToExcelForAllOpportunities(OpcoId:string): Observable<Blob> {
    return this.http.get(this.apiUri + this.subUrl3 + 'get-all-opportunity-details?OpcoId='+OpcoId, { responseType: 'blob' });
  }
/**
 * called on ngOnInit, populate table with opportunity details
 * @param page
 * @param size
 * @param opcoId
 * @returns OpportunityDetails
 */
  getOpportunityDetails(page: number, size: number, opcoId: string): Observable<any> {
    return this.http.get<any>(this.apiUri + this.subUrl1 + 'get-all-opportunity-details?page=' + page + '&size=' + size + '&opcoId=' + opcoId );
  }
/**
 * for attach to existing engagement under actions tab
 * @returns details of opportunity
 */
  getAttachOpportunityDropdown(): Observable<any> {
    return this.http.get<any>(this.apiUri + this.subUrl2 + 'get-all-project-details');
  }
/**
 * for create new engagement under actions tab
 * @returns new added engagement
 */
  attachOpportunityToExistingProject(data): Observable<any> {
    return this.http.post<any>(this.apiUri + this.subUrl2 + 'add-opportunity-to-project', data);
  }
}
