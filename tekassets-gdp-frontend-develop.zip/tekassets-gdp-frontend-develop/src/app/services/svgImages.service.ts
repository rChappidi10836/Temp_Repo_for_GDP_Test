import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, of } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class SvgService {
    private cache: { [key: string]: string } = {};
    constructor(private http: HttpClient) { }

    public loadSvg(urls: string[]): Observable<string[]> {
        const observables: Observable<string>[] = urls.map(url => this.loadSvgFile(url));
        return forkJoin(observables);
    }

    private loadSvgFile(url: string): Observable<string> {
        if (this.cache[url]) {                       
            return of(this.cache[url]);
        } else {
            return this.http.get(url, { responseType: 'text' }).pipe(
                map(svgData => {
                    this.cache[url] = svgData;
                    return svgData;
                })
            );
        }
    }
}