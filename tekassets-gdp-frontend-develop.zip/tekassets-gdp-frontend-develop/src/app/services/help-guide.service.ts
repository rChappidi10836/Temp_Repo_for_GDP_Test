import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUri } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class HelpGuideService {
  apiUri = apiUri;
  constructor(private httpService: HttpClient) {}
/**
 *
 * @returns the help guide present in side nav
 */
  downloadHelpGuidePDF(): Observable<Blob> {
    return this.httpService.get(`${apiUri}help/download`, {
      responseType: 'blob',
    });
  }
/**
 *
 * @returns project archive for admin dropdown
 */
  downloadProjectArchive(): Observable<Blob> {
    return this.httpService.get(`${apiUri}admin/project-archived-data`, {
      responseType: 'blob',
    });
  }

}
