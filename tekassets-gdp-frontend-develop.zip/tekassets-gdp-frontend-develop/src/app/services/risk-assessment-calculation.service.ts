import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RiskAssessmentCalculationService {
  riskAssignmentCalcArray = new Array(17);
  riskCriteriaText: string;
  securitySensitiveDataAddToScore2: number;
  contractType: string;
  typeOfService: string;
  legalWarrantyConditions: string;
  additionalRiskCriteria: string;
  riskProfile = null;


  constructor() {
    for (let i = 0; i < 17; i++) {
      // Index - 0 -> Score , 1 --> Weight1 , 2 --> Add To Score, 3--> Add To Score(2), 4 --> Risk Score
      this.riskAssignmentCalcArray[i] = new Array(5);
      this.setInitValue(i);
    }
  }

   setInitValue(index) {
    this.riskAssignmentCalcArray[index][0] = 0;
    this.riskAssignmentCalcArray[index][1] = 0;
    this.riskAssignmentCalcArray[index][2] = 0;
    this.riskAssignmentCalcArray[index][3] = 0;
    this.riskAssignmentCalcArray[index][4] = 0;
  }

  // Risk Assessment Calculation
  calculateRiskIndicatorScore(riskFormValue) {
    // Legal - Do warranty conditions established in the contract or MSA apply to this product or service?
    this.riskCriteriaText = riskFormValue.isWarrantyApplicable;
    this.legalWarrantyConditions = riskFormValue.isWarrantyApplicable;
    this.setInitValue(0);
    if (this.riskCriteriaText === 'No') {
      this.riskAssignmentCalcArray[0][0] = 0;
    } else if (this.riskCriteriaText === 'Yes') {
      this.riskAssignmentCalcArray[0][0] = 5;
      this.riskAssignmentCalcArray[0][1] = 5;
    }
    // Legal - What are the liability limits established by all related contracts and MSAs?
    this.riskCriteriaText = riskFormValue.liabilityLimits;
    this.setInitValue(1);
    if (this.riskCriteriaText === 'No liability limits or direct damages apply') {
      this.riskAssignmentCalcArray[1][0] = 0;
    } else if (this.riskCriteriaText === 'Less Than $2mil of direct damage exposure') {
      this.riskAssignmentCalcArray[1][0] = 5;
    } else if (this.riskCriteriaText === '$2mil - $10mil of direct damage exposure') {
      this.riskAssignmentCalcArray[1][0] = 15;
      this.riskAssignmentCalcArray[1][3] = 1;
    } else if (this.riskCriteriaText === 'Greater Than $10mil / Unlimited direct damage exposure') {
      this.riskAssignmentCalcArray[1][0] = 20;
      this.riskAssignmentCalcArray[1][3] = 1;
    } else if (this.riskCriteriaText === 'Uncapped indirect damage exposure') {
      this.riskAssignmentCalcArray[1][0] = 25;
      this.riskAssignmentCalcArray[1][1] = 140;
      this.riskAssignmentCalcArray[1][2] = 140;
    }
    // Legal - What is the contract type (financial)?
    this.riskCriteriaText = riskFormValue.contractType;
    this.setInitValue(2);
    if (this.riskCriteriaText === 'Time & Material') {
            this.riskAssignmentCalcArray[2][0] = -10;
    } else if (this.riskCriteriaText === 'Time & Material not to exceed') {
            this.riskAssignmentCalcArray[2][0] = 60;
    } else if (this.riskCriteriaText === 'Fixed Price - for milestones, time periods, deliverables'
        || this.riskCriteriaText === 'Performance based rewards / penalties') {
          this.riskAssignmentCalcArray[2][0] = 60;
          this.riskAssignmentCalcArray[2][1] = 60;
    }
    // Legal - What is the customer's credit score?
    this.riskCriteriaText = riskFormValue.customerCreditScore;
    this.setInitValue(3);
    if (this.riskCriteriaText === 'Not Available') {
      this.riskAssignmentCalcArray[3][0] = 0;
    } else if (this.riskCriteriaText === 'Less Than 4') {
      this.riskAssignmentCalcArray[3][0] = 5;
    } else if (this.riskCriteriaText === '4 or Greater') {
      this.riskAssignmentCalcArray[3][0] = 10;
      this.riskAssignmentCalcArray[3][1] = 160;
      this.riskAssignmentCalcArray[3][2] = this.riskAssignmentCalcArray[3][1];
    }
    // Security - Does the solution require access to and/or handling of sensitive data (PII, PHI, confidential customer information)?
    this.riskCriteriaText = riskFormValue.sensitiveData;
    this.setInitValue(4);
    if (this.riskCriteriaText === 'No') {
      this.riskAssignmentCalcArray[4][0] = 0;
    } else if (this.riskCriteriaText === 'Access only') {
      this.riskAssignmentCalcArray[4][0] = 5;
      this.riskAssignmentCalcArray[4][1] = 5;
    } else if (this.riskCriteriaText === 'Access and handling') {
      this.riskAssignmentCalcArray[4][0] = 10;
      this.riskAssignmentCalcArray[4][1] = 10;
    } else if (this.riskCriteriaText === 'Access, handling, storage, or management') {
      this.riskAssignmentCalcArray[4][0] = 150;
      this.riskAssignmentCalcArray[4][1] = 150;
    }
    this.securitySensitiveDataAddToScore2 = 0;
    this.securitySensitiveDataAddToScore2 = this.riskAssignmentCalcArray[4][0] + this.riskAssignmentCalcArray[1][3];
    if (this.securitySensitiveDataAddToScore2 === 11) {
      this.riskAssignmentCalcArray[4][3] = 140;
    }
    // Security - Are there regulatory compliance requirements associated with the product or service provided?
    this.riskCriteriaText = riskFormValue.isComplianceAssociated;
    this.setInitValue(5);
    if (this.riskCriteriaText === 'No') {
      this.riskAssignmentCalcArray[5][0] = 0;
    } else if (this.riskCriteriaText === 'Yes') {
      this.riskAssignmentCalcArray[5][0] = 5;
      this.riskAssignmentCalcArray[5][1] = 5;
    }
    // Security - Who will supply the hardware and equipment required for solution implementation/service operations?
    this.riskCriteriaText = riskFormValue.hardwareAndEquipment;
    this.setInitValue(6);
    if (this.riskCriteriaText === 'Customer supplied') {
      this.riskAssignmentCalcArray[6][0] = 0;
    } else if (this.riskCriteriaText === 'Combined customer and TEKsystems supplied') {
      this.riskAssignmentCalcArray[6][0] = 5;
      this.riskAssignmentCalcArray[6][1] = 5;
    } else if (this.riskCriteriaText === 'TEKsystems supplied') {
      this.riskAssignmentCalcArray[6][0] = 10;
      this.riskAssignmentCalcArray[6][1] = 10;
    }
    // Security - Must the product or service be covered by an operational Business Continuity/Disaster Recovery redundancy solution?
    this.riskCriteriaText = riskFormValue.isCovered;
    this.setInitValue(7);
    if (this.riskCriteriaText === 'No') {
      this.riskAssignmentCalcArray[7][0] = 0;
    } else if (this.riskCriteriaText === 'Yes') {
      this.riskAssignmentCalcArray[7][0] = 5;
      this.riskAssignmentCalcArray[7][1] = 5;
    }
    if (this.riskAssignmentCalcArray[7][0] > 0) {
      this.riskAssignmentCalcArray[7][2] = this.riskAssignmentCalcArray[6][1];
    }
    // Delivery - What location are services provided from?
    this.riskCriteriaText = riskFormValue.location;
    this.setInitValue(8);
    if (this.riskCriteriaText === 'Client site only') {
      this.riskAssignmentCalcArray[8][0] = 0;
    } else if (this.riskCriteriaText === 'On-/near-shore TEKsystems facility or remote location' ||
                this.riskCriteriaText === 'Mix of client, on-/near-shore TEKsystems facility, or remote location' ||
                this.riskCriteriaText === 'Off-shore TEKsystems facility' ||
                this.riskCriteriaText === 'Mix of client, on-/near-/off-shore TEKsystems facility, or remote location') {
                  this.riskAssignmentCalcArray[8][0] = 15;
    }
    // Delivery - What type of product or service is being provided to the customer?
    this.riskCriteriaText = riskFormValue.typeOfService;
    this.setInitValue(9);
    if (this.riskCriteriaText === 'Engagement') {
      this.riskAssignmentCalcArray[9][0] = 10;
      this.riskAssignmentCalcArray[9][1] = 10;
    } else if (this.riskCriteriaText === 'Advisory') {
      this.riskAssignmentCalcArray[9][0] = 10;
    } else if (this.riskCriteriaText === 'Co-Managed') {
      this.riskAssignmentCalcArray[9][0] = 0;
      this.riskAssignmentCalcArray[9][2] = -(5 + this.riskAssignmentCalcArray[2][0] + this.riskAssignmentCalcArray[12][0]);
    }
    // Delivery - What is the contractual duration for the services provided?
    this.riskCriteriaText = riskFormValue.contractualDuration;
    this.setInitValue(10);
    if (this.riskCriteriaText === 'Greater Than 1 year') {
      this.riskAssignmentCalcArray[10][0] = 5;
      this.riskAssignmentCalcArray[10][1] = 5;
    } else if (this.riskCriteriaText === '6 months to 1 year') {
      this.riskAssignmentCalcArray[10][0] = 10;
      this.riskAssignmentCalcArray[10][1] = 10;
    } else if (this.riskCriteriaText === 'Less Than 6 months') {
      this.riskAssignmentCalcArray[10][0] = 15;
    }
    if (this.riskAssignmentCalcArray[10][0] > 5) {
      this.riskAssignmentCalcArray[10][2] = this.riskAssignmentCalcArray[2][1] + this.riskAssignmentCalcArray[9][1];
    }
    // Delivery - Is this an established key account for TEKsystems Global Services?
    this.riskCriteriaText = riskFormValue.isEstablishedAccount;
    this.setInitValue(11);
    if (this.riskCriteriaText === 'No') {
      this.riskAssignmentCalcArray[11][0] = 0;
    } else if (this.riskCriteriaText === 'Yes') {
      this.riskAssignmentCalcArray[11][0] = 5;
      this.riskAssignmentCalcArray[11][2] = 5;
    }
    // Delivery - What is the total projected revenue for this engagement?
    this.riskCriteriaText = riskFormValue.totalProjectedRevenue;
    this.setInitValue(12);
    if (this.riskCriteriaText === 'Less Than $500k') {
      this.riskAssignmentCalcArray[12][0] = 5;
    } else if (this.riskCriteriaText === '$500k to $2mil') {
      this.riskAssignmentCalcArray[12][0] = 10;
      this.riskAssignmentCalcArray[12][1] = 10;
    } else if (this.riskCriteriaText === 'Greater Than $2mil') {
      this.riskAssignmentCalcArray[12][0] = 60;
      this.riskAssignmentCalcArray[12][1] = 60;
    }
    if (this.riskAssignmentCalcArray[12][0] > 5) {
      this.riskAssignmentCalcArray[12][2] = this.riskAssignmentCalcArray[2][1] + this.riskAssignmentCalcArray[9][1];
    }
    // Delivery - How long has TEKsystems Global Services been engaged with this account?
    this.riskCriteriaText = riskFormValue.engagementWithTek;
    this.setInitValue(13);
    if (this.riskCriteriaText === 'Greater Than 3 years') {
      this.riskAssignmentCalcArray[13][0] = 5;
    } else if (this.riskCriteriaText === '1 - 3 years') {
      this.riskAssignmentCalcArray[13][0] = 10;
    } else if (this.riskCriteriaText === 'Less Than 1 year') {
      this.riskAssignmentCalcArray[13][0] = 15;
      this.riskAssignmentCalcArray[13][1] = 15;
    }
    // Delivery - Is solution delivery dependent on a 3rd party company?
    this.riskCriteriaText = riskFormValue.is3rdPartyDependent;
    this.setInitValue(14);
    this.contractType = riskFormValue.contractType;
    this.typeOfService = riskFormValue.typeOfService;
    if (this.riskCriteriaText === 'No') {
      this.riskAssignmentCalcArray[14][0] = 0;
    } else if (this.riskCriteriaText === 'Yes') {
      this.riskAssignmentCalcArray[14][0] = 60;
    }
    // Delivery - Does the delivery location, model, or practice engagement present unique challenges?
    this.riskCriteriaText = riskFormValue.hasUniqueChallenges;
    this.setInitValue(15);
    if (this.riskCriteriaText === 'Yes - Location, model, and practice challenges exist') {
      this.riskAssignmentCalcArray[15][0] = 10;
    } else if (this.riskCriteriaText === 'No - Location, model, and practice involvement are standard') {
      this.riskAssignmentCalcArray[15][0] = 0;
    } else if (this.riskCriteriaText === 'Partially - Some challenges exist, but should not present significant issues') {
      this.riskAssignmentCalcArray[15][0] = 5;
    }
    // Add To Score
    if (this.legalWarrantyConditions === 'Yes') {

      this.riskAssignmentCalcArray[0][2] =  this.riskAssignmentCalcArray[9][1];
    }
    if ( this.riskAssignmentCalcArray[2][0] > 10) {
      this.riskAssignmentCalcArray[2][2] =  this.riskAssignmentCalcArray[9][1] +  this.riskAssignmentCalcArray[10][1];
    }
    if ( this.riskAssignmentCalcArray[4][0] > 5) {
      this.riskAssignmentCalcArray[4][2] =  this.riskAssignmentCalcArray[1][1] +
        this.riskAssignmentCalcArray[5][1] +  this.riskAssignmentCalcArray[6][1];
    }
    if ( this.riskAssignmentCalcArray[5][0] > 0) {
      this.riskAssignmentCalcArray[5][2] =  this.riskAssignmentCalcArray[4][1] +  this.riskAssignmentCalcArray[9][1];
    }
    if ( this.riskAssignmentCalcArray[6][0] > 0) {
      this.riskAssignmentCalcArray[6][2] =  this.riskAssignmentCalcArray[4][1] +  this.riskAssignmentCalcArray[7][1];
    }
    if (( this.riskAssignmentCalcArray[8][0] +  this.riskAssignmentCalcArray[9][0]) === 25) {
      this.riskAssignmentCalcArray[8][2] = 100;
    }
    // Total Risk Score
    this.riskAssignmentCalcArray[0][4] = this.riskAssignmentCalcArray[0][0] + this.riskAssignmentCalcArray[0][2];
    this.riskAssignmentCalcArray[1][4] = this.riskAssignmentCalcArray[1][0] + this.riskAssignmentCalcArray[1][2];
    this.riskAssignmentCalcArray[2][4] = this.riskAssignmentCalcArray[2][0] + this.riskAssignmentCalcArray[2][2];
    this.riskAssignmentCalcArray[3][4] = this.riskAssignmentCalcArray[3][0] + this.riskAssignmentCalcArray[3][2];
    this.riskAssignmentCalcArray[4][4] = this.riskAssignmentCalcArray[4][0] + this.riskAssignmentCalcArray[4][2] +
                                            this.riskAssignmentCalcArray[4][3];
    this.riskAssignmentCalcArray[5][4] = this.riskAssignmentCalcArray[5][0] + this.riskAssignmentCalcArray[5][2];
    this.riskAssignmentCalcArray[6][4] = this.riskAssignmentCalcArray[6][0] + this.riskAssignmentCalcArray[6][2];
    this.riskAssignmentCalcArray[7][4] = this.riskAssignmentCalcArray[7][0] + this.riskAssignmentCalcArray[7][2];
    this.riskAssignmentCalcArray[8][4] = this.riskAssignmentCalcArray[8][0] + this.riskAssignmentCalcArray[8][2];
    this.riskAssignmentCalcArray[9][4] = this.riskAssignmentCalcArray[9][0] + this.riskAssignmentCalcArray[9][2];
    this.riskAssignmentCalcArray[10][4] = this.riskAssignmentCalcArray[10][0] + this.riskAssignmentCalcArray[10][2];
    this.riskAssignmentCalcArray[11][4] = this.riskAssignmentCalcArray[11][0] + this.riskAssignmentCalcArray[11][2];
    this.riskAssignmentCalcArray[12][4] = this.riskAssignmentCalcArray[12][0] + this.riskAssignmentCalcArray[12][2];
    this.riskAssignmentCalcArray[13][4] = this.riskAssignmentCalcArray[13][0] + this.riskAssignmentCalcArray[13][2];
    this.riskAssignmentCalcArray[14][4] = this.riskAssignmentCalcArray[14][0] + this.riskAssignmentCalcArray[14][2];
    // this.riskAssignmentCalcArray[15][4] = this.riskAssignmentCalcArray[15][0] + this.riskAssignmentCalcArray[15][2];
    let totalRiskScore = 0;
    for (let i = 0; i < 15; i++) {
        // totalRiskScore += this.riskAssignmentCalcArray[i][4];
        totalRiskScore = totalRiskScore + this.riskAssignmentCalcArray[i][4];
    }
    // High Risk Indicator - Is there additional risk criteria, not addressed above,
    // which you believe forces this engagement into the High Risk category?
    this.additionalRiskCriteria = riskFormValue.hasHighRiskCategory;
    this.setInitValue(16);
    if (this.additionalRiskCriteria === 'Yes') {
        this.riskAssignmentCalcArray[16][0] = 171 - totalRiskScore;
    }
    // Risk Indicator Score
    let riskIndicatorScore = 0;
    if (this.isRequiredRiskAttributeHasValues(riskFormValue) === true) {
      riskIndicatorScore = totalRiskScore + this.riskAssignmentCalcArray[16][0];
      if (riskIndicatorScore < 125) {
        // Low Risk
        this.riskProfile = 'Low Risk';
      } else if (riskIndicatorScore >= 125 && riskIndicatorScore <= 170) {
        // Moderate Risk
        this.riskProfile = 'Moderate Risk';
    } else if (riskIndicatorScore > 170) {
        // High Risk
        this.riskProfile = 'High Risk';
    }
    }
    return this.riskProfile;
  }

  isRequiredRiskAttributeHasValues(riskFormValue) {
    if (riskFormValue.isWarrantyApplicable === null || riskFormValue.liabilityLimits === null ||
      riskFormValue.contractType === null || riskFormValue.customerCreditScore === null ||
      riskFormValue.sensitiveData === null || riskFormValue.isComplianceAssociated === null ||
      riskFormValue.hardwareAndEquipment === null || riskFormValue.isCovered === null ||
      riskFormValue.location === null || riskFormValue.typeOfService === null ||
      riskFormValue.contractualDuration === null || riskFormValue.isEstablishedAccount === null ||
      riskFormValue.totalProjectedRevenue === null || riskFormValue.engagementWithTek === null ||
      riskFormValue.is3rdPartyDependent === null || riskFormValue.hasUniqueChallenges === null ||
      riskFormValue.hasHighRiskCategory === null
      ) {
        return false;
    } else {
      return true;
    }
  }
}
