import { Injectable } from '@angular/core';
import { apiUri } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CreateProjectModel } from '../model/CreateProjectModel';
import { UserSearch } from '../model/UserSearch';
import { ProjectClientName } from '../model/ProjectClientName';

@Injectable({
  providedIn: 'root',
})
export class CreateProjectService {
  apiUri = apiUri;
  subUrl = 'create-project/';
  subUrl1 = 'edit-project/';
  subUrl2 = 'risk-survey/';
  subUrl3 = 'risk-survey-excel/';

  constructor(private http: HttpClient) {}

  exportSampleRiskSurvey(
    id: number,
    data: ProjectClientName
  ): Observable<Blob> {
    return this.http.post(
      this.apiUri + this.subUrl3 + 'get-sample-risk-survey' + `/${id}`,
      data,
      { responseType: 'blob' }
    );
  }

  // searchusers(OpcoID: any): Observable<any> {
  //   return this.http.get<any>(
  //     this.apiUri + this.subUrl + 'user-search/{OpcoID}{?op}
  //   );
  

  // }

  // searchusers(opcoID: string): Observable<any> {
  //   const url = `${this.apiUri}${this.subUrl}user-search/OpcoID=${opcoID}?`;
  //   return this.http.get<any>(url);
  // }

  getSalesOrganizationDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-sales-organization-dropdown'
    );
  }

  ifProjectNameExist(projectName){
    return this.http.get<any>(
      this.apiUri + this.subUrl + `check-if-project-name-exists?projectName=${projectName}`
    );
  }
  getResourceRoleDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-resource-role-dropdown'
    );
  }

  getStaffingSalesRegionDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-staffing-sales-region-dropdown'
    );
  }

  getBusinessUnitDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-business-unit-dropdown'
    );
  }

  getPracticeEngagementDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-practice-engagement-dropdown'
    );
  }

  getDeliveryModelDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-delivery-model-dropdown'
    );
  }

  getLocationOfServiceDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-location-of-services-dropdown'
    );
  }

  getContractTypeDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-contract-type-dropdown'
    );
  }

  saveProject(data: CreateProjectModel, isSourceOpportunity): Observable<any> {
    return this.http.post<any>(
      this.apiUri +
        this.subUrl +
        'create-project-manually?isSourceOpportunity=' +
        isSourceOpportunity,
      data
    );
  }

  editProject(data: CreateProjectModel): Observable<any> {
    return this.http.post<any>(
      this.apiUri + this.subUrl1 + 'edit-project-details',
      data
    );
  }

  userSearch(data: UserSearch,OpcoID:String, page: number, size: number): Observable<any> {
    return this.http.post<any>(
      this.apiUri + this.subUrl + 'user-search?OpcoID=' + OpcoID + '&page=' + page + '&size=' + size,
      data
    );
  }

  getProjectDetailsById(id: number): Observable<any> {
    return this.http.get<any[]>(
      this.apiUri + this.subUrl + 'find-project-by-id' + `/${id}`
    );
  }

  getReportLogById(id: number): Observable<any> {
    return this.http.get<any[]>(
      this.apiUri + this.subUrl + 'get-report-log' + `/${id}`
    );
  }

  getRiskSurveyReportLogById(id: number): Observable<any> {
    return this.http.get<any[]>(
      this.apiUri + this.subUrl2 + 'get-risk-survey-report-log' + `/${id}`
    );
  }

  getPrimaryServiceTypeDropdown(): Observable<any> {
    return this.http.get<any>(
      this.apiUri + this.subUrl + 'get-primary-service-type-dropdown'
    );
  }

  deleteProject(id: any): Observable<any> {
    return this.http.delete<any[]>(this.apiUri + `admin/delete-project/${id}`);
  }
}
