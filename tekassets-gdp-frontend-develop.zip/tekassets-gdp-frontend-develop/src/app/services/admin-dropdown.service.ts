import { Injectable } from '@angular/core';
import { apiUri } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { ClientModel, RequestedTabModel } from '../model/AdminTabsModel';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AdminDropdownService {

  apiUri = apiUri;

  constructor(private http: HttpClient) { }
  /**
   *
   * @param page
   * @param requestedTab
   * @param size
   * @returns employee detais
   */
  getRequestedTabData(page: number, requestedTab: string, size: number,opcoId?:any): Observable<any> {
    let apiUrl= this.apiUri + 'admin/get-requested-tab-list?page=' + page
      + '&requestedTab=' + requestedTab + '&size=' + size;
    if(requestedTab==='Client'){
      apiUrl=apiUrl+'&opcoId='+opcoId;
    }
    return this.http.get<any>(apiUrl);
  }
  /**
   * for searching
   * @param page
   * @param requestedTab
   * @param search
   * @param size
   * @returns results related to search item
   */
  searchRequestedTabData(page: number, requestedTab: string, search: string, size: number, opcoId?:any): Observable<any> {
    let apiUrl=this.apiUri + 'admin/get-requested-tab-searched-list?page=' + page
      + '&requestedTab=' + requestedTab + '&search=' + search + '&size=' + size;
    if(requestedTab==='Client'){
      apiUrl=apiUrl+'&opcoId='+opcoId;
    }
    return this.http.get<any>(apiUrl);
  }
  /**
   * saving the employee details
   * @param data
   * @param requestedTab
   */
  saveToRequestedTabData(data: RequestedTabModel, requestedTab: string): Observable<any> {
    return this.http.post<any>(this.apiUri + 'admin/save-to-requested-tab?requestedTab=' + requestedTab, data);
  }

  saveClient(data: ClientModel, requestedTab: string): Observable<any> {
    const url = `${this.apiUri}admin/save-client?requestedTab=${requestedTab}`;
    return this.http.post<any>(url, data);
  }
  
  /**
   * deletion of details
   * @param data
   * @param requestedTab
   */
  deleteRequestedTabRow(data, requestedTab: string): Observable<any> {
    return this.http.post<any>(
      this.apiUri + 'admin/delete-from-requested-tab?requestedTab=' + requestedTab, data);
  }
  /**
   *
   * @param search supervisor according to keyword
   * @returns supervisor name list
   */
  getSupervisorSearch(search,opcoId): Observable<any> {
    return this.http.get<any>(this.apiUri + `admin/get-supervisor-list?search=${search}&opcoId=${opcoId}`);
  }
  /**
   *
   * @param username
   */
  searchGDPUser(username,userID): Observable<any> {
    return this.http.get<any>(this.apiUri + `admin/search-gdp-user?username=${username}&userID=${userID}`);
  }
  /**
  /**
   * populate dropdown
   * @returns job title dropdown
   */
  getJobTitleDropdown(): Observable<any> {
    return this.http.get<any>(this.apiUri + 'admin/get-designation-list');
  }

 
  /**
   * saving the new resource added
   * changes to existing resource(emlpoyee)
   * @param data
   */
  saveResourceData(data): Observable<any> {
    return this.http.post<any>(this.apiUri + 'admin/save-resource', data);
  }

  exportToExcelAdmin(requestedExcel: string,active?:boolean, opcoId?:any): Observable<Blob> {
    let apiUrI=this.http.get(this.apiUri + 'admin/export-to-excel/' + requestedExcel, { responseType: 'blob' });
    if(requestedExcel==='Client'){
    apiUrI=this.http.get(this.apiUri + 'admin/export-to-excel/' + requestedExcel + '?active=' + active+'&opcoId=' + opcoId, { responseType: 'blob' });
    }else if(requestedExcel==='DeliveryOrganizationType'){
      apiUrI=this.http.get(this.apiUri + 'admin/export-to-excel/' + requestedExcel + '?active=' + active, { responseType: 'blob' });
    }
    return apiUrI;
  }
  /**
  * to check duplication of employeeID
  * @param id entered by user
  * @returns true if exists
  */
  getEmployeeId(id,opco): Observable<any> {
    return this.http.get<any>(this.apiUri + `admin/check-employeeId-exists?employeeId=${id}&opcoId=${opco}`);
  }
  /**
   * to check duplication of userID
   * @param id entered by user
   * @returns true if exists
   */
  getUserId(id,opcoId): Observable<any> {
    return this.http.get<any>(this.apiUri + `admin/check-userid-exists?userId=${id}&opcoId=${opcoId}`);
  }

  getAccountName(accountName,active,opcoId): Observable<any> {
    return this.http.get(this.apiUri + 'admin/check-account-exists?AccountName=' + accountName + '&Active=' + active+'&opcoId='+opcoId);
  }
  getGdpId(): Observable<any> {
    return this.http.get<any>(this.apiUri + 'admin/get-gdp-list');
  }
  getSoftDelete(data): Observable<any> {

    return this.http.post<any>(this.apiUri + 'admin/soft-delete', data);

  }

}
