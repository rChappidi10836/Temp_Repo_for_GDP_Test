import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { apiUri } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class StatusReportServiceService {
  apiUri = apiUri;
  statusReportUrl = 'status-report/';
  milestoneUrl = 'milestones/';
  // sendGETRequestWithParameters: any;

  // subUrl1 = 'opportunity/';
  // subUrl2 = 'attach-opportunity/';

  constructor(private http: HttpClient) {}
  getSampleStatusReport(
    id: number,
    page: number,
    size: number
  ): Observable<any> {
    return this.http.get<any>(
      this.apiUri +
        this.statusReportUrl +
        'get-status-report-by-projectId' +
        `/${id}` +
        '?page=' +
        page +
        '&size=' +
        size
    );
  }
  getStatusDeliveryService(id: number): Observable<any> {
    return this.http.get<any>(
      this.apiUri +
        this.statusReportUrl +
        'get-delivery-hours-by-projectId' +
        `/${id}`
    );
  }

  public getMilestoneDeliveryReport(data): Observable<any> {
    let params = new HttpParams();
    params = params.append('weekEndingDate', data.weekEndingDate);
    params = params.append('page', data.pageNumber);
    params = params.append('size', data.pageSize);

    return this.http.get(
      this.apiUri +
        this.milestoneUrl +
        'get-milestones-by-projectId' +
        `/${data.projectId}`,
      { params }
    );
  }

  // getMilestoneDeliveryReport(id: Number): Observable<any> {
  //   return this.http.get<any>(
  //     "https://jsonblob.com/api/1dad6823-0dfe-11eb-a6df-77ebed82b238"
  //   );
  // }

  saveStatusReport(data): Observable<any> {
    return this.http.post<any>(
      this.apiUri + this.statusReportUrl + 'save-status-report',
      data
    );
  }

  saveDeliveryHours(data): Observable<any> {
    return this.http.post<any>(
      this.apiUri + this.statusReportUrl + 'save-delivery-hours',
      data
    );
  }

  saveMilestoneStatusReport(data): Observable<any> {
    return this.http.post<any>(
      this.apiUri + this.milestoneUrl + 'save-milestones',
      data
    );
  }

  updateStatusReportForPassDue(data): Observable<any> {
    return this.http.post<any>(
      this.apiUri + this.statusReportUrl + 'update-status-report-in-pass-due',
      data
    );
  }

  updateStatusReport(data): Observable<any> {
    return this.http.post<any>(
      this.apiUri + this.statusReportUrl + 'update-status-report',
      data
    );
  }

  deleteStatusReport(data): Observable<any> {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: data,
    };
    return this.http.delete<any>(
      this.apiUri + this.statusReportUrl + 'delete-status-report',
      options
    );
  }

  getDeliveryMilestoneTypes(): Observable<any> {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    return this.http.get<any>(
      this.apiUri + this.milestoneUrl + 'get-all-delivery-milestone-type',
      options
    );
  }

  getDeliveryHoursByWED(projectId: number, weekEndingDate:string):Observable<any> {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    return this.http.get<any>(`${this.apiUri}${this.statusReportUrl}get-delivery-hours-by-projectId-wed/${projectId}?weekEndingDate=${weekEndingDate}`, options);
  }

}
