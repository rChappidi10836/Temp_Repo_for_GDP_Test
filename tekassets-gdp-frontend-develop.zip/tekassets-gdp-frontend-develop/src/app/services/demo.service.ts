import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUri } from 'src/environments/environment';
import { SearchProject } from '../model/SearchProject';

@Injectable({
  providedIn: 'root',
})
export class DemoService {
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
  };

  // private _uri = '/assets/data/projects.json';
  apiUri = apiUri;
  subUrl = 'project/';
  dashboardUrl = 'dashboard/';
  exportToExcelUrl = 'excel/';
  exportHeaders: {
    'Content-type': 'application/json';
    Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  };

  constructor(private http: HttpClient) {}
  searchProject(
    data: SearchProject,
    page: number,
    size: number,
    opcoId:string
  ): Observable<any> {
    return this.http.post<any>(
      this.apiUri +
        this.dashboardUrl +
        'search-project-with-filter?page=' +
        page +
        '&size=' +
        size+ 
        '&opcoId='+
        opcoId,
      data
    );
  }

  getListOfFilterValuesForAllProjects(
  filterOptions: SearchProject,
  opcoId: string 
): Observable<any> {

  let ttpParam = '-1';

  if (filterOptions.ttpId && filterOptions.ttpId.length > 0) {
    if (!filterOptions.ttpId.includes(-1)) {
      ttpParam = filterOptions.ttpId.join(',');
    }
  }

  return this.http.get<any>(
    `${this.apiUri}${this.dashboardUrl}get-all-project-filter-details` +
    `?active=${filterOptions.active}` +
    `&clientId=${filterOptions.clientId}` +
    `&deliveryOrganizationTypeId=${filterOptions.deliveryOrganizationTypeId}` +
    `&cslId=${filterOptions.cslId}` +
    `&gdmId=${filterOptions.gdmId}` +
    `&gddId=${filterOptions.gddId}` +
    `&programManagerId=${filterOptions.programManagerId}` +
    `&projectId=${filterOptions.projectId}` +
    `&businessUnitId=${filterOptions.businessUnitId}` +
    `&psId=${filterOptions.psId}` +
    `&opcoId=${opcoId}` +
    `&lodId=${filterOptions.lodId}` +
    `&dmId=${filterOptions.dmId}` +
    `&ttpId=${ttpParam}`   
  );
}



  getProjectStatus(page: number, size: number , opcoId : number): Observable<any> {
    return this.http.get<any>(
      this.apiUri +
        this.dashboardUrl +
        'get-project-status-details?page=' +
        page +
        '&size=' +
        size + 
        '&opcoId='+
        opcoId
    );
  }




  getOpcoDropdown(): Observable<any> {
    return this.http.get<any>(this.apiUri +this.dashboardUrl+ 'get-opco-list');
  }

  getProjects(page: number, size: number): Observable<any[]> {
    return this.http.get<any[]>(
      this.apiUri +
        this.subUrl +
        'list-all-projects?page=' +
        page +
        '&size=' +
        size
    );
  }

  exportToExcelForAllProjects(): Observable<Blob> {
    return this.http.get(
      this.apiUri + this.exportToExcelUrl + 'get-all-project-details',
      { responseType: 'blob' }
    );
  }

  exportToExcelForFilteredProjects(data: SearchProject , opcoId : string): Observable<Blob> {
    return this.http.post(
      this.apiUri + this.exportToExcelUrl + 'project-details-on-filter?opcoId='+opcoId,
      data,
      { responseType: 'blob' }
    );
  }

  getProjectById(id: number): Observable<any[]> {
    return this.http.get<any[]>(
      this.apiUri + this.subUrl + 'find-project-by-id' + `/${id}`
    );
  }

  saveProject(data: any): Observable<any[]> {
    return this.http.post<any[]>(
      this.apiUri + this.subUrl + 'add-project',
      data
    );
  }

  updateProject(data: any, id: number): Observable<any[]> {
    return this.http.put<any[]>(
      this.apiUri + this.subUrl + 'update-project' + `/${id}`,
      data,
      this.httpOptions
    );
  }
}
