import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUri } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})

export class ManageAccessService {
  apiUri = apiUri;

  constructor(private httpService: HttpClient) { }
  /**
   * getting all employee list
   * @param page
   * @param size
   * @returns
   */
  getEmployeesService(page: number, size: number, opcoId:string): Observable<any> {
    return this.httpService.get<any>(this.apiUri + 'admin/get-resource-list?page=' + page + '&size=' + size+'&opcoId='+opcoId);
  }
  /**
   * to perform action of manage user role
   * @param data
   * @returns changes saved
   */
  userRoleService(data): Observable<any> {
    return this.httpService.post<any>(this.apiUri + 'admin/manage-user-role', data);
  }
  /**
   * searching by employee details
   * @param page
   * @param search
   * @param size
   * @returns employee related to search
   */
  searchResources(page: number, search: string, size: number,opcoId: string): Observable<any> {
    return this.httpService.get<any>(this.apiUri + 'admin/search-resources?page=' + page
      + '&searchKey=' + search + '&size=' + size+'&opcoId='+opcoId);
  }
  /**
   * deletion of employee
   * @param resourceId
   */
  deleteStatusReport(resourceId): Observable<any> {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      // body: resourceId,
    };
    return this.httpService.delete<any>(
      this.apiUri + 'admin/delete-resource/' + resourceId,
      options
    );
  }
  /**
   * downloading excel
   * @param isActive
   */
  exportToExcelUsers(isActive,opcoId): Observable<Blob> {
    return this.httpService.get(this.apiUri + 'admin/export-to-excel/manage-access?isActive=' + isActive+'&opcoId='+opcoId, { responseType: 'blob' });
  }
}
