import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class ConfirmDialogComponent implements OnInit {
  clearValue = false;

  constructor(
    public dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public confirmData: any,
  ) { }

  ngOnInit(): void {
  }
  /**
   * case of proceeding
   */
  actionFunction() {
    this.clearValue = true;
    this.dialogRef.close(this.clearValue);
    // this.closeDialog();
  }
/**
 * case of cancel
 */
  closeDialog() {
    this.clearValue = false;
    this.dialogRef.close(this.clearValue);
  }
}
