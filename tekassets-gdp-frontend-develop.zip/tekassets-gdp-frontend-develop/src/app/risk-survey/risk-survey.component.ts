import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Constants } from '../model/Constants';
import {
  IconDefinition,
  faPen,
  faCircle,
} from '@fortawesome/free-solid-svg-icons';
import { RiskAssessmentCalculationService } from '../services/risk-assessment-calculation.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CreateProjectService } from '../services/create-project.service';
import { RiskSurveyService } from '../services/risk-survey.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CreateProjectDialogComponent } from '../create-project-dialog/create-project-dialog.component';
import { MatTableDataSource } from '@angular/material/table';
import { ReportLog } from '../model/ReportLog';
import { ProjectClientName } from '../model/ProjectClientName';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { AuthGuardService } from '../services/auth_guard.service';
import { AccessLevel } from '../enums/access_level';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-risk-survey',
  templateUrl: './risk-survey.component.html',
  styleUrls: ['./risk-survey.component.scss'],
})
export class RiskSurveyComponent implements OnInit {
  newCreateProjectForm: any;
  valueCheck = false;
  @ViewChild('errorDialogTemplate') errorDialogTemplate!: TemplateRef<any>;
  hasError: boolean;
  errorMessage: string;
  constructor(
    private fb: FormBuilder,
    private riskAssessmentService: RiskAssessmentCalculationService,
    private activatedRoute: ActivatedRoute,
    private createProjectService: CreateProjectService,
    private router: Router,
    private riskSurveyService: RiskSurveyService,
    public dialog: MatDialog,
    public matDialog: MatDialog,
    private authService: AuthGuardService
  ) { }
  // Icons
  faPen: IconDefinition = faPen;
  faCircle: IconDefinition = faCircle;

  displayedColumns: string[] = ['lastUpdatedBy', 'dateAndTime'];
  id: number;
  riskColor = null;
  showCommentBox = false;
  projectId = '';
  projectName = '';
  accountName = '';
  resetFormData: any;
  routedData: any;
  reportLogdata = [];
  datasource = new MatTableDataSource<ReportLog>();
  reportLogErrorMessage = '';
  tableHasData = false;
  showOnSave = false;
  buttonText = 'Save';
  opportunityData = null;
  lastUpdatedBy = '';
  lastUpdatedAt = '';
  valueCheckBoolean = {};
  hasEditAccess = false;
  // projectAndClientName: ProjectClientName;

  isWarrantyApplicable = Constants.IS_WARRANTY_APPLICABLE;
  liabilityLimits = Constants.LIABILITY_LIMITS;
  contractType = Constants.CONTRACT_TYPE;
  customerCreditScore = Constants.CUSTOMER_CREDIT_SCORE;
  sensitiveData = Constants.SENSITIVE_DATA;
  isComplianceAssociated = Constants.IS_COMPLIANCE_ASSOCIATED;
  hardwareAndEquipment = Constants.HARDWARE_AND_EQUIPMENT;
  isCovered = Constants.IS_COVERED;
  whatLocation = Constants.WHAT_LOCATION;
  providedToCustomer = Constants.PROVIDED_TO_CUSTOMER;
  contractualDuration = Constants.CONTRACTUAL_DURATION;
  isEstablishedAccount = Constants.IS_ESTABLISHED_ACCOUNT;
  totalProjectedRevenue = Constants.TOTAL_PROJECTED_REVENUE;
  engagementWithTek = Constants.ENGAGEMENT_WITH_TEK;
  is3rdPartyDependent = Constants.IS_3RD_PARTY_DEPENDENT;
  hasUniqueChallenges = Constants.HAS_UNIQUE_CHALLENGES;
  hasHighRisk = Constants.HIGH_RISK_INDICATOR;

  isWarrantyApplicableOptions = ['No', 'Yes'];
  liabilityLimitsOptions = [
    'No liability limits or direct damages apply',
    'Less Than $2mil of direct damage exposure',
    '$2mil - $10mil of direct damage exposure',
    'Greater Than $10mil / Unlimited direct damage exposure',
    'Uncapped indirect damage exposure',
  ];
  contractTypeOptions = [
    'Time & Material',
    'Time & Material not to exceed',
    'Fixed Price - for milestones, time periods, deliverables',
    'Performance based rewards / penalties',
  ];
  customerCreditScoreOptions = ['Not Available', 'Less Than 4', '4 or Greater'];
  sensitiveDataOptions = [
    'No',
    'Access only',
    'Access and handling',
    'Access, handling, storage, or management',
  ];
  isComplianceAssociatedOptions = ['No', 'Yes'];
  hardwareAndEquipmentOptions = [
    'Customer supplied',
    'Combined customer and TEKsystems supplied',
    'TEKsystems supplied',
  ];
  isCoveredOptions = ['No', 'Yes'];
  whatLocationOptions = [
    'Client site only',
    'On-/near-shore TEKsystems facility or remote location',
    'Mix of client, on-/near-shore TEKsystems facility, or remote location',
    'Off-shore TEKsystems facility',
    'Mix of client, on-/near-/off-shore TEKsystems facility, or remote location',
  ];
  providedToCustomerOptions = [
    'Advisory',
    'Co-Managed',
    'Engagement'
  ];
  contractualDurationOptions = [
    'Greater Than 1 year',
    '6 months to 1 year',
    'Less Than 6 months',
  ];
  isEstablishedAccountOptions = ['No', 'Yes'];
  totalProjectedRevenueOptions = [
    'Less Than $500k',
    '$500k to $2mil',
    'Greater Than $2mil',
  ];
  engagementWithTekOptions = [
    'Greater Than 3 years',
    '1 - 3 years',
    'Less Than 1 year',
  ];
  is3rdPartyDependentOptions = ['Yes', 'No'];
  hasUniqueChallengesOptions = [
    'Yes - Location, model, and practice challenges exist',
    'No - Location, model, and practice involvement are standard',
    'Partially - Some challenges exist, but should not present significant issues',
  ];
  hasHighRiskOptions = ['Yes', 'No'];
  globalRequestSource: string;

  riskSurveyForm = this.fb.group({
    indicatorColor: [null],
    projectId: [null],
    isWarrantyApplicable: [null, Validators.required],
    liabilityLimits: [null, Validators.required],
    contractType: [null, Validators.required],
    customerCreditScore: [null, Validators.required],
    sensitiveData: [null, Validators.required],
    isComplianceAssociated: [null, Validators.required],
    hardwareAndEquipment: [null, Validators.required],
    isCovered: [null, Validators.required],
    location: [null, Validators.required],
    typeOfService: [null, Validators.required],
    contractualDuration: [null, Validators.required],
    isEstablishedAccount: [null, Validators.required],
    totalProjectedRevenue: [null, Validators.required],
    engagementWithTek: [null, Validators.required],
    is3rdPartyDependent: [null, Validators.required],
    hasUniqueChallenges: [null, Validators.required],
    hasHighRiskCategory: [null, Validators.required],
    comments: [''],
  });

  async ngOnInit(): Promise<void> {
    this.activatedRoute.params.subscribe((params) => {
      this.id = params.projectId;
      this.getLastUpdatedBy(this.id);

      if (this.id !== null && this.id && this.id !== undefined) {
        // const requestSource = window.history.state.source;
        // if (
        //   requestSource === 'project-details' ||
        //   requestSource === 'risk-survey' ||
        //   requestSource === 'opportunity'
        // ) {
        //   this.globalRequestSource = requestSource;
        //   if (requestSource === 'project-details') {
        this.getRiskSurveyData(this.id);
        this.disableForm();
        this.showOnSave = true;
        //   } else if (requestSource === 'risk-survey') {
        //     this.projectName = window.history.state.projectName;
        //     this.accountName = window.history.state.accountName;
        //     this.routedData = window.history.state.formData;
        //     if (this.routedData) {
        //       this.setDataInFormControls(this.routedData);
        //       this.disableForm();
        //       this.showOnSave = true;
        //     }
        //   } else if (requestSource === 'opportunity') {
        //     this.projectName = window.history.state.projectName;
        //     this.accountName = window.history.state.accountName;
        //     this.opportunityData = window.history.state.opportunityData;
        //     this.disableForm();
        //     this.showOnSave = true;
        //   } else {
        //     this.getRiskSurveyData(this.id);
        //     this.disableForm();
        //     this.showOnSave = true;
        //   }
        // } else {
        //   this.getRiskSurveyData(this.id);
        //   this.disableForm();
        //   this.showOnSave = true;
        // }
      }
    });
    // if (this.showOnSave === false) {
    //   this.disableForm();
    //   this.showOnSave = true;
    // }
    this.hasEditAccess = await this.authService.doesUserHaveAccessToRole(
      AccessLevel.EDIT_ACCESS
    );
  }

  onStatusReport() {
    // if (this.globalRequestSource === undefined) {
    //   this.router.navigate(['dashboard/status-report'], {
    //     state: {
    //       opportunityData: null,
    //       projectId: '',
    //       projectName: '',
    //       accountName: '',
    //       source: 'create-project'
    //     },
    //   });
    // } else if (this.globalRequestSource === 'opportunity') {
    //   this.router.navigate(['dashboard/status-report', Number(this.id)], {
    //     state: {
    //       projectId: Number(this.id),
    //       opportunityData: this.opportunityData,
    //       projectName: this.projectName,
    //       accountName: this.accountName,
    //       source: 'opportunity'
    //     },
    //   });
    // } else {
    if (
      this.id !== null &&
      this.id &&
      this.id !== undefined
      // &&
      // this.opportunityData === null
    ) {
      this.router.navigate(['dashboard/status-report', Number(this.id)], {
        state: {
          projectId: Number(this.id),
          // opportunityData: null,
          source: 'project-details',
        },
      });
    }
    // }
  }

  onProjectDetails() {
    if (
      this.id !== null &&
      this.id &&
      this.id !== undefined
      // &&
      // this.opportunityData === null
    ) {
      this.router.navigate(['dashboard/project-details', this.id], {
        state: {
          source: 'project-details',
        },
      });
    }
    // else if (
    //   this.id !== null &&
    //   this.id &&
    //   this.id !== undefined &&
    //   this.opportunityData !== null
    // ) {
    //   this.router.navigate(['dashboard/project-details', this.id], {
    //     state: {
    //       opportunityData: this.opportunityData,
    //       source: 'risk-survey-opportunity',
    //     },
    //   });
    // } else {
    //   this.router.navigate([
    //     'dashboard/available-opportunities/create-project-manually',
    //   ]);
    // }
  }
  /**
   * switching tabs
   * @param tab
   */
  onEditMode(tab) {
    if (
      this.showOnSave === false &&
      this.riskSurveyForm.touched &&
      this.riskSurveyForm.dirty &&
      !this.valueCheck
    ) {
      this.openModal(tab);
    } else {
      if (tab === '1') {
        this.onProjectDetails();
      } else {
        if (tab === '2') {
          this.onStatusReport();
        } else {
          if (tab === '3') {
            this.onSecurityProfile();
          }
        }
      }
    }
  }
  openModal(tab) {
    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = 'confirm-dialog-component';
    dialogConfig.height = '250px';
    dialogConfig.width = '600px';
    dialogConfig.data = {
      title:'Notification',
      description:
        'You have unsaved changes in this ' +
        'Risk Survey' +
        ` tab. If you want to proceed to another tab without saving,
      Click "Proceed" (or) click "Cancel" to stay on the same tab.`,
    };
    const dialogRef = this.matDialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        if (tab === '1') {
          this.onProjectDetails();
        } else {
          if (tab === '2') {
            this.onStatusReport();
          } else {
            if (tab === '3') {
              this.onSecurityProfile();
            }
          }
        }
      }
    });
  }
  getReportLog(id) {
    this.createProjectService
      .getRiskSurveyReportLogById(id)
      .subscribe((data) => {
        this.reportLogdata = data.data;
        this.datasource = new MatTableDataSource<ReportLog>(this.reportLogdata);
        if (this.datasource.data.length > 0) {
          this.tableHasData = true;
        } else {
          this.tableHasData = false;
          this.reportLogErrorMessage = 'No logs found!';
        }
      });
  }
  getLastUpdatedBy(id) {
    this.createProjectService
      .getRiskSurveyReportLogById(id)
      .subscribe((data) => {
        this.lastUpdatedAt = data.data[0].dateAndTime;
        this.lastUpdatedBy = data.data[0].lastUpdatedBy;
      });
  }
  /**
   * report log of risk survey
   */
  onOpenOfReportLog() {
    this.getReportLog(this.id);
  }

  /**
   * entering into edit mode from read only
   */
  onEdit() {
    this.buttonText = 'Update';
    this.showOnSave = false;
    this.riskSurveyForm.enable();
    Object.assign(this.valueCheckBoolean, this.riskSurveyForm.value);

    this.riskSurveyForm.valueChanges.subscribe((selectedValue) => {
      this.newCreateProjectForm = this.riskSurveyForm.value;
      this.valuechange();
      return selectedValue;
    });
  }

  valuechange() {
    if (
      JSON.stringify(this.newCreateProjectForm) ===
      JSON.stringify(this.valueCheckBoolean)
    ) {
      this.valueCheck = true;
    } else {
      this.valueCheck = false;
    }
  }

  getRiskSurveyData(id) {
    this.riskSurveyService.getRiskSurveyWithProjectId(id).subscribe((data) => {
      const riskSurveyDetails = data.data[0];
      this.resetFormData = data.data[0];
      this.setDataInFormControls(riskSurveyDetails);
      if (!riskSurveyDetails.indicatorColor) {
        this.onEdit();
      } else {
        this.riskColor = riskSurveyDetails.indicatorColor;
      }
    },
      (error: HttpErrorResponse) => {
        if (error.status === 404) {
          console.error('Id not found: ', error.message);
          this.errorMessage = 'ID not found';
          this.hasError = true;
        } else {
          console.error('API Error:', error.message);
          this.errorDialogBox('ID NOT FOUND');
          this.hasError = true;
        }
      });
  }

  errorDialogBox(message: string) {
    const dialogRef = this.dialog.open(this.errorDialogTemplate, {
      data: { message }, // Pass data to the template
      disableClose: true,
    });
  }
  closeDialogAndNavigate() {
    this.dialog.closeAll();
    this.router.navigate(['dashboard']);
  }

  disableForm() {
    this.riskSurveyForm.disable();
  }

  setDataInFormControls(riskSurveyDetails) {
    if (riskSurveyDetails.projectName && riskSurveyDetails.accountName) {
      this.projectName = riskSurveyDetails.projectName;
      this.accountName = riskSurveyDetails.accountName;
    }

    this.riskSurveyForm.controls['isWarrantyApplicable'].setValue(
      riskSurveyDetails.isWarrantyApplicable
    );
    this.riskSurveyForm.controls['liabilityLimits'].setValue(
      riskSurveyDetails.liabilityLimits
    );
    this.riskSurveyForm.controls['contractType'].setValue(
      riskSurveyDetails.contractType
    );
    this.riskSurveyForm.controls['customerCreditScore'].setValue(
      riskSurveyDetails.customerCreditScore
    );
    this.riskSurveyForm.controls['sensitiveData'].setValue(
      riskSurveyDetails.sensitiveData
    );
    this.riskSurveyForm.controls['isComplianceAssociated'].setValue(
      riskSurveyDetails.isComplianceAssociated
    );
    this.riskSurveyForm.controls['hardwareAndEquipment'].setValue(
      riskSurveyDetails.hardwareAndEquipment
    );
    this.riskSurveyForm.controls['isCovered'].setValue(
      riskSurveyDetails.isCovered
    );
    this.riskSurveyForm.controls['location'].setValue(
      riskSurveyDetails.location
    );
    this.riskSurveyForm.controls['typeOfService'].setValue(
      riskSurveyDetails.typeOfService
    );
    this.riskSurveyForm.controls['contractualDuration'].setValue(
      riskSurveyDetails.contractualDuration
    );
    this.riskSurveyForm.controls['isEstablishedAccount'].setValue(
      riskSurveyDetails.isEstablishedAccount
    );
    this.riskSurveyForm.controls['totalProjectedRevenue'].setValue(
      riskSurveyDetails.totalProjectedRevenue
    );
    this.riskSurveyForm.controls['engagementWithTek'].setValue(
      riskSurveyDetails.engagementWithTek
    );
    this.riskSurveyForm.controls['is3rdPartyDependent'].setValue(
      riskSurveyDetails.is3rdPartyDependent
    );
    this.riskSurveyForm.controls['hasUniqueChallenges'].setValue(
      riskSurveyDetails.hasUniqueChallenges
    );
    this.riskSurveyForm.controls['hasHighRiskCategory'].setValue(
      riskSurveyDetails.hasHighRiskCategory
    );
    if (
      riskSurveyDetails.comments !== null &&
      riskSurveyDetails.comments &&
      riskSurveyDetails.hasHighRiskCategory === 'Yes'
    ) {
      this.showCommentBox = true;
      this.riskSurveyForm.controls['comments'].setValue(
        riskSurveyDetails.comments
      );
    }
    if (
      riskSurveyDetails.comments !== null &&
      riskSurveyDetails.comments &&
      riskSurveyDetails.hasHighRiskCategory === 'No'
    ) {
      this.showCommentBox = false;
      this.riskSurveyForm.controls['comments'].setValue(
        riskSurveyDetails.comments
      );
    }
    this.onChange(this.riskSurveyForm.value);
  }
  /**
   * changing risk indicator color
   * using risk assesment service
   * @param event
   */
  onChange(event) {
    if (
      !this.riskSurveyForm.invalid &&
      this.riskSurveyForm.controls['isWarrantyApplicable'].value !== null
    ) {
      const riskProfile = this.riskAssessmentService.calculateRiskIndicatorScore(
        this.riskSurveyForm.value
      );
      if (
        riskProfile !== null &&
        riskProfile !== undefined &&
        riskProfile !== ''
      ) {
        if (riskProfile === 'Low Risk') {
          this.riskColor = 'green';
        } else if (riskProfile === 'Moderate Risk') {
          this.riskColor = 'orange';
        } else {
          this.riskColor = 'red';
        }
      }
    } else {
      this.riskColor = null;
      // All values are not present
    }
  }
  /**
   * saving or updating
   */
  onSave() {
    this.onChange('');
    this.riskSurveyForm.controls['projectId'].setValue(this.id);
    this.riskSurveyForm.controls['indicatorColor'].setValue(this.riskColor);
    if (this.riskSurveyForm.valid) {
      const formValue = this.riskSurveyForm.value;
      this.riskSurveyService
        .saveRiskSurvey(this.riskSurveyForm.value)
        .subscribe((data) => {
          this.router
            .navigateByUrl('/dashboard', { skipLocationChange: true })
            .then(() => {
              this.router.navigate(['dashboard/risk-survey', this.id], {
                state: {
                  formData: formValue,
                  projectName: this.projectName,
                  accountName: this.accountName,
                  source: 'risk-survey',
                },
              });
            });
        });
    }
  }
  /**
   * on cancel click
   */
  onCancel() {
    const dialogRef = this.dialog.open(CreateProjectDialogComponent);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        this.getRiskSurveyData(this.id);
        this.disableForm();
        this.showOnSave = true;
      } else if (data === false) {
        // nothing to do
      }
    });
  }
  /**
   * reset to previous form fields
   */
  onReset() {
    this.riskSurveyForm.reset();
    if (this.id !== null && this.id && this.id !== undefined) {
      this.getRiskSurveyData(this.id);
      this.showCommentBox = false;
    }
    // this.setDataInFormControls(this.resetFormData);
  }
  /**
   * making comments mandatory
   * @param select of option yes
   */
  onSelectOfHighRiskIndicator(event) {
    this.onChange(event);
    if (event.value === 'Yes') {
      this.showCommentBox = true;
    } else {
      this.showCommentBox = false;
    }
  }
  // function added to navigate to security profile
  onSecurityProfile() {
    if (
      this.id !== null &&
      this.id &&
      this.id !== undefined
      // &&
      // this.opportunityData === null
    ) {
      this.router.navigate(['dashboard/security-profile', Number(this.id)], {
        state: {
          // projectId: Number(this.id),
          // opportunityData: null,
          source: 'project-details',
        },
      });
    }
  }

  // function to navigate to status report
  // onStatusReport() {
  //   this.router.navigate(['dashboard/status-report', Number(this.id)], {
  //     state: {
  //       projectId: Number(this.id),

  //       source: 'risk-survey',
  //     },
  //   });
  // }

  onExportToExcel() {
    const projectIdForExcel =
      this.id === null || this.id === undefined ? -1 : this.id;
    const projectAndClientName = new ProjectClientName();
    projectAndClientName.projectName = this.projectName;
    projectAndClientName.accountName = this.accountName;
    this.createProjectService
      .exportSampleRiskSurvey(projectIdForExcel, projectAndClientName)
      .subscribe((data) => {
        const blob = new Blob([data], {
          type:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = 'Risk Survey.xlsx';
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
      });
  }
}
