import { TestBed } from '@angular/core/testing';

import { LoadspinnerInterceptor } from './loadspinner.interceptor';

describe('LoadspinnerInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      LoadspinnerInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: LoadspinnerInterceptor = TestBed.inject(LoadspinnerInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
