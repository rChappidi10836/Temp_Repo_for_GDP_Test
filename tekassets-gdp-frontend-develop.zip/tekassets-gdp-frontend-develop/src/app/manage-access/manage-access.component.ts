import { AfterViewInit, Component, OnChanges, OnDestroy, OnInit, ViewChild } from '@angular/core';
import {
  IconDefinition,
  faSearch,
  faPlus,
  faToggleOff,
  faTimes,
  faTimesCircle,
} from '@fortawesome/free-solid-svg-icons';
import { ManageAccessService } from './../services/manage-access.service';
import { PageEvent, MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ManageAccessModel } from '../model/AdminTabsModel';
import { ManageAccessUserComponent } from '../manage-access-user/manage-access-user.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { AdminDropdownService } from '../services/admin-dropdown.service';
import { DeleteDialogNotificationComponent } from '../delete-dialog-notification/delete-dialog-notification.component';
import { access } from 'fs';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthGuardService } from '../services/auth_guard.service';
import { AccessLevel } from '../enums/access_level';
import { SharedService } from '../services/shared.service';
import { Constants } from '../model/Constants';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-manage-access',
  templateUrl: './manage-access.component.html',
  styleUrls: ['./manage-access.component.scss'],
})
export class ManageAccessComponent implements OnInit, OnChanges , OnDestroy{
  
  dataSource = new MatTableDataSource<ManageAccessModel>();
  searchData = '';
  isChecked = true;
  currentPage = 0;
  dummyPage = 0;
  postPerPage = 15;
  showTotalPages = 1;
  maxlenth_active: number = 0;
  maxlenth_inactive: number = 0;
  maxperpage: number = 100;
  totalCount;
  orderByAttribute: any;
  sortDirection: any;
  tableData: any = [];
  tableHasData = false;
  data: any;
  activeTotalCount: any;
  inactiveTotalCount: any;
  filterData: any;
  faSearch: IconDefinition = faSearch;
  faPlus: IconDefinition = faPlus;
  faToggleOff: IconDefinition = faToggleOff;
  faTimes: IconDefinition = faTimes;
  faTimesCircle: IconDefinition = faTimesCircle;
  selectedopcoId:string;
  displayedColumns: string[] = [
    'employeeName',
    'employeeId',
    'username',
    'jobCode',
    'jobTitle',
    'supervisor',
    'location',
    'hireDate',
    // 'terminationDate',
    'access',
    'actions',
  ];
  displayedColumnsInactive: string[] = [
    'employeeName',
    'employeeId',
    'username',
    'jobCode',
    'jobTitle',
    'supervisor',
    'location',
    'hireDate',
    'terminationDate',
    'access',
  ];
  displayedColumnsToNonAdmin: string[] = [
    'employeeName',
    'employeeId',
    'username',
    'jobCode',
    'jobTitle',
    'supervisor',
    'location',
    'hireDate'
  ];
  actualPaginator: MatPaginator;
  @ViewChild(MatPaginator)
  set paginator(value: MatPaginator) {
    this.actualPaginator = value;
    this.actualPaginator.length=15;
  }
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  private sharedData:Subscription
  showAdminOptions: boolean;
  public pageSizeOptions = [];
  constructor(
    private manageAccessService: ManageAccessService,
    public dialog: MatDialog,
    private router: Router,
    private authService: AuthGuardService,
    private sharedService:SharedService
  ) {   
  
    this.sharedData=this.sharedService.observer$.subscribe((data)=>{
      if(this.sharedData){
        this.selectedopcoId=this.sharedService.sharedDataSubject.value
        this.getEmployees();
        localStorage.setItem('opcoId','');
      }
    })
  }
  ngOnDestroy(): void {
    if(this.sharedData){
      this.sharedData.unsubscribe();
    }
  }


  
  /**
   *
   * @returns paginator values to display
   */
  getPageSizeOptions() {
    if (this.maxlenth_active > this.maxperpage && this.isChecked == true) {
       this.pageSizeOptions =  [15, 20, 50, this.maxperpage, this.maxlenth_active];
    }
    else if (this.maxlenth_inactive > this.maxperpage && this.isChecked == false) {
      this.pageSizeOptions =[15, 20, 50, this.maxperpage, this.maxlenth_inactive];
    }
    else {
      this.pageSizeOptions = [15, 20, 50, this.maxperpage];
    }
  }

  ngOnChanges() {
    this.dataSource = new MatTableDataSource<ManageAccessModel>();
    this.dataSource.paginator = this.actualPaginator;
    this.dataSource.sort = this.sort;
    this.selectedopcoId=this.sharedService.sharedDataSubject.value||Constants.OPCO_ID;
  }
  current_date:Date;
  async ngOnInit() {
    this.current_date=new Date();
    Constants.CURRENT_TAB='employee-details'
    if((Constants.CURRENT_ROLE=='Executive'&&this.sharedService.sharedDataSubject.value==null)||(Constants.CURRENT_ROLE=='Admin'&&this.sharedService.sharedDataSubject.value==null)){
      this.selectedopcoId='1'
    }
    else{
    this.selectedopcoId = this.sharedService.sharedDataSubject.value||Constants.OPCO_ID;
    }
    this.getEmployees();
    this.showAdminOptions =
      true &&
      (await this.authService.doesUserHaveAccessToRole(
        AccessLevel.ADMIN_ACCESS
      ));
    this.displayedColumns = this.showAdminOptions ? this.displayedColumns : this.displayedColumnsToNonAdmin;
  }
  /**
   * api call for getting employee data
   */
  getEmployees() {
    this.manageAccessService
      .getEmployeesService(this.currentPage, this.postPerPage,this.selectedopcoId)
      .subscribe((data) => {
        this.data = data.data[0].resources;
        this.activeTotalCount = data.data[0].activeTotalCount;
        this.maxlenth_active = data.data[0].activeTotalCount;
        this.inactiveTotalCount = data.data[0].inactiveTotalCount;
        this.maxlenth_inactive = data.data[0].inactiveTotalCount;
        this.getPageSizeOptions() ;
        this.setValues();
      });
  }
  /**
   * setting employee data in table
   */
  setValues() {
    if (this.isChecked === true) {
      this.filterData = this.data.filter((project) => project.active === true);
      this.totalCount = this.activeTotalCount; 
      this.dataSource = new MatTableDataSource<ManageAccessModel>(
        this.filterData
      );
      this.dataSource.paginator=this.paginator;
      this.dataSource.sort = this.sort;
      this.dataSource.paginator.length=Math.ceil(this.maxlenth_active);  
    } else {
      this.filterData = this.data.filter((project) => project.active === false); 
      this.totalCount = this.inactiveTotalCount;
      this.dataSource = new MatTableDataSource<ManageAccessModel>(
        this.filterData
      );
      this.dataSource.paginator=this.paginator;
      this.dataSource.sort = this.sort;
      this.dataSource.paginator.length=Math.ceil(this.maxlenth_inactive);
    }  
  }
  /**
   * search functionality triggered
   * @param value to be searched
   */
  onSearch(value) {
    if (value == 'page')
      this.currentPage = 0;
    this.manageAccessService
      .searchResources(this.currentPage, this.searchData, this.postPerPage,this.selectedopcoId)
      .subscribe((data) => {
        this.data = data.data[0].resources;
        this.activeTotalCount = data.data[0].activeTotalCount;
        this.maxlenth_active = data.data[0].activeTotalCount;
        this.inactiveTotalCount = data.data[0].inactiveTotalCount;
        this.maxlenth_inactive = data.data[0].inactiveTotalCount;
        this.getPageSizeOptions();
        this.setValues();
      });
  }
  /**
   * clearing the search field
   */
  clearData() {
    this.searchData = '';
    this.getEmployees();
  }
  /**
   * moving next pages
   * @param value
   */
  switch(value) {
    this.isChecked = value;
    this.setValues();
    this.postPerPage = 15;
    this.currentPage = 0;
    this.clearData();
  }
  /**
   * sorting in asc, or desc
   * @param asc,desc
   */
  onSort(value) {
    this.orderByAttribute = value.active;
    this.sortDirection = value.direction;
  }
  /**
   * employee details according to pagination
   * @param pageData
   */
  onChangedPage(pageData: PageEvent) {
    console.log( pageData.pageIndex,pageData.pageSize)
    this.currentPage = pageData.pageIndex;
    this.postPerPage = pageData.pageSize;
    if (this.searchData === '') {
      this.getEmployees();
    } else {
      this.onSearch('value');
    }
  }
  /**
   * under actions tab for managing user role
   * @param row
   */
  onManageUser(value) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = false;
    dialogConfig.maxHeight = 1200;
    dialogConfig.width = '750px';
    dialogConfig.data = {
      data: value,
    };
    const dialogRef = this.dialog.open(ManageAccessUserComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((data) => {
      this.getEmployees();
    });
  }
  /**
   * editing employee information
   * @param row
   */
  onEdit(row) {
    sessionStorage.setItem('editData', JSON.stringify(row));
    console.log(row);
    this.router.navigateByUrl('employee-details/edit-employee');
  }
  onDelete(row) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      tab: 'manageAccess',
      data: row,
    };
    const dialogRef = this.dialog.open(
      DeleteDialogNotificationComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        this.deleteResource(row);
      }
    });
  }
  /**
   * deletion of row
   * @param row to be deleted
   */
  deleteResource(row) {
    this.manageAccessService.deleteStatusReport(row.id).subscribe((data) => {
      this.getEmployees();
    });
  }
  /**
   * excel report download
   */
  onExportToExcel() {
    this.manageAccessService
      .exportToExcelUsers(this.isChecked,this.selectedopcoId)
      .subscribe((data) => {
        const blob = new Blob([data], {
          type:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = 'ResourcesWithRoles.xlsx';
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
      });
  }
  onPageEvent = ($event) => {
    console.log($event);
    this.getEmployees();
  }
}
