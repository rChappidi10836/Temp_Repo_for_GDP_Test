import {
  Component,
  OnInit,
  ViewChild,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { AdminDropdownService } from '../services/admin-dropdown.service';
import { PageEvent, MatPaginator } from '@angular/material/paginator';
import {
  IconDefinition,
  faFilter,
  faLongArrowAltUp,
  faLongArrowAltDown,
  faPlus,
  faCircle,
  faSearch,
} from '@fortawesome/free-solid-svg-icons';
import { from, Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { startWith, map, takeUntil, take } from 'rxjs/operators';
import { MatSelect } from '@angular/material/select';
import { MatSort, MatSortable, Sort } from '@angular/material/sort';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { Router, ActivatedRoute } from '@angular/router';
import { ThemePalette } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { AdminDropdownModel } from '../model/AdminTabsModel';
import { AdminNotificationComponent } from '../admin-notification/admin-notification.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AddEditAdminComponentsComponent } from '../add-edit-admin-components/add-edit-admin-components.component';
import { DeleteDialogNotificationComponent } from '../delete-dialog-notification/delete-dialog-notification.component';
import { NotificationDialogComponent } from '../notification-dialog/notification-dialog.component';
import { SharedService } from '../services/shared.service';

@Component({
  selector: 'app-admin-components',
  templateUrl: './admin-components.component.html',
  styleUrls: ['./admin-components.component.scss'],
})
export class AdminComponentsComponent implements OnInit, OnChanges {
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatSlideToggleModule, { static: true })
  slideToggle: MatSlideToggleModule;
  // icons
  faSearch: IconDefinition = faSearch;
  faFilter: IconDefinition = faFilter;
  faLongArrowAltUp: IconDefinition = faLongArrowAltUp;
  faLongArrowAltDown: IconDefinition = faLongArrowAltDown;
  faPlus: IconDefinition = faPlus;
  faCircle: IconDefinition = faCircle;
  color: ThemePalette = 'primary';
  displayedColumns: string[] = ['name', 'action'];
  orderByAttribute: any;
  sortDirection: any;
  adminDropdownOption: string;
  requestSource: any;
  currentPage = 0;
  postPerPage = 10;
  maxlenth_active: number = 0;
  flag: number = 0;
  maxlenth_inactive: number = 0;
  maxperpage: number = 100;
  //pageSizeOptions = [10, 20, 50, 100];

  dataSource = new MatTableDataSource<AdminDropdownModel>();
  totalCount: any;
  requestedTab: string;
  data: any;
  activeTotalCount: any;
  inActiveTotalCount: any;
  filterData: any;
  searchData = '';
  fieldName = '';
  id = null;
  isChecked = true;
  active: boolean;
  fileName: string;
  opco_id: any;
  adminService: Observable<Blob>;
  adminTempService: Observable<Blob>;

  constructor(
    private adminDropdownService: AdminDropdownService,
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog,

    private sharedService:SharedService,
  ) { }
  ngOnChanges() {
    this.dataSource = new MatTableDataSource<AdminDropdownModel>();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  ngOnInit(): void {
   
    this.activatedRoute.params.subscribe((params) => {
      this.requestSource = params.requestedTab;
      this.getAdminDropdownOption();
      this.getAdminDropdownData();
    });
  }
/**
 * for paginator
 * @returns various page options
 */
  getPageSizeOptions(): number[] {
    if (this.maxlenth_active > this.maxperpage && this.isChecked == true) {
      return [10, 20, 50, this.maxperpage, this.maxlenth_active];
    }
    if (this.maxlenth_inactive > this.maxperpage && this.isChecked == false) {
      return [10, 20, 50, this.maxperpage, this.maxlenth_inactive];
    }
    else {
      return [10, 20, 50, this.maxperpage];
    }
  }
/**
 * display data by option selected in admin dropdown
 */
  getAdminDropdownOption() {
    this.searchData = '';
    this.isChecked = true;
    this.postPerPage = 10;
    this.currentPage = 0;
    if (this.requestSource === 'practiceEngagement') {
      this.adminDropdownOption = 'Practice ';
      this.fileName = 'Practice.xlsx';
      this.requestedTab = 'DeliveryOrganizationType';
    } else if (this.requestSource === 'deliveryModel') {
      this.adminDropdownOption = 'Delivery Model';
      this.fileName = 'Delivery Model.xlsx';
      this.requestedTab = 'DeliveryModel';
    } else if (this.requestSource === 'serviceType') {
      this.adminDropdownOption = 'Service Type';
      this.fileName = 'Service Type.xlsx';
      this.requestedTab = 'PrimaryServiceType';
    } else if (this.requestSource === 'locationOfServices') {
      this.adminDropdownOption = 'Location of Delivery';
      this.fileName = 'Location of Delivery.xlsx';
      this.requestedTab = 'Location';
    } else if (this.requestSource === 'contractType') {
      this.adminDropdownOption = 'Contract Type';
      this.fileName = 'Contract Type.xlsx';
      this.requestedTab = 'ContractType';
    } else if (this.requestSource === 'salesOrganization') {
      this.adminDropdownOption = 'Sales Organization';
      this.fileName = 'Sales Organization.xlsx';
      this.requestedTab = 'SalesOrganization';
    } else if (this.requestSource === 'staffingSalesRegion') {
      this.adminDropdownOption = 'Staffing Sales Region';
      this.fileName = 'Staffing Sales Region.xlsx';
      this.requestedTab = 'StaffingSalesRegion';
    } else if (this.requestSource === 'deliveryMilestones') {
      this.adminDropdownOption = 'Delivery Milestones';
      this.fileName = 'Delivery Milestones.xlsx';
      this.requestedTab = 'DeliveryMilestoneType';
    } else if (this.requestSource === 'accountName') {
      this.adminDropdownOption = 'Account Name';
      this.fileName = 'Account Name.xlsx';
      this.requestedTab = 'Client';
    }
  }
/**
 * clear data for search
 */
  clearData() {
    this.searchData = '';
    this.getAdminDropdownData();
  }
/**
 * get data according to option selected in dropdown
 * service call
 */
  getAdminDropdownData() {
    const opco_value=this.requestedTab==="Client"?this.sharedService.sharedDataSubject.value||1:undefined;
    
    this.adminDropdownService
      .getRequestedTabData(
        this.currentPage,
        this.requestedTab,
        this.postPerPage,
        opco_value,
      )
      .subscribe((data) => {
        this.data = data.data[0].adminTabDtoList;
        this.activeTotalCount = data.data[0].activeTotalCount;
        this.maxlenth_active = data.data[0].activeTotalCount;
        this.inActiveTotalCount = data.data[0].inActiveTotalCount;
        this.maxlenth_inactive = data.data[0].inActiveTotalCount;
        this.setValues();
      });
  }
  /**
   * setting values in table
   */
  setValues() {
    if (this.isChecked === true) {
      this.filterData = this.data.filter((project) => project.active === true);
      this.dataSource = new MatTableDataSource<AdminDropdownModel>(
        this.filterData
      );
      this.dataSource.sort = this.sort;
      this.totalCount = this.activeTotalCount;
    } else {
      this.filterData = this.data.filter((project) => project.active === false);
      console.log(this.filterData)
      this.dataSource = new MatTableDataSource<AdminDropdownModel>(
        this.filterData
      );
      this.dataSource.sort = this.sort;
      this.totalCount = this.inActiveTotalCount;
    }
    const sortState: Sort = {active: 'name', direction: 'asc'};
    console.log(this.sort.active);
    this.sort.active = sortState.active;
    this.sort.direction = sortState.direction;
    this.sort.sortChange.emit(sortState);
  }
/**
 * search from the table data
 */
  getAdminDropdownSearchData() {
    console.log(this.requestedTab)
    const opco_value=this.requestedTab==="Client"?this.sharedService.sharedDataSubject.value||1:undefined;
    this.adminDropdownService
      .searchRequestedTabData(
        this.currentPage,
        this.requestedTab,
        this.searchData,
        this.postPerPage,
        opco_value
      )
      .subscribe((data) => {
        this.data = data.data[0].adminTabDtoList;
        this.activeTotalCount = data.data[0].activeTotalCount;
        this.maxlenth_active = data.data[0].activeTotalCount;
        this.inActiveTotalCount = data.data[0].inActiveTotalCount;
        this.maxlenth_inactive = data.data[0].inactiveTotalCount;
        this.setValues();
      });
  }
/**
 * search functionality
 */
  onSearch() {
    this.currentPage = 0;// display result on same page
    this.getAdminDropdownSearchData();
  }
/**
 * sort data
 * @param asc,desc
 */
  onSort(value) {
    this.orderByAttribute = value.active;
    console.log(this.orderByAttribute)
    this.sortDirection = value.direction;

  }
/**
 * display data in asc on change
 * @param pageData
 */
  onChangedPage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex;
    this.postPerPage = pageData.pageSize;
    if (this.searchData === '') {
      this.getAdminDropdownData();
    } else {
      this.getAdminDropdownSearchData();
    }
  }
  /**
   * on selecting different value
   * @param value
   */
  switch(value) {
    this.isChecked = value;
    this.setValues();
    this.postPerPage = 10;
    this.currentPage = 0;
    this.clearData();
  }
/**
 * deleting action
 * @param row
 */
  onDelete(row) {
    const dialogRef = this.dialog.open(DeleteDialogNotificationComponent);
    dialogRef.afterClosed().subscribe((data) => {
      if (data === true) {
        this.deleteRow(row);
      }
    });
  }

  deleteRow(row) {
    this.adminDropdownService
      .deleteRequestedTabRow(row, this.requestedTab)
      .subscribe(
        (data) => {
          this.getAdminDropdownData();
        },
        (error) => {
          const dialogConfig = new MatDialogConfig();
          dialogConfig.autoFocus = true;
          dialogConfig.width = '500px';
          dialogConfig.data = {
            value:
              'Cannot delete ' +
              this.adminDropdownOption +
              ' since it has pending references in Projects.',
            source: 'requestedTab-delete',
          };
          const dialogRef = this.dialog.open(
            AdminNotificationComponent,
            dialogConfig
          );
        }
      );
  }

  getRow(row) {
    console.log(row);
    this.id = row.id;
    this.fieldName = row.name;
    this.active = row.active;
    this.opco_id = row.opcoId;
    
  }
/**
 * editing the particular row
 * @param value
 */
  onAddEdit(value) {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = false;
    dialogConfig.maxHeight = 1200;
    dialogConfig.width = '500px';
    dialogConfig.data = {
      description: this.adminDropdownOption,
      action: value === 'Edit' ? 'Edit' : 'Add New',
      requestedTab: this.requestedTab,
      id: value === 'Edit' ? this.id : null,
      requestSource: this.requestSource,
      fieldName: value === 'Edit' ? this.fieldName : '',
      active: value === 'Edit' ? this.active : true,
      opco_id:this.adminDropdownOption ==='Account Name'? this.opco_id :'',
    };
    const dialogRef = this.dialog.open(
      AddEditAdminComponentsComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => { });
  }
/**
 * downloading excel
 */
  onExportToExcel() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      value: this.adminDropdownOption + ' Excel is Downloading',
      source: 'project-updated',
    };
    const dialogRef = this.dialog.open(
      NotificationDialogComponent,
      dialogConfig
    );
    if(this.requestedTab==='Client'){
      console.log(this.isChecked);
      this.adminTempService=this.adminDropdownService
      .exportToExcelAdmin(this.requestedTab,this.isChecked,this.sharedService.sharedDataSubject.value||1);
      
    }else if(this.requestedTab==='DeliveryOrganizationType'){
      this.adminTempService=this.adminDropdownService
      .exportToExcelAdmin(this.requestedTab,this.isChecked);
    }else{
      this.adminTempService=this.adminDropdownService
      .exportToExcelAdmin(this.requestedTab);
    }
    this.adminTempService
    .subscribe((data) => {
      const blob = new Blob([data], {
        type:
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = this.fileName;
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
      });
  }
}
