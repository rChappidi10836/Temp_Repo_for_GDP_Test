import { Component, OnInit, ViewChild, OnChanges, AfterViewInit } from '@angular/core';
import { IconDefinition, faPlus, faEllipsisV } from '@fortawesome/free-solid-svg-icons';
import { OpportunityService } from '../services/opportunity.service';
import { OpportunityDetails } from '../model/OpportunityDetails';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
// tslint:disable-next-line: max-line-length
import { AttachOpportunityToExistingProjectComponent } from '../attach-opportunity-to-existing-project/attach-opportunity-to-existing-project.component';
import { Constants } from '../model/Constants';
import { SharedService } from '../services/shared.service';

@Component({
  selector: 'app-opportunities',
  templateUrl: './opportunities.component.html',
  styleUrls: ['./opportunities.component.scss'] 
})
export class OpportunitiesComponent implements OnInit, OnChanges,AfterViewInit {
  selectedOpco:any;

  constructor(
    private opportunityService: OpportunityService,
    private sharedService: SharedService,
    private router: Router,
    public dialog: MatDialog,
  ) { }
  ngAfterViewInit(): void {
    // this.cdr.detectChanges();
  }

  // icons
  faPlus: IconDefinition = faPlus;
  faEllipsisV: IconDefinition = faEllipsisV;

  maxlenth: number = 0;
  maxperpage: number = 100;
  public totalPages;
  public tempPage = 0;
  public currentPage = 0;
  public postPerPage = 10;
  public showTotalPages = 1;
  public pageSizeOptions = [];

  getPageSizeOptions(){
    if(this.maxlenth>this.maxperpage)
    this.pageSizeOptions= [10, 20,50,this.maxperpage, this.maxlenth];
    else
    this.pageSizeOptions= [10,20,50,this.maxperpage];
  }
  
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  displayedColumns: string[] = [
    'opportunityName',
    'accountName',
    'opportunityId',
    'closedDate',
    'startDate',
    'gsOpportunity',
    'primaryService',
    'deliveryModel',
    'practice',
    'actions'
  ];

  data = [];
  opportunityArray: MatTableDataSource<OpportunityDetails>;
locationId=[];
  // dialog
  title: string;
  path: string;
  actualPaginator: MatPaginator;
  @ViewChild(MatPaginator)
  set paginator(value: MatPaginator) {
    this.actualPaginator = value;
    this.actualPaginator.length=10;
  }
  ngOnChanges() {
    this.opportunityArray = new MatTableDataSource<OpportunityDetails>();
    this.opportunityArray.paginator = this.actualPaginator;
    this.opportunityArray.sort = this.sort;
  }


  ngOnInit() {
    this.opportunityArray = new MatTableDataSource<OpportunityDetails>(this.data);

    if(Constants.CURRENT_ROLE=='Admin' || Constants.CURRENT_ROLE=='Executive') {
      if(this.sharedService.sharedDataSubject.value==null) {
        this.selectedOpco=1
        console.log(this.selectedOpco)
      } else{
        this.selectedOpco=this.sharedService.sharedDataSubject.value
        console.log(this.selectedOpco)
      }
    } else{
      this.selectedOpco=Constants.OPCO_ID;
      console.log(this.selectedOpco)
    }
    this.getOpportunityDetails(true);
  }

/**
 * attching on existing engagement
 * @param opportunityDetails
 */
  onAttachOpportunityToExistingProject(opportunityDetails) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.width = '686px';
    dialogConfig.disableClose = true;
    dialogConfig.data = { rowData: opportunityDetails };
    const dialogRef = this.dialog.open(
      AttachOpportunityToExistingProjectComponent,
      dialogConfig
    );
  }
/**
 * for creating new engagement
 * @param row
 */
  getRecord(row) {   
    this.router.navigate(['dashboard/project-details', row.opportunityPk], {
      state: { rowData: row, source: 'opportunity' ,
       opportunityId: row.opportunityId,
       deliveryOrganizationTypeId:row.deliveryOrganizationTypeId,
       locationId:row.locationId
      },
    });
  }
/**
 * displaying details of opportunity in table format
 */
  getOpportunityDetails(isPaginator) {
    this.opportunityService.getOpportunityDetails(this.currentPage, this.postPerPage, this.selectedOpco).subscribe(
      (data) => {
        this.data = data.data[0].opportunityDtoList;
        this.totalPages = data.data[0].totalNumberOfElements;
        this.maxlenth = data.data[0].totalNumberOfElements;
        this.getPageSizeOptions();
        this.opportunityArray = new MatTableDataSource<OpportunityDetails>(this.data);
        if(isPaginator){
          this.opportunityArray.paginator=this.paginator;
          this.opportunityArray.sort = this.sort;
          this.actualPaginator.length=this.maxlenth;
        }
        this.sortTableData();        
      }
    );
  }
/**
 * using paginator for next page
 * @param pageData
 */
  onChangedPage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex;
    this.postPerPage = pageData.pageSize;
    this.getOpportunityDetails(false);
  }
/**
 * trigger excel download
 */
  exportAllOpportunitiesToExcel() {
    this.opportunityService.exportToExcelForAllOpportunities(this.selectedOpco).subscribe((data) => {
      const blob = new Blob([data], {
        type:
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      if (window.navigator && window.navigator.msSaveBlob) {
        window.navigator.msSaveBlob(blob);
        return;
      }
      const sheetUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = sheetUrl;
      link.download = 'All Opportunity Details.xlsx';
      link.dispatchEvent(
        new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window,
        })
      );
    });
  }
/**
 * sorting table content asc/desc
 */
  sortTableData() {
    this.opportunityArray.sortingDataAccessor = (
      item,
      property
    ): string | number => {
      switch (property) {
        case 'startDate': return Number(new Date(item.startDate));
        case 'closedDate': return Number(new Date(item.closedDate));
        case 'opportunityName': return item.opportunityName;
        case 'accountName': return item.accountName;
        case 'opportunityId': return item.opportunityId;
        case 'gsOpportunity': return item.gsOpportunity;
        case 'primaryService': return item.primaryService;
        case 'deliveryModel': return item.deliveryModel;
        case 'practice': return item.practice;
        default:
          return item[property];
      }
    };
  }

}
