import { Component, OnInit } from '@angular/core';
import { BroadcastService, MsalService } from '@azure/msal-angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  constructor(
    private broadcastService: BroadcastService,
    private authService: MsalService,
    private router: Router
  ) {}
  graphMeEndpoint = 'https://graph.microsoft.com/v1.0/me';
  requestObj = { scopes: ['user.read'] };
  current_date:Date;

  ngOnInit() {
    this.current_date=new Date();
    this.authService
      .acquireTokenSilent(this.requestObj)
      .then((tokenResponse) => {

        this.redirectToDashBoard();
      })
      .catch((error) => {
      });
  }

  login() {
    const isIE =
      window.navigator.userAgent.indexOf('MSIE ') > -1 ||
      window.navigator.userAgent.indexOf('Trident/') > -1;
    if (isIE) {
      this.authService.loginRedirect({
        extraScopesToConsent: ['user.read', 'openid', 'profile'],
      });
    } else {
      this.authService
        .loginPopup({
        extraScopesToConsent: ['user.read', 'openid', 'profile'],
        })
        .then(
          (data) => {
            // console.log(data);
            this.redirectToDashBoard();
          },
          (error) => {
         
          }
        );
    }
  }

  redirectToDashBoard() {
    this.router.navigate(['dashboard']);
  }
}
