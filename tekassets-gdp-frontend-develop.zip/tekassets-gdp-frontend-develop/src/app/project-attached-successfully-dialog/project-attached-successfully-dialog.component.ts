import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { IconDefinition, faTimes } from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';

@Component({
  selector: 'app-project-attached-successfully-dialog',
  templateUrl: './project-attached-successfully-dialog.component.html',
  styleUrls: ['./project-attached-successfully-dialog.component.scss']
})
export class ProjectAttachedSuccessfullyDialogComponent implements OnInit {
  faTimes: IconDefinition = faTimes;
  projectId: number;

  constructor(private router: Router, private dialogRef: MatDialogRef<
    ProjectAttachedSuccessfullyDialogComponent
  >,          @Inject(MAT_DIALOG_DATA) data) {
    this.projectId = data.projectId;
  }

  ngOnInit(): void {
  }
/**
 * after attching Opportunity back to TGS View
 */
  onClose() {
    this.dialogRef.close();
  }
/**
 * view details of project
 */
  onViewDetails() {
    this.router.navigate(['dashboard/project-details', this.projectId], {
      state: { rowData: this.projectId, source: 'attached-opportunity' },
    });
    this.onClose();
  }
/**
 * adding one more project
 */
  onAddAnotherProject() {
    this.onClose();
    this.router.navigateByUrl('/dashboard', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/dashboard/available-opportunities']);
  });
  }

}
