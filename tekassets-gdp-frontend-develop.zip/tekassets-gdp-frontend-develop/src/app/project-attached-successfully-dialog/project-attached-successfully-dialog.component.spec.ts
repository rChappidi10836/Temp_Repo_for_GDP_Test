import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectAttachedSuccessfullyDialogComponent } from './project-attached-successfully-dialog.component';

describe('ProjectAttachedSuccessfullyDialogComponent', () => {
  let component: ProjectAttachedSuccessfullyDialogComponent;
  let fixture: ComponentFixture<ProjectAttachedSuccessfullyDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectAttachedSuccessfullyDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectAttachedSuccessfullyDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
