import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';
import { AuthResponse, AuthError } from 'msal';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'GDP';
  public name = 'GDP User';

  constructor(public router: Router, private authService: MsalService) {}
  ngOnInit():void{
  this.authService.handleRedirectCallback((authError: AuthError, authResponse: AuthResponse) => {
      if (authError) {
        this.router.navigate(['/login']); 
      } else if (authResponse) {
        this.router.navigate(['/dashboard']); 
      }
    });
  }

}

  

