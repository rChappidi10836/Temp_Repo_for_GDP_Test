import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecurityExcelDialogComponent } from './security-excel-dialog.component';

describe('SecurityExcelDialogComponent', () => {
  let component: SecurityExcelDialogComponent;
  let fixture: ComponentFixture<SecurityExcelDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecurityExcelDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecurityExcelDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
