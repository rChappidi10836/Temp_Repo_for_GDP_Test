import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EngagementSoftDeleteComponent } from '../engagement-soft-delete/engagement-soft-delete.component';

@Component({
  selector: 'app-security-excel-dialog',
  templateUrl: './security-excel-dialog.component.html',
  styleUrls: ['./security-excel-dialog.component.scss']
})
export class SecurityExcelDialogComponent implements OnInit {
  message;

  constructor(@Inject(MAT_DIALOG_DATA) public data,public dialogRef : MatDialogRef<EngagementSoftDeleteComponent>) {
    this.message = data.msg }

  ngOnInit(): void {
  }

  closeDialog() {
      this.dialogRef.close();
    }
}




