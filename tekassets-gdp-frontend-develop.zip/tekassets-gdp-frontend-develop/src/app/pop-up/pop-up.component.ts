import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EngagementSoftDeleteComponent } from '../engagement-soft-delete/engagement-soft-delete.component';

@Component({
  selector: 'app-pop-up',
  templateUrl: './pop-up.component.html',
  styleUrls: ['./pop-up.component.scss']
})
export class PopUpComponent implements OnInit {
  message;

  constructor(@Inject(MAT_DIALOG_DATA) public data,public dialogRef : MatDialogRef<EngagementSoftDeleteComponent>) { 
    this.message = data.msg

  }

  ngOnInit(): void {
  }
  closeDialog() {
    this.dialogRef.close();
  }

}
