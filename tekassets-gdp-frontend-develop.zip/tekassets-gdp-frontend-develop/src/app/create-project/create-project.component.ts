import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import {
Validators,
FormBuilder,
FormArray,
FormGroup,
FormControl,
} from '@angular/forms';
import { CreateProjectService } from '../services/create-project.service';
import {
IconDefinition,
faLink,
faSearch,
faPlus,
faTrash,
faChevronRight,
faTimes,
faPen,
} from '@fortawesome/free-solid-svg-icons';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CreateProjectDialogComponent } from '../create-project-dialog/create-project-dialog.component';
import { UserSearchDialogComponent } from '../user-search-dialog/user-search-dialog.component';
import { UserSearchResetDialogComponent } from '../user-search-reset-dialog/user-search-reset-dialog.component';
import { Constants } from '../model/Constants';
import { ActivatedRoute, Router, ParamMap, Params } from '@angular/router';
import { NotificationDialogComponent } from '../notification-dialog/notification-dialog.component';
import { ReportLog } from '../model/ReportLog';
import { MatTableDataSource } from '@angular/material/table';
import { element } from 'protractor';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { DeleteDialogNotificationComponent } from '../delete-dialog-notification/delete-dialog-notification.component';
import { AuthGuardService } from '../services/auth_guard.service';
import { AccessLevel } from '../enums/access_level';
import { ThemePalette } from '@angular/material/core';
import { HttpErrorResponse } from '@angular/common/http';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { AdminDropdownService } from '../services/admin-dropdown.service';
import { IdNotPresentDialogComponent } from '../id-not-present-dialog/id-not-present-dialog.component';
import { DemoService } from '../services/demo.service';
import { SharedService } from '../services/shared.service';
import { Subscription } from 'rxjs';

@Component({
selector: 'app-create-project',
templateUrl: './create-project.component.html',
styleUrls: ['./create-project.component.scss'],
})
export class CreateProjectComponent implements OnInit,OnDestroy {
@ViewChild('errorDialogTemplate') errorDialogTemplate!: TemplateRef<any>;
hasError: boolean = false; 
buttonvalue: any;
val : any;
private sharedData: Subscription;
selectedOperatingCompany: any;
OpCompId:any;
selectedOperatingCompanyName: any;
selectedOpco: any;
isEditMode: boolean=false;
viewOpco: Subscription;
existingProjectName: any;
tempOpcoId: any;
opportunityId: any;
locationId=[];
TTPtooltip:any='';
constructor(
  private fb: FormBuilder,
  private createProjectService: CreateProjectService,
  public dialog: MatDialog,
  private activatedRoute: ActivatedRoute,
  private router: Router,
  public matDialog: MatDialog,
  private authService: AuthGuardService,
  private demoService:DemoService,
  private sharedService:SharedService 
  
) { 
  this.sharedData=this.sharedService.observer$.subscribe(()=>{ 
    if(this.sharedData){
      this.selectedOpcoId=this.sharedService.sharedDataSubject.value
      console.log(this.selectedOpcoId)
      this.parsedSelectedOpcoId= parseInt(this.selectedOpcoId, 10);
      console.log(this.parsedSelectedOpcoId)
    }
    })
    if(Constants.CURRENT_ROLE=='Admin' || Constants.CURRENT_ROLE=='Executive') {
    if(this.sharedService.sharedDataSubject.value==null) {
      this.selectedOpco=1
      console.log(this.selectedOpco)
    } else{
      this.selectedOpco=this.sharedService.sharedDataSubject.value
      console.log(this.selectedOpco)
    }
  } else{
    this.selectedOpco=Constants.OPCO_ID;
    console.log(this.selectedOpco)
  }
  this.viewOpco=this.sharedService.viewengobserver.subscribe(()=>{
    if(this.viewOpco){
      this.selectedOpco=this.sharedService.viewengopco.value;
      this.selectedOpcoId=this.sharedService.viewengopco.value;
    }
  })
}
ngOnDestroy(): void {
  if(this.sharedData){
    this.sharedData.unsubscribe();
  }
}
isDropdownDisabled(): boolean {

  return Constants.CURRENT_ROLE === 'Global Edit Access'||Constants.CURRENT_ROLE==='Global View Access';
}
get teamMembers() {
  return this.createProjectForm.get('otherTeamMembers') as FormArray;
}

// icons
faSearch: IconDefinition = faSearch;
faLink: IconDefinition = faLink;
faPlus: IconDefinition = faPlus;
faTrash: IconDefinition = faTrash;
faChevronRight: IconDefinition = faChevronRight;
faTimes: IconDefinition = faTimes;
faPen: IconDefinition = faPen;

globalDeliveryManagerLabel = Constants.GLOBAL_DELIVERY_MANAGER;
programManagerLabel = Constants.PROGRAM_MANAGER;

nationalAccountOwnerLabel = Constants.NATIONAL_ACCOUNT_OWNER;
customerSuccessLeadLabel = Constants.ENGAGEMENT_MANAGER;
osgPoaLabel = Constants.OSG_POA;
osgBoaLabel = Constants.OSG_BOA;
bdmLabel = Constants.BDM;
teamMembersNameLabel = Constants.TEAM_MEMBER_NAME;
globalDeliveryDirectorLabel = Constants.GLOBAL_DELIVERY_DIRECTOR;
opcoIdLabel = this.sharedService.sharedDataSubject.value||Constants.OPCO_ID;
currentrole = Constants.CURRENT_ROLE;
opcoconst=Constants.OPCO_ID;
public parsedSelectedOpcoId:number=this.opcoIdLabel;

createProjectForm = this.fb.group({
  projectName: [null, Validators.required],
  isFlex: [false],
  startDate: [{ value: new Date() }, Validators.required],
  accountName: [null, Validators.required],
  endDate: [{ value: new Date() }, Validators.required],
  peopleSoftEngagementId: [{ value: null, disabled: true }],
  selectedSalesOrganizationId: [null],
  peopleSoftId: [{ value: null, disabled: true }],
  selectedStaffingSaleRegionId: [null],
  opportunityId: [null],
  selectedBusinessId: [null],
  gdpId: [{ value: null, disabled: true }],
  linkToSMPSite: [null],
  opco: [null],
  targetTechnologyPlatform: [null],

  globalDeliveryManager: [null, Validators.required],
  programManager: [null],
  globalDeliveryDirector: [null, Validators.required],
  nationalAccountOwner: [null],
  customerSuccessLead: [null, Validators.required],
  osgPoa: [null],
  osgBoa: [null],
  bdm: [null],

  selectedPracticeEngagementId: [null, this.parsedSelectedOpcoId==1? Validators.required : null],
  selectedLocationOfServicesId: [null],
  selectedDeliveryModelId: [null, Validators.required],
  selectedContractTypeId: [null],
  selectedPrimaryServiceTypeId: [null],
  selectedOperatingCompanyId: [{value:null,disabled:false}, Validators.required],


  // dummy form controls
  projectId: [null],
  globalDeliveryManagerId: [null],
  programManagerId: [null],
  globalDeliveryDirectorId: [null],
  nationalAccountOwnerId: [null],
  customerSuccessLeadId: [null],
  osgPoaId: [null],
  osgBoaId: [null],
  bdmId: [null],
  memberId: [null],
  managerialInformation: [null],

  otherTeamMembers: this.fb.array([]),
});

displayedColumns: string[] = ['lastUpdatedBy', 'dateAndTime'];
reportLogdata = [];
lastUpdatedBy = '';
lastUpdatedAt = '';
datasource = new MatTableDataSource<ReportLog>();
reportLogErrorMessage = '';
titleText = 'ADD';
id: string;
opcoId: any;
showEditButton = false;
showEditOptions = false;
showAdminOptions = false;
globalRequestSource: string;
saveButtonText: string;
inEditMode = false;
sourceisOpportunity = false;
projectIdWhenSorceIsDashboard: number;
tableHasData = false;
showOnSave = false;
showCancelButton = true;
savedProjectData: Array<any> = [];
projectId: number;
existFlag = false;
errorMessage = '';
membersResourceId: Array<any> = [];
salesOrganizationDropdown: any[];
staffingSaleRegionDropdown: any[];
businessUnitDropdown: any[];
practiceEngagementDropdown: Array<any> = [];
locationOfServicesDropdown: any[];
operatingCompanyDropdown: any[];
deliveryModelDropdown: any[];
contractTypeDropdown: any[];
primaryServiceTypeDropdown: any[];
resourceRoleDropdown: any[];
filteredResourceRoleDropdown: any[];
managerialInfo: Array<any> = [];
routedDataManagerialInfo: Array<any> = [];
sourceBeforeEdit: string;
resetFormData: any;
riskSurveyData: any;
gdpId: number;
serviceType: any;
serviceTypeArray: Array<any> = [];
serviceTypeString: string;
i: any;
newCreateProjectForm: any;
valueCheckBoolean = {};
valueCheck = true;
passDueDate = false;
disttp=false;
projectActive = true;
color: ThemePalette = 'primary';
isFlex = false;
public selectedOpcoId:any;
public disableCreateOpco=false;

deliveryenable= true;
engagementopco : any;


          ngAfterViewInit(): void {

            
            console.log(this.selectedOpcoId);
            console.log(this.opcoIdLabel)
            }

      
  onSelectOfdelivery(event) {
              console.log(typeof(event.value))
                if(event.value === 8) {
                  this.deliveryenable = false;
  } else {
    this.deliveryenable = true;
  }
  console.log(this.deliveryenable)
} 

ngOnInit() {
  

  if(Constants.CURRENT_ROLE=='Admin' || Constants.CURRENT_ROLE=='Executive') {
    if(this.sharedService.sharedDataSubject.value==null) {
      this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
        Number(1)
          
      );         
      this.sharedService.emitOpco(Number(1));
    } else{
      this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
        Number(this.sharedService.sharedDataSubject.value)
      );
      this.sharedService.emitOpco(Number(this.sharedService.sharedDataSubject.value))
    }
  } else{      
    this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
      Number(Constants.OPCO_ID)
    );
    this.sharedService.emitOpco(Number(Constants.OPCO_ID));
    console.log(Constants.OPCO_ID)
    
    this.createProjectForm.controls['selectedOperatingCompanyId'].disable();
      }  
  if((Constants.CURRENT_ROLE=='Global Edit Access'||Constants.CURRENT_ROLE=='Global View Access')&&this.sharedService.sharedDataSubject.value==null){
    // this.OpCompId=1
    this.OpCompId=Constants.OPCO_ID;
    console.log(this.opcoconst)
    console.log(this.OpCompId)   
  }else{
  this.OpCompId=this.sharedService.sharedDataSubject.value||Constants.OPCO_ID;  
  console.log(this.OpCompId)    
  }
  // now
  if(Constants.CURRENT_ROLE=='Admin' || Constants.CURRENT_ROLE=='Executive') {
    if(this.sharedService.sharedDataSubject.value==null) {
      this.selectedOpcoId=1
    } else{
      this.selectedOpcoId=this.selectedOpcoId=this.sharedService.sharedDataSubject.value
    }
  } else{
    this.selectedOpcoId=Constants.OPCO_ID;
  }
  this.saveButtonText = 'Save';
  this.createProjectForm.controls['gdpId'].disable();
  this.getSalesOrganization();
  this.getStaffingSaleRegion();
  this.getBusinessUnit();
  this.getPracticeEngagement();
  this.getLocationOfServices();
  this.getOpcoDropdown();
  this.getDeliveryModel();
  this.getContractType();
  this.getPrimaryServiceType();
  this.getResourceRole();
  console.log(this.opcoIdLabel);
  console.log(typeof(this.opcoIdLabel))
  const state = history.state;
  // if (state && state.source === 'dashboard') {
  //   this.opcoId = state.opcoId;
  //   console.log('opcoId from state:', this.opcoId);
  // }
  // console.log(this.opcoId);
  this.activatedRoute.params.subscribe(async (params) => {
    this.id = params.projectId;
    console.log(this.id);
    this.getLastUpdatedBy(this.id); 
    this.showAdminOptions =
      true &&
      (await this.authService.doesUserHaveAccessToRole(
        AccessLevel.ADMIN_ACCESS
      ));
    this.showEditOptions =
      true &&
      (await this.authService.doesUserHaveAccessToRole(
        AccessLevel.EDIT_ACCESS
      ));
    if (this.id !== null && this.id) {
      const requestSource = window.history.state.source;

      if (
        requestSource === 'create-project' ||
        requestSource === 'edit' ||
        requestSource === 'opportunity' ||
        requestSource === 'dashboard' ||
        requestSource === 'attached-opportunity' ||
        requestSource === 'risk-survey' ||
        requestSource === 'risk-survey-opportunity' ||
        requestSource === 'status-report-opportunity' ||
        requestSource === 'status-report' ||
        requestSource === 'project-details'
      ) {
        if (requestSource === 'create-project') {
          this.sourceBeforeEdit = requestSource;
          this.titleText = '';
          this.showEditButton = true;
          this.globalRequestSource = requestSource;
          this.showOnSave = true;
          this.showCancelButton = false;
          this.routedDataManagerialInfo = window.history.state.managerialInfo;
          const routedData = window.history.state.formData;
          const idValue = window.history.state.gdpIdValue;
          if (routedData && idValue) {
            this.doWhenSourceIsCreateProject(routedData, idValue);
            this.getReportLog(Number(this.id));
          }
        } else if (requestSource === 'edit') {
          this.sourceBeforeEdit = requestSource;
          this.titleText = '';
          this.showEditButton = true;
          this.globalRequestSource = requestSource;
          this.showOnSave = true;
          this.showCancelButton = false;
          this.inEditMode = false;
          this.filteredResourceRoleDropdown =
            window.history.state.updatedResourceList;
          this.primaryServiceTypeDropdown = window.history.state.serviceArray;
          this.routedDataManagerialInfo = window.history.state.managerialInfo;
          const updatedFormData = window.history.state.updatedFormData;
          this.resetFormData = window.history.state.updatedFormData;
          this.gdpId = window.history.state.gdpIdValue;
          const idValue = window.history.state.gdpIdValue;
          if (updatedFormData) {
            this.doWhenSourceIsEdit(updatedFormData, idValue);
          }
        } else if (requestSource === 'opportunity') {
          this.sourceBeforeEdit = requestSource;
          this.globalRequestSource = requestSource;
          this.sourceisOpportunity = true;
          this.showOnSave = false;
          this.riskSurveyData = window.history.state.rowData;
          this.resetFormData = window.history.state.rowData;
          const routedRowData = window.history.state.rowData;
          if (routedRowData) {
            this.doWhenSourceIsOpportunity(routedRowData);
            
          }
        } else if (requestSource === 'dashboard') {
          this.sourceBeforeEdit = requestSource;
          this.titleText = '';
          this.showEditButton = true;
          this.globalRequestSource = requestSource;
          this.showCancelButton = false;
          this.showOnSave = true;
          this.resetFormData = window.history.state.rowData.projectId;
          this.riskSurveyData = window.history.state.rowData;
          const routedRowData = window.history.state.rowData;
          if (routedRowData) {
            this.projectIdWhenSorceIsDashboard = routedRowData.projectId;
            this.doWhenSourceIsDashboard(routedRowData.projectId, 'onInit');
          }
          // if (window.history.state.opcoId) {
          //   this.opcoId = window.history.state.opcoId;
          //   this.clientOpcoId = this.opcoId;
          //   // You can perform any additional logic related to opcoId here
          //   console.log('opcoId: ' + this.opcoId);
          // }
          // console.log('Engagement opcoId: ' + this.clientOpcoId);
        } else if (requestSource === 'attached-opportunity') {
          this.sourceBeforeEdit = requestSource;
          this.titleText = '';
          this.showEditButton = true;
          this.globalRequestSource = requestSource;
          this.showCancelButton = false;
          this.showOnSave = true;
          this.resetFormData = window.history.state.rowData;
          this.riskSurveyData = window.history.state.rowData;
          const routedRowData = window.history.state.rowData;
          if (routedRowData) {
            this.projectIdWhenSorceIsDashboard = routedRowData;
            this.doWhenSourceIsDashboard(routedRowData, 'onInit');
          }
        } else if (
          requestSource === 'risk-survey-opportunity' ||
          requestSource === 'status-report-opportunity'
        ) {
          this.globalRequestSource = requestSource;
          this.showOnSave = false;
          this.resetFormData = window.history.state.opportunityData;
          const routedRowData = window.history.state.opportunityData;
          if (routedRowData) {
            this.doWhenSourceIsOpportunity(routedRowData);
          }
        } else if (
          requestSource === 'risk-survey' ||
          requestSource === 'status-report' ||
          requestSource === 'project-details'
        ) {
          this.globalRequestSource = requestSource;
          this.titleText = '';
          this.showEditButton = true;
          this.showCancelButton = false;
          this.showOnSave = true;
          this.doWhenSourceIsDashboard(Number(this.id), 'onInit');
        }
      } else if (
        requestSource === 'risk-survey' ||
        requestSource === 'status-report'
      ) {
        this.globalRequestSource = requestSource;
      } else {
        this.doWhenSourceIsDashboard(Number(this.id), 'onInit');
        this.titleText = '';
        this.showEditButton = true;
        this.showCancelButton = false;
        this.showOnSave = true;
      }
    }
  });

}


someOtherFunction() {
  console.log('Inside other function: ' + this.opcoId);
}
onOperatingCompanyChange(){
  this.tempOpcoId=this.createProjectForm.controls['selectedOperatingCompanyId'].value;
  this.createProjectForm.controls['selectedOperatingCompanyId'].markAsPristine();
  if(this.createProjectForm.controls['selectedOperatingCompanyId'].value===2){
    this.createProjectForm.controls['selectedPracticeEngagementId'].clearValidators(); 
  }else if(this.createProjectForm.controls['selectedOperatingCompanyId'].value!==2){
    this.createProjectForm.controls['selectedPracticeEngagementId'].setValidators(Validators.required);
  } 
  if (
    this.createProjectForm.dirty 
  ) {  
  const dialogConfig = new MatDialogConfig();
  // The user can't close the dialog by clicking outside its body
  dialogConfig.disableClose = true;
  dialogConfig.id = 'confirm-dialog-component';
  dialogConfig.height = '250px';
  dialogConfig.width = '600px';
  dialogConfig.data = {
    title:'Alert',
    description:
      'You have unsaved changes in this ' +
      'Engagement Details ' +
      ` tab. If you want to proceed without saving,
    Click "Proceed" (or) click "Cancel" to stay on the same tab.`,
  };
const dialogRef = this.dialog.open(ConfirmDialogComponent,dialogConfig);
dialogRef.afterClosed().subscribe((result) => {
  if(result){
    if(this.createProjectForm.controls.selectedOperatingCompanyId.value===1){
      this.createProjectForm.reset();        
      this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
        Number(this.tempOpcoId)   
      );
      this.sharedService.emitviewengOpco(this.tempOpcoId);
      this.sharedService.emitOpco(this.tempOpcoId);
      
    }else if(this.createProjectForm.controls.selectedOperatingCompanyId.value===2){
      this.createProjectForm.reset();    
      this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
        Number(this.tempOpcoId)          
      );
      this.sharedService.emitviewengOpco(this.tempOpcoId);
      this.sharedService.emitOpco(this.tempOpcoId);    
    }else{
      this.createProjectForm.reset();
      this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
        Number(this.tempOpcoId)          
      );
      this.sharedService.emitviewengOpco(this.tempOpcoId);
      this.sharedService.emitOpco(this.tempOpcoId); 
    }
  }else{
    this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
      Number(this.sharedService.shareOpcoIdfromcpc.value||1)          
    );
  }
})
}else{
  if(this.createProjectForm.controls.selectedOperatingCompanyId.value===1){
    this.createProjectForm.reset();        
    this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
      Number(1)  
    ); 
    this.sharedService.emitviewengOpco(this.tempOpcoId);
    this.sharedService.emitOpco(this.tempOpcoId);    
  }else if(this.createProjectForm.controls.selectedOperatingCompanyId.value===2){
    this.createProjectForm.reset();    
    this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
      Number(2)      
    );
    this.sharedService.emitviewengOpco(this.tempOpcoId);
    this.sharedService.emitOpco(this.tempOpcoId);  
  }else{
    this.createProjectForm.reset();    
    this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
      Number(this.tempOpcoId)  
    );
    this.sharedService.emitviewengOpco(this.tempOpcoId);
    this.sharedService.emitOpco(this.tempOpcoId);
  }
}
}
onNoClick(): void {
  this.dialog.closeAll();
}


onSecurityProfile() {
  if (
    this.id !== null &&
    this.id &&
    this.id !== undefined &&
    this.globalRequestSource !== 'opportunity'
    
  ) {
    this.router.navigate(['dashboard/security-profile', Number(this.id)], {
      state: {
        projectId: Number(this.id),
        opportunityData: null,
        source: 'project-details',
      },
    });
  }
}

onEditMode(tab) {
  if (
    this.inEditMode === true &&
    this.createProjectForm.touched &&
    this.createProjectForm.dirty &&
    !this.valueCheck
  ) {
    this.openModal(tab);
  } else {
    if (tab === '1') {
      this.onStatusReport();
    } else {
      if (tab === '2') {
        this.onSecurityProfile();
      } else {
        if (tab === '3') {
          this.onRiskSurvey();
        }
      }
    }
  }
}

onStatusReport() {
  if (
    this.id !== null &&
    this.id &&
    this.id !== undefined &&
    this.globalRequestSource !== 'opportunity' 
    
  ) {
    this.router.navigate(['dashboard/status-report', Number(this.id)], {
      state: {
        opcoId:this.createProjectForm.controls.selectedOperatingCompanyId.value,
        source: 'project-details',
      },
    });
  }
}

onRiskSurvey() {
  if (
    this.id !== null &&
    this.id &&
    this.id !== undefined &&
    this.globalRequestSource !== 'opportunity'
  ) {
    this.router.navigate(['dashboard/risk-survey', Number(this.id)], {
      state: {
        source: 'project-details',
      },
    });
  }
}
openLink() {
  const url = this.createProjectForm.controls.linkToSMPSite.value;
  window.open(url, '_blank');
}

resetRoleDropdown(value) {
  if (
    value === 'FLEX' &&
    this.resourceRoleDropdown !== undefined &&
    this.resourceRoleDropdown.length > 0
  ) {
    this.filteredResourceRoleDropdown = this.resourceRoleDropdown.filter(
      (item) => {
        if (
          item.engagementType === 'COMMON' ||
          item.engagementType === 'FLEX'
        ) {
          return { id: item.resourceRoleId, name: item.resourceRoleName };
        }
      }
    );
  } else if (
    value === 'TGS' &&
    this.resourceRoleDropdown !== undefined &&
    this.resourceRoleDropdown.length > 0
  ) {
    this.filteredResourceRoleDropdown = this.resourceRoleDropdown.filter(
      (item) => {
        if (
          item.engagementType === 'COMMON' ||
          item.engagementType === 'TGS'
        ) {
          return { id: item.resourceRoleId, name: item.resourceRoleName };
        }
      }
    );
  }
}
onSelectOfPracticeEngagement(event) {
  if (event.source.triggerValue === 'Flex IT (North America)') {
    this.resetRoleDropdown('FLEX');
  } else {
    this.resetRoleDropdown('TGS');
  }
}

openModal(tab) {
  const dialogConfig = new MatDialogConfig();
  // The user can't close the dialog by clicking outside its body
  dialogConfig.disableClose = true;
  dialogConfig.id = 'confirm-dialog-component';
  dialogConfig.height = '250px';
  dialogConfig.width = '600px';
  dialogConfig.data = {
    description:
      'You have unsaved changes in this ' +
      'Project Details' +
      ` tab. If you want to proceed to another tab without saving,
    Click "Proceed" (or) click "Cancel" to stay on the same tab.`,
  };
  const dialogRef = this.matDialog.open(ConfirmDialogComponent, dialogConfig);
  dialogRef.afterClosed().subscribe((data) => {
    if (data === true) {
      if (tab === '1') {
        this.onStatusReport();
      } else {
        if (tab === '2') {
          this.onSecurityProfile();
        } else {
          if (tab === '3') {
            this.onRiskSurvey();
          }
        }
      }
    }
  });
}

resetValueOfValueCheck() {
  this.valueCheck = false;
}

onEdit() {
  this.isEditMode=true
 

  this.showEditButton = false;
  this.saveButtonText = 'Update';
  this.showOnSave = false;
  this.showCancelButton = true;
  this.inEditMode = true;
  this.titleText = 'EDIT';
  this.createProjectForm.enable();
  this.createProjectForm.controls['accountName'].disable();
  this.createProjectForm.controls['gdpId'].disable();
  this.createProjectForm.controls['peopleSoftEngagementId'].disable();
  this.createProjectForm.controls['peopleSoftId'].disable();
  // if(Constants.CURRENT_ROLE==='Executive'||Constants.CURRENT_ROLE==='Admin'){
    // this.createProjectForm.controls['selectedOperatingCompanyId'].enable(); 
  // }
  // else{
    this.createProjectForm.controls['selectedOperatingCompanyId'].disable();
  // }
  if (!this.showAdminOptions) {
    this.createProjectForm.controls['selectedBusinessId'].disable();
  } else {
    this.createProjectForm.controls['selectedBusinessId'].enable();
  }
  Object.assign(this.valueCheckBoolean, this.createProjectForm.value);
  this.setCssColor();
  if (this.globalRequestSource === 'edit') {
    this.resetRoleDropdownOnEdit(
      this.resetFormData.selectedPracticeEngagementId
    );
  }
  this.existingProjectName = this.createProjectForm.controls['projectName'].value;
  console.log(this.createProjectForm.controls['projectName'].value);
  this.createProjectForm.valueChanges.subscribe((selectedValue) => {
    this.newCreateProjectForm = this.createProjectForm.value;
    this.valuechange();
    return selectedValue;
  });

}
valuechange() {
  this.resetValueOfDropdowns();
  if (
    JSON.stringify(this.newCreateProjectForm) ===
    JSON.stringify(this.valueCheckBoolean)
  ) {
    this.valueCheck = true;
  } else {
    this.valueCheck = false;
  }
}

getReportLog(projectIdWhenSorceIsDashboard) {
  if (projectIdWhenSorceIsDashboard !== undefined) {
    this.createProjectService
      .getReportLogById(projectIdWhenSorceIsDashboard)
      .subscribe((data) => {
        this.reportLogdata = data.data;
        this.datasource = new MatTableDataSource<ReportLog>(
          this.reportLogdata
        );
        if (this.datasource.data.length > 0) {
          this.tableHasData = true;
        } else {
          this.tableHasData = false;
          this.reportLogErrorMessage = 'No logs found!';
        }
      });
  }
}

getLastUpdatedBy(projectIdWhenSorceIsDashboard) {
  if (projectIdWhenSorceIsDashboard !== undefined) {
    this.createProjectService
      .getReportLogById(projectIdWhenSorceIsDashboard)
      .subscribe((data) => {
        this.lastUpdatedAt = data.data[0].dateAndTime
          ? data.data[0].dateAndTime
          : '';
        this.lastUpdatedBy = data.data[0].lastUpdatedBy
          ? data.data[0].lastUpdatedBy
          : '';
      });
  }
}

onOpenOfReportLog() {
  let requestedProjectId: number;
  if (this.globalRequestSource === 'dashboard') {
    requestedProjectId = this.projectIdWhenSorceIsDashboard;
  } else {
    requestedProjectId = Number(this.id);
  }
  this.getReportLog(requestedProjectId);
}

setCssColorForDisabledFields() {
  return '#95989A';
}

setCssColor() {
  if (this.showOnSave === false) {
    return '#4D4F5C !important'; // dark
  } else {
    return '#95989A'; // light
  }
}


doWhenSourceIsDashboard(routedData, calledFrom) {
  
  console.log(routedData);
  
  this.createProjectService
    .getProjectDetailsById(routedData)
    .subscribe((data) => {
      const projectDetails = data.data[0];
      

      this.projectActive = !projectDetails?.closed;
      this.createProjectForm.controls['projectName'].setValue(
        projectDetails.projectName
      );
      this.createProjectForm.controls['isFlex'].setValue(
        projectDetails.isFlex
      );
     
      this.isFlex = projectDetails.isFlex;
      this.createProjectForm.controls['accountName'].setValue(
        projectDetails.accountName
      );
      this.createProjectForm.controls['gdpId'].setValue(projectDetails.gdpId);
      if (projectDetails.startDate) {
        this.createProjectForm.controls['startDate'].setValue(
          new Date(projectDetails.startDate).toISOString()
        );
      }
      if (projectDetails.endDate) {
        this.createProjectForm.controls['endDate'].setValue(
          new Date(projectDetails.endDate).toISOString()
        );
        this.passDateCheck(new Date(projectDetails.endDate));
      }
      if (projectDetails.selectedSalesOrganizationId) {
        this.createProjectForm.controls[
          'selectedSalesOrganizationId'
        ].setValue(projectDetails.selectedSalesOrganizationId);
      }
      if (projectDetails.selectedStaffingSaleRegionId) {
        this.createProjectForm.controls[
          'selectedStaffingSaleRegionId'
        ].setValue(projectDetails.selectedStaffingSaleRegionId);
      }
      if (projectDetails.selectedBusinessId) {
        this.createProjectForm.controls['selectedBusinessId'].setValue(
          projectDetails.selectedBusinessId
        );
      }
      if (projectDetails.linkToSMPSite) {
        this.createProjectForm.controls['linkToSMPSite'].setValue(
          projectDetails.linkToSMPSite
        );
      }
    
      if (projectDetails.opportunityId) {
        this.createProjectForm.controls['opportunityId'].setValue(
          projectDetails.opportunityId
        );
      }
 
      this.createProjectForm.controls['targetTechnologyPlatform'].setValue(
        projectDetails.targetTechnologyPlatform
      );
      if (projectDetails.selectedLocationOfServicesId) {
        this.createProjectForm.controls[
          'selectedLocationOfServicesId'
        ].setValue(projectDetails.selectedLocationOfServicesId);
      }
      if (projectDetails.selectedOperatingCompanyId) {
        console.log(projectDetails.selectedOperatingCompanyId);
        this.createProjectForm.controls[
          'selectedOperatingCompanyId'
        ].setValue(projectDetails.selectedOperatingCompanyId);
      }
      if (projectDetails.selectedContractTypeId) {
        this.createProjectForm.controls['selectedContractTypeId'].setValue(
          projectDetails.selectedContractTypeId
        );
      }
      if (projectDetails.selectedDeliveryModelId) {
        this.createProjectForm.controls['selectedDeliveryModelId'].setValue(
          projectDetails.selectedDeliveryModelId,
          
        );
      }
      if (projectDetails.peopleSoftEngagementId) {
        this.createProjectForm.controls['peopleSoftEngagementId'].setValue(
          projectDetails.peopleSoftEngagementId
    
        );
      }
      if (projectDetails.peopleSoftId) {
        this.createProjectForm.controls['peopleSoftId'].setValue(
          projectDetails.peopleSoftId
        );
      }
      if (projectDetails.selectedPracticeEngagementId) {
        this.createProjectForm.controls[
          'selectedPracticeEngagementId'
        ].setValue(projectDetails.selectedPracticeEngagementId  );


        if (
          this.getPracticeEngagementById(
            projectDetails.selectedPracticeEngagementId
          )
        ) {
          this.resetRoleDropdown('FLEX');
        } else {
          this.resetRoleDropdown('TGS');
        }
       
      }
      console.log(projectDetails);

      if(this.currentrole==='Global View Access'){
        console.log(this.currentrole)
        this.isDropdownDisabled();
      }
      
      this.buttonvalue = data.opcoid;
      
      this.engagementopco = Number(data.opcoid.split(" ",1)[0])
  
      this.sharedService.emitengOpco(this.engagementopco)

      
      console.log(projectDetails.selectedDeliveryModelId)
      if(projectDetails.selectedDeliveryModelId === 8) {
        this.deliveryenable = false;
        this.sharedService.emitdelivery(this.deliveryenable)
      } else {
        this.deliveryenable = true;
        this.sharedService.emitdelivery(this.deliveryenable)
      }


      console.log(this.engagementopco)
      console.log("hello")
      
      if(data.opcoid){
        this.selectedOpco=String(data.opcoid.split(" ",1)[0]);
        this.selectedOpcoId=data.opcoid.split(" ",1)[0];
        this.sharedService.emitOpco(data.opcoid.split(" ",1)[0]);
        console.log(this.selectedOpco);
        console.log(this.selectedOpco=='2')
        this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
          Number(data.opcoid.split(" ",1)[0])
        );
        // changes
        // this.sharedService.emitOpco(Number(data.opcoid.split(" ",1)[0]));
        console.log(Number(data.opcoid.split(" ",1)[0]))
      } 

      


      if (projectDetails.selectedPrimaryServiceTypeId) {
        this.createProjectForm.controls[
          'selectedPrimaryServiceTypeId'
        ].setValue(projectDetails.selectedPrimaryServiceTypeId);
        this.serviceType = projectDetails.selectedPrimaryServiceTypeId;
        for (this.i = 0; this.i <= this.serviceType.length; this.i++) {
          this.primaryServiceTypeDropdown.map((item) => {
            if (item.id === this.serviceType[this.i]) {
              this.serviceTypeArray.push(item.name);
            }
          });
        }
        this.serviceTypeString = this.serviceTypeArray.toString();
      }

      if (projectDetails.managerialInformation) {
        this.setOtherTeamMembersForProjectDetails(
          projectDetails.managerialInformation
        );
      }
            this.routedDataManagerialInfo = projectDetails.managerialInformation;
      
      if (!(calledFrom === 'reset')) {
        this.createProjectForm.controls['otherTeamMembers'].disable();
        this.disableForm();
      }
    },
    (error: HttpErrorResponse) => {
      if (error.status === 404) {
        console.error('Id not found: ', error.message);
        
        this.errorMessage = 'ID not found';
        // this.hasError = true;
        
      } else {
        console.error('API Error:', error.message);
        this.errorDialogBox('ID NOT FOUND', this.id);
        // this.hasError = true;
        console.log(this.hasError)
        
        console.log(this.id)
      }
      
      
    }

    );
}






errorDialogBox(message: string, id: string) {
  const dialogRef = this.dialog.open(IdNotPresentDialogComponent, {
    data: { message, id },
    disableClose: true,
  });
  // const dialogConfig = new MatDialogConfig();
  // dialogConfig.autoFocus = true;
  // dialogConfig.data = {
  //   value: 'Project Updated Successfully!!',
  //   source: 'project-updated',
  // };
  // const dialogRef = this.dialog.open(
  //   NotificationDialogComponent,
  //   dialogConfig
  // );
}
closeDialogAndNavigate() {
  this.dialog.closeAll();
  this.router.navigate(['dashboard']);
}

getPracticeEngagementById(id) {
  let isFlexIT = false;
  for (const item of this.practiceEngagementDropdown) {
    if (item.id === id && item.name === 'Flex IT (North America)') {
      isFlexIT = true;
      break;
    }
  }
  return isFlexIT;
}

setOtherTeamMembersForProjectDetails(projectDetailResourcesList) {
  let isFirstCsl = true;
  let isFirstGDM = true;
  let isFirstPM = true;
  let isFirstNAO = true;
  let isFirstOsgPoa = true;
  let isFirstOsgBoa = true;
  let isFirstBdm = true;
  let isFirstGDD = true;
  let index = 0;
  this.clearTeamMembers();
  const addMembers =
    this.createProjectForm.controls.otherTeamMembers['controls'];
  projectDetailResourcesList.forEach((element4) => {
    if (element4.otherTeamMember) {
      switch (element4.resourceRoleName) {
        case Constants.ENGAGEMENT_MANAGER:
          isFirstCsl = false;
          break;
        case Constants.GLOBAL_DELIVERY_MANAGER:
          isFirstGDM = false;
          break;
        case Constants.PROGRAM_MANAGER:
          isFirstPM = false;
          break;
        case Constants.GLOBAL_DELIVERY_DIRECTOR:
          isFirstGDD = false;
          break;
        case Constants.BDM:
          isFirstBdm = false;
          break;
        case Constants.NATIONAL_ACCOUNT_OWNER:
          isFirstNAO = false;
          break;
        case Constants.OSG_POA:
          isFirstOsgPoa = false;
          break;
        case Constants.OSG_BOA:
          isFirstOsgBoa = false;
          break;
      }
    }
    if (
      element4.resourceRoleName === Constants.ENGAGEMENT_MANAGER ||
      element4.resourceRoleName === Constants.GLOBAL_DELIVERY_MANAGER ||
      element4.resourceRoleName === Constants.PROGRAM_MANAGER ||
      element4.resourceRoleName === Constants.NATIONAL_ACCOUNT_OWNER ||
      element4.resourceRoleName === Constants.OSG_POA ||
      element4.resourceRoleName === Constants.OSG_BOA ||
      element4.resourceRoleName === Constants.BDM ||
      element4.resourceRoleName === Constants.GLOBAL_DELIVERY_DIRECTOR
    ) {
      if (
        element4.resourceRoleName === Constants.ENGAGEMENT_MANAGER &&
        isFirstCsl === false
      ) {
        this.addTeamMembers(index);
        addMembers[index].controls.members.setValue(element4.resourceName);
        addMembers[index].controls.role.setValue(element4.resourceRoleId);
        addMembers[index].controls.value.setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
        if (
          JSON.stringify(element4) !==
          JSON.stringify(
            projectDetailResourcesList[projectDetailResourcesList.length - 1]
          )
        ) {
          index++;
        }
      } else if (
        element4.resourceRoleName === Constants.ENGAGEMENT_MANAGER &&
        isFirstCsl === true
      ) {
        isFirstCsl = false;
        this.createProjectForm.controls['customerSuccessLead'].setValue(
          element4.resourceName
        );

        this.createProjectForm.controls['customerSuccessLeadId'].setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
      } else if (
        element4.resourceRoleName === Constants.GLOBAL_DELIVERY_MANAGER &&
        isFirstGDM === false
      ) {
        this.addTeamMembers(index);
        addMembers[index].controls.members.setValue(element4.resourceName);
        addMembers[index].controls.role.setValue(element4.resourceRoleId);
        addMembers[index].controls.value.setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
        if (
          JSON.stringify(element4) !==
          JSON.stringify(
            projectDetailResourcesList[projectDetailResourcesList.length - 1]
          )
        ) {
          index++;
        }
      } else if (
        element4.resourceRoleName === Constants.GLOBAL_DELIVERY_MANAGER &&
        isFirstGDM === true
      ) {
        isFirstGDM = false;
        this.createProjectForm.controls['globalDeliveryManager'].setValue(
          element4.resourceName
        );

        this.createProjectForm.controls['globalDeliveryManagerId'].setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
      }
      //
      else if (
        element4.resourceRoleName === Constants.PROGRAM_MANAGER &&
        isFirstPM === false
      ) {
        this.addTeamMembers(index);
        addMembers[index].controls.members.setValue(element4.resourceName);
        addMembers[index].controls.role.setValue(element4.resourceRoleId);
        addMembers[index].controls.value.setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
        if (
          JSON.stringify(element4) !==
          JSON.stringify(
            projectDetailResourcesList[projectDetailResourcesList.length - 1]
          )
        ) {
          index++;
        }
      } else if (
        element4.resourceRoleName === Constants.PROGRAM_MANAGER &&
        isFirstPM === true
      ) {
        isFirstPM = false;
        this.createProjectForm.controls['programManager'].setValue(
          element4.resourceName
        );

        this.createProjectForm.controls['programManagerId'].setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
      }
      //
      else if (
        element4.resourceRoleName === Constants.GLOBAL_DELIVERY_DIRECTOR &&
        isFirstGDD === false
      ) {
        this.addTeamMembers(index);
        addMembers[index].controls.members.setValue(element4.resourceName);
        addMembers[index].controls.role.setValue(element4.resourceRoleId);
        addMembers[index].controls.value.setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
        if (
          JSON.stringify(element4) !==
          JSON.stringify(
            projectDetailResourcesList[projectDetailResourcesList.length - 1]
          )
        ) {
          index++;
        }
      } else if (
        element4.resourceRoleName === Constants.GLOBAL_DELIVERY_DIRECTOR &&
        isFirstGDD === true
      ) {
        isFirstGDD = false;
        this.createProjectForm.controls['globalDeliveryDirector'].setValue(
          element4.resourceName
        );

        this.createProjectForm.controls['globalDeliveryDirectorId'].setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
      } else if (
        element4.resourceRoleName === Constants.NATIONAL_ACCOUNT_OWNER &&
        isFirstNAO === false
      ) {
        this.addTeamMembers(index);
        addMembers[index].controls.members.setValue(element4.resourceName);
        addMembers[index].controls.role.setValue(element4.resourceRoleId);
        addMembers[index].controls.value.setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
        if (
          JSON.stringify(element4) !==
          JSON.stringify(
            projectDetailResourcesList[projectDetailResourcesList.length - 1]
          )
        ) {
          index++;
        }
      } else if (
        element4.resourceRoleName === Constants.NATIONAL_ACCOUNT_OWNER &&
        isFirstNAO === true
      ) {
        isFirstNAO = false;
        this.createProjectForm.controls['nationalAccountOwner'].setValue(
          element4.resourceName
        );

        this.createProjectForm.controls['nationalAccountOwnerId'].setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
      } else if (
        element4.resourceRoleName === Constants.OSG_POA &&
        isFirstOsgPoa === false
      ) {
        this.addTeamMembers(index);
        addMembers[index].controls.members.setValue(element4.resourceName);
        addMembers[index].controls.role.setValue(element4.resourceRoleId);
        addMembers[index].controls.value.setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
        if (
          JSON.stringify(element4) !==
          JSON.stringify(
            projectDetailResourcesList[projectDetailResourcesList.length - 1]
          )
        ) {
          index++;
        }
      } else if (
        element4.resourceRoleName === Constants.OSG_POA &&
        isFirstOsgPoa === true
      ) {
        isFirstOsgPoa = false;
        this.createProjectForm.controls['osgPoa'].setValue(
          element4.resourceName
        );

        this.createProjectForm.controls['osgPoaId'].setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
      } else if (
        element4.resourceRoleName === Constants.OSG_BOA &&
        isFirstOsgBoa === false
      ) {
        this.addTeamMembers(index);
        addMembers[index].controls.members.setValue(element4.resourceName);
        addMembers[index].controls.role.setValue(element4.resourceRoleId);
        addMembers[index].controls.value.setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
        if (
          JSON.stringify(element4) !==
          JSON.stringify(
            projectDetailResourcesList[projectDetailResourcesList.length - 1]
          )
        ) {
          index++;
        }
      } else if (
        element4.resourceRoleName === Constants.OSG_BOA &&
        isFirstOsgBoa === true
      ) {
        isFirstOsgBoa = false;
        this.createProjectForm.controls['osgBoa'].setValue(
          element4.resourceName
        );

        this.createProjectForm.controls['osgBoaId'].setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
      } else if (
        element4.resourceRoleName === Constants.BDM &&
        isFirstBdm === false
      ) {
        this.addTeamMembers(index);
        addMembers[index].controls.members.setValue(element4.resourceName);
        addMembers[index].controls.role.setValue(element4.resourceRoleId);
        addMembers[index].controls.value.setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
        if (
          JSON.stringify(element4) !==
          JSON.stringify(
            projectDetailResourcesList[projectDetailResourcesList.length - 1]
          )
        ) {
          index++;
        }
      } else if (
        element4.resourceRoleName === Constants.BDM &&
        isFirstBdm === true
      ) {
        isFirstBdm = false;
        this.createProjectForm.controls['bdm'].setValue(
          element4.resourceName
        );

        this.createProjectForm.controls['bdmId'].setValue({
          resourceId: element4.resourceId,
          resourceRoleId: element4.resourceRoleId,
          resourceRoleName: element4.resourceRoleName,
          resourceName: element4.resourceName,
          isDeleted: false,
        });
      }
    } else {
      this.addTeamMembers(index);
      addMembers[index].controls.members.setValue(element4.resourceName);
      addMembers[index].controls.role.setValue(element4.resourceRoleId);
      addMembers[index].controls.value.setValue({
        resourceId: element4.resourceId,
        resourceRoleId: element4.resourceRoleId,
        resourceRoleName: element4.resourceRoleName,
        resourceName: element4.resourceName,
        isDeleted: false,
      });
      if (
        JSON.stringify(element4) !==
        JSON.stringify(
          projectDetailResourcesList[projectDetailResourcesList.length - 1]
        )
      ) {
        index++;
      }
    }
  });
}

doWhenSourceIsCreateProject(routedData, idValue) {
  console.log(routedData);
  this.selectedOpco=routedData.selectedOperatingCompanyId;
  this.selectedOpcoId=routedData.selectedOperatingCompanyId;
  this.sharedService.emitOpco(routedData.selectedOperatingCompanyId);
  this.onSave(routedData, idValue);
  const dialogConfig = new MatDialogConfig();
  dialogConfig.autoFocus = true;
  dialogConfig.data = {
    value: 'Project Created Successfully!!',
    source: 'create-project',
  };
  const dialogRef = this.dialog.open(
    NotificationDialogComponent,
    dialogConfig
  );
  
  if(routedData.selectedDeliveryModelId === 8) {
    this.deliveryenable = false;
    this.sharedService.emitdelivery(this.deliveryenable)
    } else {
    this.deliveryenable = true;
    this.sharedService.emitdelivery(this.deliveryenable)
    }

    



}

resetRoleDropdownOnEdit(id) {
  if (this.getPracticeEngagementById(id)) {
    this.resetRoleDropdown('FLEX');
  } else {
    this.resetRoleDropdown('TGS');
  }
}

doWhenSourceIsEdit(routedData, idValue) {

  this.selectedOpco=routedData.selectedOperatingCompanyId;
  this.selectedOpcoId=routedData.selectedOperatingCompanyId;
  this.sharedService.emitOpco(routedData.selectedOperatingCompanyId);
  this.onSave(routedData, idValue);
  const dialogConfig = new MatDialogConfig();
  dialogConfig.autoFocus = true;
  dialogConfig.data = {
    value: 'Project Updated Successfully!!',
    source: 'project-updated',
  };
  const dialogRef = this.dialog.open(
    NotificationDialogComponent,
    dialogConfig
  );
  
  if(routedData.selectedDeliveryModelId === 8) {
    this.deliveryenable = false;
    this.sharedService.emitdelivery(this.deliveryenable)
    } else {
    this.deliveryenable = true;
    this.sharedService.emitdelivery(this.deliveryenable)
    }




}

getResource(name, list) {
  let result;
  let found = false;
  if (list.length > 0 && list !== undefined) {
    list.forEach((element1) => {
      if (name === element1.resourceName) {
        found = true;
        result = element1;
      }
    });
  }
  return { status: found, value: result };
}

isTeamMemberPresent(teamMember, list) {
  let found = false;
  list.forEach((element1) => {
    if (
      element1.resourceName !== undefined &&
      element1.resourceName === teamMember
    ) {
      found = true;
    }
    if (
      element1 === teamMember &&
      element1.resourceId === undefined &&
      element1.resourceRoleId === undefined &&
      element1
    ) {
      found = true;
    }
  });
  return found;
}

mergeManagerialInformation(updatedManagerialInfo, updatedTeamMemberList) {
  if (updatedTeamMemberList !== undefined) {
    updatedTeamMemberList.forEach((teamMember) => {
      if (teamMember.role !== teamMember.value.resourceRoleId) {
        teamMember.value.resourceRoleId = teamMember.role;
      }
      if (
        !this.isTeamMemberPresent(teamMember.value, updatedManagerialInfo)
      ) {
        updatedManagerialInfo.push(teamMember.value);
      }
    });
  }
  return updatedManagerialInfo;
}

doWhenSourceIsOpportunity(row) {
    this.TTPtooltip="TTP(s) with respect to opportunities are seperated by pipe (|).";

  this.locationId.push( row.locationId)
  console.log(row)
  this.createProjectForm.controls['projectName'].setValue(
    row.opportunityName
  );
  this.createProjectForm.controls['startDate'].setValue(
    new Date(row.unformattedStartDate).toISOString()
  );
  this.createProjectForm.controls['accountName'].setValue(row.accountName);
  // Opportunity Close Date is not project End Date
  // this.createProjectForm.controls['endDate'].setValue(
  //   new Date(row.unformattedClosedDate).toISOString()
  // );
  this.createProjectForm.controls['opportunityId'].setValue(
    row.opportunityId
  );
  console.log(row.target_Technology_Platform)
  this.createProjectForm.controls['targetTechnologyPlatform'].setValue(
    row.target_Technology_Platform
  );
  const pstValues: Array<number> = [];
  pstValues.push(row.primaryServiceTypeId);
  this.createProjectForm.controls['selectedPrimaryServiceTypeId'].setValue(
    pstValues
  );
  this.createProjectForm.controls['selectedDeliveryModelId'].setValue(
    row.deliveryModelId
  );
  if(!(this.locationId.length===1 && this.locationId[0]===null)){
  this.createProjectForm.controls['selectedLocationOfServicesId'].setValue(
    this.locationId
  );
  }
  this.createProjectForm.controls['selectedPracticeEngagementId'].setValue(
    row.deliveryOrganizationTypeId
  );
  this.createProjectForm.controls['selectedSalesOrganizationId'].setValue(
    row.salesOrganizationId
  );
  if (this.getPracticeEngagementById(row.deliveryOrganizationTypeId)) {
    this.resetRoleDropdown('FLEX');
  } else {
    this.resetRoleDropdown('TGS');
  }
}

getFormContolValue(name: string) {
  return this.createProjectForm.get(name).value.name
    ? this.createProjectForm.get(name).value.name
    : '';
}

get otherTeamMembers() {
  return this.createProjectForm.get('otherTeamMembers') as FormArray;
}

addTeamMembers(value) {
  this.teamMembers.push(this.fb.group({ members: '', role: '', value: '' }));
}
clearTeamMembers() {
  const frmArray = this.createProjectForm.get(
    'otherTeamMembers'
  ) as FormArray;
  frmArray.clear();
}

deleteTeamMembers(index) {
  if (!this.showOnSave) {
    const assignValue =
      this.createProjectForm.controls.otherTeamMembers['controls'];
    assignValue[index].controls.members.markAsDirty();
    this.resetValueOfValueCheck();
    this.teamMembers.removeAt(index);
  }
}

getSalesOrganization() {
  this.createProjectService
    .getSalesOrganizationDropdown()
    .subscribe((data) => {
      this.salesOrganizationDropdown = data.data;
    });
}

getResourceRole() {
  this.createProjectService.getResourceRoleDropdown().subscribe((data) => {
    this.resourceRoleDropdown = data.data;
    this.filteredResourceRoleDropdown = this.resourceRoleDropdown;
  });
}

getStaffingSaleRegion() {
  this.createProjectService
    .getStaffingSalesRegionDropdown()
    .subscribe((data) => {
      this.staffingSaleRegionDropdown = data.data;
    });
}

getBusinessUnit() {
  this.createProjectService.getBusinessUnitDropdown().subscribe((data) => {
    this.businessUnitDropdown = data.data;
  });
}

getPracticeEngagement() {
  this.createProjectService
    .getPracticeEngagementDropdown()
    .subscribe((data) => {
      this.practiceEngagementDropdown = data.data;
    });
}

getLocationOfServices() {
  this.createProjectService
    .getLocationOfServiceDropdown()
    .subscribe((data) => {
      this.locationOfServicesDropdown = data.data;
    });
}


// onOperatingCompanySelected(event : any) {
//     const OpcoID = event.value;
//     console.log(OpcoID)
//     this.sharedService.emitOpco(OpcoID);
// }

getOpcoDropdown() {
  this.demoService.getOpcoDropdown()
    .subscribe((data) => {
      this.operatingCompanyDropdown = data.data;
      console.log(this.operatingCompanyDropdown)
      console.log(this.OpCompId)

      for(let option of this.operatingCompanyDropdown){
        console.log('Option ID:', option.id);
          console.log('Expected OpCompId:', this.OpCompId);
          if(option.id==this.OpCompId){
            console.log('Match found! Selected Company Name:', option.regionName);
          this.selectedOperatingCompanyName=option.regionName
      
                console.log(option)
                console.log(this.selectedOperatingCompanyName)
                }
              
              }
    });
}
getDeliveryModel() {
  this.createProjectService.getDeliveryModelDropdown().subscribe((data) => {
    this.deliveryModelDropdown = data.data;
  });
}

getContractType() {
  this.createProjectService.getContractTypeDropdown().subscribe((data) => {
    this.contractTypeDropdown = data.data;
  });
}

getPrimaryServiceType() {
  this.createProjectService
    .getPrimaryServiceTypeDropdown()
    .subscribe((data) => {
      this.primaryServiceTypeDropdown = data.data;
    });
}

disableForm() {
  this.createProjectForm.disable();
}

resetArrayData() {
  this.membersResourceId.length = 0;
  this.managerialInfo.length = 0;
}

onSave(routedData, id) {
  this.createProjectForm.reset(routedData);
  if (this.showOnSave === true) {
    this.createProjectForm.controls['gdpId'].enable();
  }
  this.createProjectForm.controls['gdpId'].setValue(id);
  if (this.sourceisOpportunity === false) {
    this.setOtherTeamMembers(routedData.otherTeamMembers);
  }
  this.disableForm();
  this.serviceType = routedData.selectedPrimaryServiceTypeId;
  if (this.serviceType !== undefined && this.serviceType !== null) {
    for (this.i = 0; this.i <= this.serviceType.length; this.i++) {
      this.primaryServiceTypeDropdown.map((item) => {
        if (item.id === this.serviceType[this.i]) {
          this.serviceTypeArray.push(item.name);
        }
      });
    }
    this.serviceTypeString = this.serviceTypeArray.toString();
  }
}

onResetSave(routedData, id) {
  this.selectedOpco=routedData.selectedOperatingCompanyId;
  this.selectedOpcoId=routedData.selectedOperatingCompanyId;
  this.sharedService.emitOpco(routedData.selectedOperatingCompanyId);
  this.createProjectForm.reset(routedData);
  if (this.showOnSave === true) {
    this.createProjectForm.controls['gdpId'].enable();
  }
  this.createProjectForm.controls['gdpId'].setValue(id);
  if (this.sourceisOpportunity === false) {
    this.setOtherTeamMembers(routedData.otherTeamMembers);
  }
  this.createProjectForm.enable();
  this.createProjectForm.controls['gdpId'].disable();
  this.createProjectForm.controls['peopleSoftEngagementId'].disable();
  this.createProjectForm.controls['peopleSoftId'].disable();
}

isRoutedResourceValid(member, role) {
  if (
    member === undefined ||
    member === '' ||
    role === undefined ||
    role === ''
  ) {
    return false;
  } else {
    return true;
  }
}

setOtherTeamMembers(resourcesData) {
  let index = 0;
  const assignValue =
    this.createProjectForm.controls.otherTeamMembers['controls'];
  this.clearTeamMembers();
  resourcesData.forEach((element3) => {
    if (this.isRoutedResourceValid(element3.members, element3.role)) {
      this.addTeamMembers(index);
      assignValue[index].controls.members.setValue(element3.members);
      assignValue[index].controls.role.setValue(element3.role);
      const resourceData = this.getResource(
        element3.members,
        this.routedDataManagerialInfo
      );
      this.membersResourceId.push({
        resourceData,
      });
      index++;
    }
  });
}

resetValueOfDropdowns() {
  if (
    this.createProjectForm.controls['selectedSalesOrganizationId'].value ===
    undefined
  ) {
    this.createProjectForm.controls['selectedSalesOrganizationId'].setValue(
      null
    );
  }
  if (
    this.createProjectForm.controls['selectedStaffingSaleRegionId'].value ===
    undefined
  ) {
    this.createProjectForm.controls['selectedStaffingSaleRegionId'].setValue(
      null
    );
  }
  if (
    this.createProjectForm.controls['selectedBusinessId'].value === undefined
  ) {
    this.createProjectForm.controls['selectedBusinessId'].setValue(null);
  }
  if (
    this.createProjectForm.controls['selectedPracticeEngagementId'].value ===
    undefined
  ) {
    this.createProjectForm.controls['selectedPracticeEngagementId'].setValue(
      null
    );
  }
  if (
    this.createProjectForm.controls['selectedLocationOfServicesId'].value ===
    undefined
  ) {
    this.createProjectForm.controls['selectedLocationOfServicesId'].setValue(
      null
    );
  }
  if (
    this.createProjectForm.controls['selectedOperatingCompanyId'].value ===
    undefined
  ) {
    this.createProjectForm.controls['selectedOperatingCompanyId'].setValue(
      null
    );
  }
  if (
    this.createProjectForm.controls['selectedDeliveryModelId'].value ===
    undefined
  ) {
    this.createProjectForm.controls['selectedDeliveryModelId'].setValue(null);
  }
  if (
    this.createProjectForm.controls['selectedContractTypeId'].value ===
    undefined
  ) {
    this.createProjectForm.controls['selectedContractTypeId'].setValue(null);
  }
  if (
    this.createProjectForm.controls['selectedPrimaryServiceTypeId'].value ===
    undefined
  ) {
    this.createProjectForm.controls['selectedPrimaryServiceTypeId'].setValue(
      null
    );
  }
}

ifProjectNameExist(){
  console.log(this.existingProjectName)
  if(this.createProjectForm.controls['projectName'].value === ''){
    this.createProjectForm.controls['projectName'].setErrors({'required':true});      
  }  
  else if(this.existingProjectName===undefined||this.createProjectForm.controls['projectName'].value.trim() !== this.existingProjectName.trim()){
    this.createProjectService.ifProjectNameExist(this.createProjectForm.controls['projectName'].value).subscribe((data)=>{
    if(data.data[0]){
    this.createProjectForm.controls['projectName'].setErrors({'Project Name Already Exist':data.data[0]});  
    }
    else{
      this.createProjectForm.controls['projectName'].setErrors(null);
    }   
  });
}
}

onSubmit() {
  this.createProjectForm.controls['selectedOperatingCompanyId'].enable();
  Object.assign(this.createProjectForm.value, {
    accountName: this.createProjectForm.getRawValue().accountName,
  });
  if (this.inEditMode === true) {
    const updatedFormValue = this.createProjectForm.value;      
    this.getManagerialInformationInArray();
    let requestedProjectId: number;
    if (this.globalRequestSource === 'dashboard') {
      requestedProjectId = this.projectIdWhenSorceIsDashboard;
    } else {
      requestedProjectId = Number(this.id);
    }

    this.createProjectForm.controls['projectId'].setValue(requestedProjectId);
    if (this.otherTeamMembers.value.length > 0) {
      this.createProjectForm.controls['managerialInformation'].setValue(
        this.mergeManagerialInformation(
          this.createProjectForm.controls.managerialInformation.value,
          this.otherTeamMembers.value
        )
      );
    }
    Object.assign(this.createProjectForm.value, {
      accountName: this.createProjectForm.getRawValue().accountName,
    });
    this.resetValueOfDropdowns();
    
    this.createProjectService
      .editProject(this.createProjectForm.value)
      .subscribe((data) => {
        this.router
          .navigateByUrl('/dashboard', { skipLocationChange: true })
          .then(() => {
            this.router.navigate(
              ['dashboard/project-details', requestedProjectId],
              {
                state: {
                  updatedResourceList: this.filteredResourceRoleDropdown,
                  managerialInfo:
                    this.createProjectForm.controls.managerialInformation
                      .value,
                  serviceArray: this.primaryServiceTypeDropdown,
                  updatedFormData: updatedFormValue,
                  gdpIdValue: data.data[0].gdpId,
                  source: 'project-details',
                },
              }
            );
          });
      });
  }
  if (this.createProjectForm.valid && this.inEditMode === false) {
    const formValue = this.createProjectForm.value;
    this.getManagerialInformationInArray();
    const withManagerialInfo = this.createProjectForm.value;
    let isSourceOpportunity = false;
    if (this.globalRequestSource === 'opportunity') {
      isSourceOpportunity = true;
    }
   
    this.createProjectService
      .saveProject(this.createProjectForm.value, isSourceOpportunity)
      .subscribe(
        (data) => {
          this.savedProjectData = data.data[0];
          this.projectId = data.data[0].projectId;
          this.router.navigate(
            ['dashboard/project-details', this.projectId],
            {
              state: {
                otherTeamMemberData: this.membersResourceId,
                managerialInfo:
                  this.createProjectForm.controls.managerialInformation.value,
                formData: formValue,
                gdpIdValue: data.data[0].gdpId,
                source: 'create-project',
              },
            }
          );
          
        },
        (error) => {
          
          // console.log(error.error.message)
          
          if(error.error.message==Constants.PROJECT_NAME_ERROR_MSG){
            this.resetArrayData();
            this.errorMessage = Constants.PROJECT_NAME_EXISTS;
            this.createProjectForm.get('projectName').setErrors({
              serverError: this.errorMessage,
            });
          }
          if(error.error.message==Constants.CLIENT_OPCO_ERROR_MSG){
            this.resetArrayData();
            this.errorMessage = Constants.CLIENT_OPCO_MISMATCH;
            this.createProjectForm.get('accountName').setErrors({
              serverError: this.errorMessage,
            });
          }
        }
      );
  }
}

getManagerialInformationInArray() {
  const controlReference = this.createProjectForm.controls;
  if (
    controlReference.globalDeliveryManagerId.value !== undefined &&
    controlReference.globalDeliveryManagerId.value
  ) {
    this.managerialInfo.push(
      this.createProjectForm.controls.globalDeliveryManagerId.value
    );
  }
  
  if (
    controlReference.programManagerId.value !== undefined &&
    controlReference.programManagerId.value
  ) {
    this.managerialInfo.push(
      this.createProjectForm.controls.programManagerId.value
    );
  }
  
  if (
    controlReference.globalDeliveryDirectorId.value !== undefined &&
    controlReference.globalDeliveryDirectorId.value
  ) {
    this.managerialInfo.push(
      this.createProjectForm.controls.globalDeliveryDirectorId.value
    );
  }
  if (
    controlReference.nationalAccountOwnerId.value !== undefined &&
    controlReference.nationalAccountOwnerId.value
  ) {
    this.managerialInfo.push(
      this.createProjectForm.controls.nationalAccountOwnerId.value
    );
  }
  if (
    controlReference.customerSuccessLeadId.value !== undefined &&
    controlReference.customerSuccessLeadId.value
  ) {
    this.managerialInfo.push(
      this.createProjectForm.controls.customerSuccessLeadId.value
    );
  }
  if (
    controlReference.osgPoaId.value !== undefined &&
    controlReference.osgPoaId.value
  ) {
    this.managerialInfo.push(this.createProjectForm.controls.osgPoaId.value);
  }
  if (
    controlReference.osgBoaId.value !== undefined &&
    controlReference.osgBoaId.value
  ) {
    this.managerialInfo.push(this.createProjectForm.controls.osgBoaId.value);
  }
  if (
    controlReference.bdmId.value !== undefined &&
    controlReference.bdmId.value
  ) {
    this.managerialInfo.push(this.createProjectForm.controls.bdmId.value);
  }
  if (this.membersResourceId.length > 0) {
    for (const item of this.membersResourceId) {
      if (this.isResourceValid(item)) {
        this.managerialInfo.push(item);
      }
    }
  }

  this.createProjectForm.controls['managerialInformation'].setValue(
    this.managerialInfo
  );
}

isResourceValid(item) {
  if (
    item.resourceId === undefined ||
    item.resourceId === '' ||
    item.resourceRoleId === undefined ||
    item.resourceRoleId === ''
  ) {
    return false;
  } else {
    return true;
  }
}

isResourceNonEdited(item) {
  if (item.resourceName === undefined || item.resourceName === '') {
    return false;
  } else {
    return true;
  }
}

onReset() {
  if (this.globalRequestSource === 'dashboard') {
    this.createProjectForm.reset();
    this.doWhenSourceIsDashboard(this.id, 'reset');
  } else if (this.globalRequestSource === 'opportunity') {
    this.createProjectForm.reset();
    this.doWhenSourceIsOpportunity(this.resetFormData);
    this.ngOnInit();
  } else if (this.globalRequestSource === 'edit') {
    this.createProjectForm.reset();
    this.onResetSave(this.resetFormData, this.gdpId);
  } else if (this.id == undefined){
    this.createProjectForm.reset();
    this.ngOnInit();
  } else {
    this.createProjectForm.reset();
    this.doWhenSourceIsDashboard(this.id, 'reset');
  }
}

openDialog() {
  const dialogRef = this.dialog.open(CreateProjectDialogComponent);
  dialogRef.afterClosed().subscribe((data) => {
    if (data === true) {
      if (this.id === undefined) {
        this.router.navigate(['/dashboard'], {
          state: { requestedTab: 'create-project-manually' },
        });
      } else if (this.globalRequestSource !== 'opportunity') {
        this.createProjectForm.reset();
        this.ngOnInit();
      }else{
        this.router.navigate(['/dashboard/available-opportunities'], {
          state: { 
            requestedTab: '/project-details' 
          },
        });
      }
    } else if (data === false) {
      // nothing to do
    }
  });
}

openUserSearchDialog(formControlName, label) {
  if (!this.showOnSave) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.maxHeight = 550;
    dialogConfig.width = '845px';
    const dialogRef = this.dialog.open(
      UserSearchDialogComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      this.createProjectForm.controls[formControlName + 'Id'].setValue({
        resourceId: data.resourceId,
        resourceRoleId: this.getResourceRoleIdFromControl(label),
        resourceRoleName: label,
        resourceName: data.fullName,
        isDeleted: false,
      });
      this.createProjectForm.controls[formControlName].setValue(
        data.fullName
      );
      this.createProjectForm.controls[formControlName].markAsDirty();
      this.resetValueOfValueCheck();
    });
  }
}

getResourceRoleIdFromControl(label) {
  for (const item of this.resourceRoleDropdown) {
    if (item.resourceRoleName === label) {
      return item.resourceRoleId;
    }
  }
}

openUserSearchDialogFormArray(index) {
  if (!this.showOnSave) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.maxHeight = 550;
    dialogConfig.width = '845px';
    const dialogRef = this.dialog.open(
      UserSearchDialogComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      this.existFlag = false;
      const assignValue =
        this.createProjectForm.controls.otherTeamMembers['controls'];
      assignValue[index].controls.members.setValue(data.fullName);
      assignValue[index].controls.members.markAsDirty();
      const roleId = assignValue[index].controls.role.value;
      assignValue[index].controls.value.setValue({
        resourceId: data.resourceId,
        resourceRoleId: '',
        resourceRoleName: '',
        resourceName: data.fullName,
        isDeleted: false,
      });
      if (
        data.resourceId !== undefined &&
        data.resourceId &&
        data.resourceId !== '' &&
        this.membersResourceId.length > 0
      ) {
        for (const item of this.membersResourceId) {
          if (item.resourceRoleId === roleId && roleId !== '') {
            this.existFlag = true;
            const getResource = this.getMembersbyRoleId(roleId);
            getResource.resourceId = data.resourceId;
            getResource.resourceName = data.fullName;
          }
        }
      }
      if (!this.existFlag) {
        this.existFlag = false;
        this.membersResourceId.push({
          resourceId: data.resourceId,
          resourceRoleId: '',
          resourceRoleName: '',
          resourceName: data.fullName,
          isDeleted: false,
        });
      }
    });
  }
}

getResourceRoleFromId(id) {
  for (const item of this.resourceRoleDropdown) {
    if (item.resourceRoleId === id) {
      return item.resourceRoleName;
    }
  }
}

getMembersbyName(existingFullName) {
  for (const item of this.membersResourceId) {
    if (item.resourceName === existingFullName) {
      return item;
    }
  }
}

getMembersbyRoleId(id) {
  for (const item of this.membersResourceId) {
    if (item.resourceRoleId === id) {
      return item;
    }
  }
}

onSelectOfRole(event, index) {
  const roleId = event.value;
  this.existFlag = false;
  if (
    roleId !== undefined &&
    roleId !== '' &&
    roleId &&
    this.membersResourceId.length > 0
  ) {
    for (const item of this.membersResourceId) {
      const assignValue =
        this.createProjectForm.controls.otherTeamMembers['controls'];
      const resourceFullName = assignValue[index].controls.members.value;
      if (
        item.resourceName === resourceFullName &&
        item.resourceName !== ''
      ) {
        this.existFlag = true;
        const getResource = this.getMembersbyName(resourceFullName);
        getResource.resourceRoleId = roleId;
        getResource.resourceRoleName = this.getResourceRoleFromId(roleId);
      }
    }
  }
  if (!this.existFlag) {
    this.existFlag = false;
    this.membersResourceId.push({
      resourceId: '',
      resourceRoleId: roleId,
      resourceRoleName: this.getResourceRoleFromId(roleId),
      resourceName: '',
      isDeleted: false,
    });
  }
}

resetValueDialog(label, formControlName) {
  if (!this.showOnSave) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.data = { fieldName: label, source: 'create-project' };
    const dialogRef = this.dialog.open(
      UserSearchResetDialogComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      // tslint:disable-next-line: triple-equals
      if (data == true) {
        this.createProjectForm.controls[formControlName].setValue('');
        this.createProjectForm.controls[formControlName].markAsDirty();
        this.resetValueOfValueCheck();
        this.createProjectForm.controls[formControlName + 'Id'].setValue({
          resourceRoleId: this.getResourceRoleIdFromControl(label),
          resourceRoleName: label,
          isDeleted: true,
        });
      }
    });
  }
}

resetValueDialogFromArray(label, index) {
  if (!this.showOnSave) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.data = { fieldName: label, source: 'create-project' };
    const dialogRef = this.dialog.open(
      UserSearchResetDialogComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      // tslint:disable-next-line: triple-equals
      if (data == true) {
        const assignValue =
          this.createProjectForm.controls.otherTeamMembers['controls'];
        assignValue[index].controls.members.setValue('');
        assignValue[index].controls.members.markAsDirty();
        this.resetValueOfValueCheck();
        this.membersResourceId.push({
          resourceRoleId: this.getResourceRoleIdFromControl(label),
          resourceRoleName: label,
          isDeleted: true,
        });
      }
    });
  }
}

onDelete(event) {
  const dialogRef = this.dialog.open(DeleteDialogNotificationComponent);
  dialogRef.afterClosed().subscribe((data) => {
    if (data === true) {
      this.createProjectService.deleteProject(this.id).subscribe(
        (res) => {
          // navigate back to homepage.
          this.router.navigate(['dashboard']);
        },
        (error) => {
          // handle error if required.
        }
      );
    }
  });
}

getConvertedPassDate(currentDate) {
  const yyyy = currentDate.getFullYear().toString();
  const mm = (currentDate.getMonth() + 1).toString();
  const dd = currentDate.getDate().toString();
  const mmChars = mm.split('');
  const ddChars = dd.split('');
  return (
    yyyy +
    '-' +
    (mmChars[1] ? mm : '0' + mmChars[0]) +
    '-' +
    (ddChars[1] ? dd : '0' + ddChars[0])
  );
}

passDateCheck(endDate) {
  const currDate = new Date();
  endDate = this.getConvertedPassDate(endDate);
  const convertedCurrDate = this.getConvertedPassDate(currDate);
  if (endDate < convertedCurrDate) {
    this.passDueDate = true;
  } else {
    this.passDueDate = false;
  }
  return this.passDueDate;
}

}
