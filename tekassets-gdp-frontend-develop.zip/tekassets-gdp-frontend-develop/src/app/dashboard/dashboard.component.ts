import {
  Component,
  Input,
  OnInit,
  ViewChild,
  OnDestroy,
  AfterViewInit,
  OnChanges,
  ViewEncapsulation,
  EventEmitter,
  Output,
} from '@angular/core';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { DemoService } from '../services/demo.service';
import { PageEvent, MatPaginator } from '@angular/material/paginator';
import {
  IconDefinition,
  faFilter,
  faLongArrowAltUp,
  faLongArrowAltDown,
  faPlus,
  faCircle,
  faTimesCircle,
  faSlidersH,
} from '@fortawesome/free-solid-svg-icons';
import { from, Observable, ReplaySubject, Subject, Subscription } from 'rxjs';
import { FormsModule, FormControl } from '@angular/forms';
import { startWith, map, takeUntil, take } from 'rxjs/operators';
import { MatSelect } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { Filter } from '../model/Filter';
import { SearchProject } from '../model/SearchProject';
import { Project } from '../model/Project';
import { Router } from '@angular/router';
import { MatOption } from '@angular/material/core';
import { Constants } from '../model/Constants';
import { AuthGuardService } from '../services/auth_guard.service';
import { AccessLevel } from '../enums/access_level';
import { SummarypopupComponent } from '../summarypopup/summarypopup.component';
import { MatDialog } from '@angular/material/dialog';
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { faThemeisle } from '@fortawesome/free-brands-svg-icons';
import { AdminDropdownService } from '../services/admin-dropdown.service';
import { constants } from 'buffer';
import { SharedService } from '../services/shared.service';
import { isNull } from '@angular/compiler/src/output/output_ast';
import { Placeholder } from '@angular/compiler/src/i18n/i18n_ast';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition(
        'expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')
      ),
    ]),
  ],
})
export class DashboardComponent
  implements OnInit, AfterViewInit, OnDestroy, OnChanges {

 
  selectedEngagementStatus = 1;
  selectedAccountId = [-1];
  selectedPracticeEngagementId = [-1];
  selectedCsl = [-1];
  selectedGdpId = -1;
  selectedGdmId = [-1];
  selectedPmId = [-1];
  selectedGddId = [-1];
  selectedBuId = [-1];
  selectedTtp =[-1];  
  selectedPsId = -1;
  selectedLOD = [-1];
  selectedDmId = [-1]

  // flags to select deselect default dropdowns
  disableAllGDM = false;
  disableAllPM = false;
  disableAllGDD = false;
  disableAllCSL = false;
  disableAllBU = false;  
  disableAllTtp = false;
  disableAllPractice = false;
  disableAllAccount = false;
  disableAllPsId = false;
  disableAllLOD = false;
  disableAllDM = false;
  private sharedData:Subscription
  sharedDataNavbar: Subscription;
  TempVar:boolean=false;
  cacheOpco:any;
  previousTab: string;
  temp: boolean=false;
  localOpco: any;
  selectedTtpIndexes: number[];


  constructor(
    private breakpointObserver: BreakpointObserver,
    private demoService: DemoService,
    private router: Router,
    private authService: AuthGuardService,
    private dialog: MatDialog,
    private adminDropdownService: AdminDropdownService,
    private sharedService:SharedService
  ) {
        this.sharedData=this.sharedService.observer$.subscribe((data)=>{
        if(this.sharedData){
          this.selectedOpcoId=this.sharedService.sharedDataSubject.value;
          this.cacheOpco=this.sharedService.sharedDataSubject.value;
          if(localStorage.getItem('opcoId')!=this.selectedOpcoId||this.selectedOpcoId===''){
            this.onClear();
          }
        this.parsedSelectedOpcoId= parseInt(this.selectedOpcoId, 10);     
      } 
      
    })
  }
  data = [];
  searchedData = [];
  checkFlag = true;
  current_date:Date;

  /** control for the selected option */
  public projectCtrl: FormControl = new FormControl();
  public accountNameCtrl: FormControl = new FormControl();
  public cslCtrl: FormControl = new FormControl();
  public gdpIdCtrl: FormControl = new FormControl();
  public gdmCtrl: FormControl = new FormControl();
  public pmCtrl: FormControl = new FormControl();
  public gddCtrl: FormControl = new FormControl();
  public buCtrl: FormControl = new FormControl();
  public ttpCtrl: FormControl = new FormControl();
  public psIdCtrl: FormControl = new FormControl();
  public lodCtrl: FormControl = new FormControl();
  public dmCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword */
  public projectFilterCtrl: FormControl = new FormControl();
  public accountNameFilterCtrl: FormControl = new FormControl();
  public cslFilterCtrl: FormControl = new FormControl();
  public gdpIdFilterCtrl: FormControl = new FormControl();
  public gdmFilterCtrl: FormControl = new FormControl();
  public pmFilterCtrl: FormControl = new FormControl();
  public gddFilterCtrl: FormControl = new FormControl();
  public buFilterCtrl: FormControl = new FormControl();
  public ttpFilterCtrl: FormControl = new FormControl();
  public psIdFilterCtrl: FormControl = new FormControl();
  public lodFilterCtrl: FormControl = new FormControl();
  public dmFilterCtrl: FormControl = new FormControl();

  
  // tslint:disable-next-line: ban-types
  public filteredProjects: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  // tslint:disable-next-line: ban-types
  public filteredAccountName: ReplaySubject<any[]> = new ReplaySubject<any[]>(
    1
  );
  // tslint:disable-next-line: ban-types
  public filteredCsl: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public filteredGdm: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public filteredPm: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public filteredGdd: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  // tslint:disable-next-line: ban-types
  public filteredGdpId: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public filteredBUs: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public filteredTtps: ReplaySubject<Filter[]> = new ReplaySubject<Filter[]>(1);
  public filteredPSIds: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public filteredLODs: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  public filteredDMs: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

  // icons
  faFilter: IconDefinition = faFilter;
  faLongArrowAltUp: IconDefinition = faLongArrowAltUp;
  faLongArrowAltDown: IconDefinition = faLongArrowAltDown;
  faPlus: IconDefinition = faPlus;
  faCircle: IconDefinition = faCircle;
  faSlidersH: IconDefinition = faSlidersH;
  faTimesCircle: IconDefinition = faTimesCircle;

  

  maxlenth: number = 0;
  maxperpage: number = 100;
  public totalPages;
  public tempPage = 0;
  public currentPage = 0;
  public postPerPage = 15;
  public showTotalPages = 1;
  public projectsArray: Array<any>;
  public addProjectsButtonVisible;
  public operatingCompanyButtonVisible;
  selectedOpcoId: any;
  parsedSelectedOpcoId:number;
  actualPaginator: MatPaginator;
  @ViewChild(MatPaginator)
  set paginator(value: MatPaginator) {
    console.log(value);
    this.actualPaginator = value;
  }
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  itemsPerPage: number[];

  getPageSizeOptions() {
    if (this.maxlenth > this.maxperpage)
      this.itemsPerPage = [15, 20, 50, this.maxperpage, this.maxlenth];
    else this.itemsPerPage = [15, 20, 50, this.maxperpage];
  }

  /** Subject that emits when the component has been destroyed. */
  protected onDestroy = new Subject<void>();

  displayedColumns: string[] = [
    'status',
    'projectName',
    'accountName',
    'gdm',
    'csl',
    'statusDate',
    'phase',
  ];
  columnsToDisplayWithSummary = [...this.displayedColumns, 'statusSummary'];
  expandedElement: Project | null;
  public projectStatusArray = new MatTableDataSource<Project>();

  // filter source
  engagementStatusFilterSource: any[] = [
    { value: 1, viewValue: 'Active' },
    { value: 0, viewValue: 'Closed' },
    { value: 2, viewValue: 'All Engagements' },
  ];
  // filter options
  engagementStatusFilterOptions: any[];
  accountNameFilterOptions: Filter[];
  practiceEngagementsFilterOptions: Filter[];
  cslFilterOptions: Filter[];
  gdmFilterOptions: Filter[];
  pmFilterOptions: Filter[];
  gddFilterOptions: Filter[];
  gdpIdFilterOptions: Filter[];
  buIdFilterOptions: Filter[];
  ttpFilterOptions: Filter[] ;
  psIdFilterOptions: Filter[];
  lodFilterOptions: Filter[];
  dmFilterOptions: Filter[];
  operatingCompanyDropdown: any[];
  opcoId=Constants.OPCO_ID;
  // for engagement status default value
  defaultEngagementStatusValue: number;

  // on search click
  filterValues: SearchProject;
  orderByAttribute: 'projectName';
  sortDirection: 'asc';

  errorMessage = '';
  tableHasData = false;

  ngOnChanges() {
    this.projectStatusArray = new MatTableDataSource<Project>();
    this.sortDate();
    this.projectStatusArray.paginator = this.paginator;
    this.projectStatusArray.sort = this.sort;  
  }

  async ngOnInit() { 
    Constants.CURRENT_TAB='dashboard'
    this.localOpco=localStorage.getItem('opcoId');    
    this.current_date=new Date();
    this.filterValues = new SearchProject();
    this.filterValues.active = 1;
    this.filterValues.clientId = [-1];
    this.filterValues.deliveryOrganizationTypeId = [-1];
    this.filterValues.cslId = [-1];
    this.filterValues.gdmId = [-1];
    this.filterValues.programManagerId = [-1];
    this.filterValues.gddId = [-1];
    this.filterValues.projectId = -1;
    this.filterValues.businessUnitId = [-1];
    this.filterValues.ttpId = [-1];
    this.filterValues.psId = -1;
    this.filterValues.lodId = [-1];
    this.filterValues.dmId = [-1];
    this.defaultEngagementStatusValue = 1;
    if(((Constants.CURRENT_ROLE=='Executive'||Constants.CURRENT_ROLE=='Admin')&&this.sharedService.sharedDataSubject.value==null)){
      this.selectedOpcoId=1;
    }
    else if(this.sharedService.sharedDataSubject.value){
      this.selectedOpcoId = this.sharedService.sharedDataSubject.value;
    }
    else if(Constants.CURRENT_ROLE=='Global Edit Access'||Constants.CURRENT_ROLE=='Global View Access'){
        this.selectedOpcoId =Constants.OPCO_ID;
    }
    this.cacheOpco=localStorage.getItem('opcoId');
    
    if (this.isFilterCached() && this.localOpco.replace(null,'') && (localStorage.getItem('opcoId')===this.selectedOpcoId|| this.sharedService.sharedDataSubject.value==null)) {
      console.log("ngOnInit", this.selectedOpcoId);
      this.readFilterCache();
      this.onSearch();
    } else {
      this.getProjectStatusDetails(false);
    }  
    this.getAllProjectFilterValues(this.filterValues); 
    this.addProjectsButtonVisible =
      await this.authService.doesUserHaveAccessToRole(AccessLevel.EDIT_ACCESS); 

  }

   trackById(index: number, item: any): any {
    return item.id;
  }

 
  onExportToExcel() {
    const flag = this.isFilterCriteriaApplied();
    if (flag) {
      this.exportAllProjectsToExcel();
    } else {
      this.exportSearchedProjectsToExcel();
    }
  }


  isFilterCriteriaApplied() {
    return (
      (this.selectedEngagementStatus === 1 ||
        this.selectedEngagementStatus === undefined) &&
      (this.selectedAccountId === [-1] ||
        this.selectedAccountId === undefined) &&
      (this.selectedPracticeEngagementId === [-1] ||
        this.selectedPracticeEngagementId === undefined) &&
      (this.selectedCsl === [-1] || this.selectedCsl === undefined) &&
      (this.selectedGdmId === [-1] || this.selectedGdmId === undefined) &&
      (this.selectedPmId === [-1] || this.selectedPmId === undefined) &&
      (this.selectedGddId === [-1] || this.selectedGddId === undefined) &&
      (this.selectedGdpId === -1 || this.selectedGdpId === undefined) &&
      (this.selectedPsId === -1 || this.selectedPsId === undefined) &&
      (this.selectedDmId === [-1] || this.selectedDmId === undefined)&&
      // (this.selectedLOD === [-1] || this.selectedLOD === undefined)
       (this.selectedTtp === [-1] || this.selectedTtp === undefined)
    );
  }

  exportSearchedProjectsToExcel() {
    this.filterValues.active =
      this.selectedEngagementStatus === undefined
        ? 1
        : this.selectedEngagementStatus;
    this.filterValues.clientId =
      this.selectedAccountId === undefined ? [-1] : this.selectedAccountId;
    this.filterValues.deliveryOrganizationTypeId =
      this.selectedPracticeEngagementId === undefined
        ? [-1]
        : this.selectedPracticeEngagementId;
    this.filterValues.cslId =
      this.selectedCsl === undefined ? [-1] : this.selectedCsl;
    this.filterValues.gdmId =
      this.selectedGdmId === undefined ? [-1] : this.selectedGdmId;
    this.filterValues.programManagerId =
      this.selectedPmId === undefined ? [-1] : this.selectedPmId;
    this.filterValues.gddId =
      this.selectedGddId === undefined ? [-1] : this.selectedGddId;
    this.filterValues.projectId =
      this.selectedGdpId === undefined ? -1 : this.selectedGdpId;
    this.filterValues.psId =
      this.selectedPsId === undefined ? -1 : this.selectedPsId;
    this.filterValues.lodId =
      this.selectedLOD === undefined ? [-1] : this.selectedLOD;
    this.filterValues.dmId =
      this.selectedDmId === undefined ? [-1] : this.selectedDmId;
      this.filterValues.ttpId =
      this.selectedTtp === undefined ? [-1] : this.selectedTtp;

    this.filterValues.orderByAttribute = 'projectName';
    this.filterValues.sortDirection = 'asc';
    this.exportFilteredProjects(this.filterValues);
  }

  exportFilteredProjects(filterValues) {
    this.demoService
      .exportToExcelForFilteredProjects(this.filterValues, this.selectedOpcoId)
      .subscribe((data) => {
        const blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        if (window.navigator && window.navigator.msSaveBlob) {
          window.navigator.msSaveBlob(blob);
          return;
        }
        const sheetUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = sheetUrl;
        link.download = 'Filtered Engagement Details.xlsx';
        link.dispatchEvent(
          new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
      });
  }

  exportAllProjectsToExcel() {
    this.demoService.exportToExcelForAllProjects().subscribe((data) => {
      const blob = new Blob([data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      if (window.navigator && window.navigator.msSaveBlob) {
        window.navigator.msSaveBlob(blob);
        return;
      }
      const sheetUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = sheetUrl;
      link.download = 'All Engagement Details.xlsx';
      link.dispatchEvent(
        new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window,
        })
      );
    });
  }

  getRecord(row) {
    this.router.navigate(['dashboard/project-details', row.projectId], {
      state: { rowData: row, source: 'dashboard' },
    });
  }

  onStatusDate(row) {
    this.router.navigate(['dashboard/status-report', row.projectId], {
      state: { rowData: row, source: 'project-details' },
    });
  }
  onSort(value) {
    this.orderByAttribute = value.active;
    this.sortDirection = value.direction;
  }

  ngAfterViewInit() {
    this.setInitialValuePracticeEngagement();
    this.setInitialValueAccountName();
    this.setInitialValuecsl();
    this.setInitialValueGdpId();
    this.setInitialValueGdm();
    this.setInitialValuePm();
    this.setInitialValueGdd();
    this.setInitialValueTtp();
    this.setInitialValuePsId();  
    this.setInitialValueLOD();
    this.setInitialValueDM();
  }

  ngOnDestroy() {
    if(this.sharedData){
      this.sharedData.unsubscribe();
    }
    this.onDestroy.next();
    this.onDestroy.complete();
  }

  onSelectOfEngagementStatus(event) {
    this.selectedEngagementStatus = event.value;
    this.selectedAccountId = [-1];
    this.selectedPracticeEngagementId = [-1];
    this.selectedCsl = [-1];
    this.selectedGdmId = [-1];
    this.selectedPmId = [-1];
    this.selectedGddId = [-1];
    this.selectedGdpId = -1;
    this.selectedBuId = [-1];
    
    this.selectedPsId = -1;
    this.selectedLOD = [-1];
    this.selectedDmId = [-1];
    this.onSearch();
  }

  onSelectOfAccountName(event) {
    let array = event.value;
    if (
      (array.indexOf(-1) > -1 && this.disableAllAccount) ||
      array.length === 0
    ) {
      // select -1 and remove other selections
      this.selectedAccountId = [-1];
      this.accountNameCtrl.setValue(this.selectedAccountId);
      this.disableAllAccount = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
     
    }
    
    this.disableAllAccount = true;
    this.selectedAccountId = array;
    this.accountNameCtrl.setValue(array);
    this.onSearch();
   
  }

  onSelectOfPracticeEngagement(event) {
    let array = event.value;

    if (
      (array.indexOf(-1) > -1 && this.disableAllPractice) ||
      array.length === 0
    ) {
      // select -1 and remove other selections
      this.selectedPracticeEngagementId = [-1];
      this.projectCtrl.setValue(this.selectedPracticeEngagementId);

      this.disableAllPractice = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
    }
    this.disableAllPractice = true;
    this.selectedPracticeEngagementId = array;
    this.projectCtrl.setValue(array);
    this.onSearch();
    
  }

  OnselectOfCsl(event) {
    let array = event.value;
    if ((array.indexOf(-1) > -1 && this.disableAllCSL) || array.length === 0) {
      // select -1 and remove other selections
      this.selectedCsl = [-1];
      this.cslCtrl.setValue(this.selectedCsl);

      this.disableAllCSL = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
    }
    this.disableAllCSL = true;
    this.selectedCsl = array;
    this.cslCtrl.setValue(array);
    this.onSearch(); 
  }

  onSelectOfLOD(event) {
    let array = event.value;
    if ((array.indexOf(-1) > -1 && this.disableAllLOD) || array.length === 0) {
      // select -1 and remove other selections
      this.selectedLOD = [-1];
      this.lodCtrl.setValue(this.selectedLOD);

      this.disableAllLOD = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
    }
    this.disableAllLOD = true;
    this.selectedLOD = array;
    this.lodCtrl.setValue(array);
    this.onSearch(); 
  }

  onSelectOfDm(event) {
    let array = event.value;
    if ((array.indexOf(-1) > -1 && this.disableAllDM) || array.length === 0) {
      // select -1 and remove other selections
      this.selectedDmId = [-1];
      this.dmCtrl.setValue(this.selectedDmId);

      this.disableAllDM = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
    }
    this.disableAllDM = true;
    this.selectedDmId = array;
    this.dmCtrl.setValue(array);
    this.onSearch(); 
  }

  OnselectOfGdm(event) {
    let array = event.value;
    if ((array.indexOf(-1) > -1 && this.disableAllGDM) || array.length === 0) {
      // select -1 and remove other selections
      this.selectedGdmId = [-1];
      this.gdmCtrl.setValue(this.selectedGdmId);
      this.disableAllGDM = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
    }
    this.disableAllGDM = true;
    this.selectedGdmId = array;
    this.gdmCtrl.setValue(array);
    this.onSearch();
   
  }
  OnselectOfPm(event) {
    let array = event.value;
    if ((array.indexOf(-1) > -1 && this.disableAllPM) || array.length === 0) {
      // select -1 and remove other selections
      this.selectedPmId = [-1];
      this.pmCtrl.setValue(this.selectedPmId);

      this.disableAllPM = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
    }
    this.disableAllPM = true;
    this.selectedPmId = array;
    this.pmCtrl.setValue(array);
    this.onSearch();  
  }

  OnselectOfGdd(event) {
    let array = event.value;
    if ((array.indexOf(-1) > -1 && this.disableAllGDD) || array.length === 0) {
      // select -1 and remove other selections
      this.selectedGddId = [-1];
      this.gddCtrl.setValue(this.selectedGddId);

      this.disableAllGDD = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
    }
    this.disableAllGDD = true;
    this.selectedGddId = array;
    this.gddCtrl.setValue(array);
    this.onSearch();
   
  }

  onSelectOfBu(event) {
    let array = event.value;

    if ((array.indexOf(-1) > -1 && this.disableAllBU) || array.length === 0) {
      // select -1 and remove other selections
      this.selectedBuId = [-1];
      this.buCtrl.setValue(this.selectedBuId);

      this.disableAllBU = false;
      this.onSearch();
      return;
    }
    if (array.length > 1 && array.indexOf(-1) > -1) {
      //remove -1 from list if anything else is selected
      array = array.filter(function (item) {
        return item !== -1;
      });
    }
    this.disableAllBU = true;
    this.selectedBuId = array;
    this.buCtrl.setValue(array);
    this.onSearch();
  
  }

  onSelectOfTtp(event: any) {

  let value = event.value || [];

  // If All TTP selected
  if (value.includes(-1) && value.length > 1) {

    // previously All was selected 
    if (this.selectedTtp.includes(-1)) {
      value = value.filter(v => v !== -1);
    } 
    // If user clicked All TTP with others selected
    else {
      value = [-1];
    }
  }

  // If everything is deselected
  if (value.length === 0) {
    value = [-1];
  }

  this.selectedTtp = value;

 
  this.ttpCtrl.setValue(this.selectedTtp);

  this.onSearch();
}

  OnselectOfGdpId(event) {
    this.selectedGdpId = event.value;
    this.onSearch();
  }

  OnselectOfPsId(event) {
    this.selectedPsId = event.value;
    this.onSearch();
  }
  getOpcoDropdown() {
    this.demoService.getOpcoDropdown()
      .subscribe((data) => {
        this.operatingCompanyDropdown = data.data;
        // const defaultOption = {
        //   id: '1',
        //   opcoName: 'TEKSystems Global Services', // Modify this to match your API response
        // };

        // // Prepend the default option
        // this.operatingCompanyDropdown.unshift(defaultOption);
      });
  
  }
  

  /**Tooltip functions**/
  getGDMToolTip() {
    return this.gdmFilterOptions
      ?.filter((e) => this.selectedGdmId.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }
  getPMToolTip() {
    return this.pmFilterOptions
      ?.filter((e) => this.selectedPmId.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }

  getGDDToolTip() {
    return this.gddFilterOptions
      ?.filter((e) => this.selectedGddId.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }

  getCSLToolTip() {
    return this.cslFilterOptions
      ?.filter((e) => this.selectedCsl.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }

  getBUToolTip() {
    return this.buIdFilterOptions
      ?.filter((e) => this.selectedBuId.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }

  getTTPToolTip() {
  return this.ttpFilterOptions
    ?.filter((e) => this.selectedTtp.indexOf(e.id) > -1)
    .map((e) => e.name)
    .join(', ');
}

  getLODToolTip() {
    return this.lodFilterOptions
      ?.filter((e) => this.selectedLOD.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }

  getDMToolTip() {
    return this.dmFilterOptions
      ?.filter((e) => this.selectedDmId.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }

  getPracticeToolTip() {
    return this.practiceEngagementsFilterOptions
      ?.filter((e) => this.selectedPracticeEngagementId.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }

  getAccountToolTip() {
    return this.accountNameFilterOptions
      ?.filter((e) => this.selectedAccountId.indexOf(e.id) > -1)
      .map((e) => e.name)
      .join(', ');
  }

  getPsIdToolTip() {
    return this.psIdFilterOptions
      ?.filter((e) => this.selectedPsId == e.id)
      .map((e) => e.name)
      .join(', ');
  }
  getGdpToolTip() {
    return this.gdpIdFilterOptions
      ?.filter((e) => this.selectedGdpId == e.id)
      .map((e) => e.name)
      .join(', ');
  }

  /**
   * search on basis of values selected in each field
   */
  onSearch() {
    this.currentPage = 0;
    this.filterValues.active =
      this.selectedEngagementStatus === undefined
        ? 1
        : this.selectedEngagementStatus;
    this.filterValues.clientId =
      this.selectedAccountId === undefined ? [-1] : this.selectedAccountId;
    this.filterValues.deliveryOrganizationTypeId =
      this.selectedPracticeEngagementId === undefined
        ? [-1]
        : this.selectedPracticeEngagementId;
    this.filterValues.cslId =
      this.selectedCsl === undefined ? [-1] : this.selectedCsl;
    this.filterValues.gdmId =
      this.selectedGdmId === undefined ? [-1] : this.selectedGdmId;
    this.filterValues.programManagerId =
      this.selectedPmId === undefined ? [-1] : this.selectedPmId;
    this.filterValues.gddId =
      this.selectedGddId === undefined ? [-1] : this.selectedGddId;
    this.filterValues.projectId =
      this.selectedGdpId === undefined ? -1 : this.selectedGdpId;
    this.filterValues.psId =
      this.selectedPsId === undefined ? -1 : this.selectedPsId;
    this.filterValues.orderByAttribute =
      this.orderByAttribute === undefined
        ? 'projectName'
        : this.orderByAttribute;
    this.filterValues.sortDirection =
      this.sortDirection === undefined ? 'asc' : this.sortDirection;
    if (this.postPerPage > 100) {
      this.postPerPage = 15;
    }
    this.filterValues.businessUnitId =
    this.selectedBuId === undefined ? [-1] : this.selectedBuId;
      
   
    this.filterValues.ttpId =
    !this.selectedTtp || this.selectedTtp.length === 0 ? [-1] : this.selectedTtp;
    

    this.filterValues.lodId =
    this.selectedLOD === undefined ? [-1] : this.selectedLOD;
    this.filterValues.dmId =
    this.selectedDmId === undefined ? [-1] : this.selectedDmId;
    
    this.searchProjectOnFilterValues(
      this.filterValues,
      this.currentPage,
      this.postPerPage,
      true
    );

    this.getAllProjectFilterValues(this.filterValues);
    this.cacheSearchFilters('true', false);  
   }
  searchProjectOnFilterValues(
  filterValues,
  currentPage,
  postPerPage,
  isPaginator
) {
  let ttpForApi: number[] = [];

if (this.selectedTtp && this.selectedTtp.length > 0) {

  if (this.selectedTtp.includes(-1)) {
    ttpForApi = [];
  } else {
    ttpForApi = [...this.selectedTtp];
  }
}



this.filterValues.ttpId = ttpForApi;

  const updatedFilters = {
    ...this.filterValues,
    ttpId: ttpForApi
  };
 
  this.demoService
    .searchProject(updatedFilters, this.currentPage, this.postPerPage, this.selectedOpcoId)
    .subscribe(
      (data) => {
        this.searchedData = data.data[0].projectStatusDtoList;
        this.totalPages = data.data[0].totalNumberOfElements;
        this.maxlenth = data.data[0].totalNumberOfElements;
        this.projectStatusArray = new MatTableDataSource<Project>(this.searchedData);
        this.sortDate();
        this.projectStatusArray.sort = this.sort;
        this.tableHasData = true;
        this.errorMessage = '';
        this.getPageSizeOptions();

        if (isPaginator) {
          this.actualPaginator.pageIndex = this.currentPage;
          this.actualPaginator.pageSizeOptions = this.itemsPerPage;
        }
      },
      (error) => {
        this.tableHasData = false;
        this.errorMessage = 'No records found!';
      }
    );
}
  // @ViewChild() paginator: MatPaginator; this.paginator.pageIndex = 0;

  /**
   * clear the search results
   */
  onClear() {
    this.disableAllCSL = false;
    this.disableAllGDM = false;
    this.disableAllPM = false;
    this.disableAllGDD = false;
    this.disableAllBU = false;
    this.disableAllTtp = false;
    this.disableAllLOD=false;
    this.disableAllPractice = false;
    this.disableAllAccount = false;
    this.disableAllDM = false;
    this.currentPage = this.tempPage;
    this.postPerPage = 15;
    this.showTotalPages = 5;
    this.filterValues.active = 1;
    this.filterValues.clientId = [-1];
    this.filterValues.deliveryOrganizationTypeId = [-1];
    this.filterValues.cslId = [-1];
    this.filterValues.gdmId = [-1];
    this.filterValues.programManagerId = [-1];
    this.filterValues.gddId = [-1];
    this.filterValues.businessUnitId = [-1];
    this.filterValues.ttpId = [-1];
    this.filterValues.projectId = -1;
    this.filterValues.psId = -1;
    this.filterValues.lodId = [-1];
    this.filterValues.dmId = [-1];

    this.defaultEngagementStatusValue = 1;
    this.getProjectStatusDetails(true);
    this.selectedEngagementStatus = 1;
    this.selectedAccountId = [-1];
    this.selectedPracticeEngagementId = [-1];
    this.selectedCsl = [-1];
    this.selectedGdmId = [-1];
    this.selectedPmId = [-1];
    this.selectedGddId = [-1];
    this.selectedGdpId = -1;
    this.selectedBuId = [-1];
    this.selectedTtp = [-1];
    this.selectedPsId = -1;
    this.selectedLOD = [-1];
    this.selectedDmId = [-1];
    this.getAllProjectFilterValues(this.filterValues);
    this.ngAfterViewInit();
    this.cacheSearchFilters('false', false);
  }

  getGdpIdFilterOptionsValue() {
    // tslint:disable-next-line: quotemark
    const defaultGdpId = { name: "All GDP ID's", id: -1 };
    this.gdpIdFilterOptions.unshift(defaultGdpId);
    this.gdpIdCtrl.setValue(this.gdpIdFilterOptions[0].id);
    this.filteredGdpId.next(this.gdpIdFilterOptions);
    this.gdpIdFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterGdpId();
      });
  }

  getPsIdFilterOptionsValue() {
    // tslint:disable-next-line: quotemark
    const defaultPsId = { name: "All Project ID's", id: -1 };
    this.psIdFilterOptions.unshift(defaultPsId);
    this.psIdCtrl.setValue(this.psIdFilterOptions[0].id);
    this.filteredPSIds.next(this.psIdFilterOptions);
    this.psIdFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterPsId();
      });
  }

  getCslsFilterOptionsValue() {
    const defaultCsl = { id: -1, name: Constants.ALL_EM };
    this.cslFilterOptions.unshift(defaultCsl);
    this.cslCtrl.setValue([this.cslFilterOptions[0].id]);
    this.filteredCsl.next(this.cslFilterOptions);
    this.cslFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterCsl();
      });
  }

  getGdmsFilterOptionsValue() {
    const defaultGdm = { id: -1, name: Constants.ALL_GDM };
    this.gdmFilterOptions.unshift(defaultGdm);
    this.gdmCtrl.setValue([this.gdmFilterOptions[0].id]);
    this.filteredGdm.next(this.gdmFilterOptions);
    this.gdmFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterGdm();
      });
  }

  getPmsFilterOptionsValue() {
    const defaultPm = { id: -1, name: Constants.ALL_PrgM };
    this.pmFilterOptions.unshift(defaultPm);
    this.pmCtrl.setValue([this.pmFilterOptions[0].id]);
    this.filteredPm.next(this.pmFilterOptions);
    this.pmFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterPm();
      });
  }

  getGddsFilterOptionsValue() {
    const defaultGdd = { id: -1, name: Constants.ALL_GDD };
    this.gddFilterOptions.unshift(defaultGdd);
    this.gddCtrl.setValue([this.gddFilterOptions[0].id]);
    this.filteredGdd.next(this.gddFilterOptions);
    this.gddFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterGdd();
      });
  }

  getBUsFilterOptionsValue() {
    const defaultBU = { id: -1, name: Constants.ALL_BU };
    this.buIdFilterOptions.unshift(defaultBU);
    this.buCtrl.setValue([this.buIdFilterOptions[0].id]);
    this.filteredBUs.next(this.buIdFilterOptions);
    this.buFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterBU();
      });
  }

  getTTPFilterOptionsValue() {

  const defaultTtp: Filter = { id: -1, name: 'All TTP' };

  if (!this.ttpFilterOptions.find(x => x.id === -1)) {
    this.ttpFilterOptions.unshift(defaultTtp);
  }

  this.filteredTtps.next(this.ttpFilterOptions);
  
  // selectedTtp has a  value
 if (!this.selectedTtp || this.selectedTtp.length === 0) {
  this.selectedTtp = [-1];
}
  
  // restore dropdown
 
 this.ttpCtrl.setValue(this.selectedTtp);


  this.ttpFilterCtrl.valueChanges
    .pipe(takeUntil(this.onDestroy))
    .subscribe(() => {
      this.filterTTP();
    });
}
  getLODFilterOptionsValue() {
    // tslint:disable-next-line: quotemark
    const defaultLOD = {id: -1, name: "All Location's of Delivery" };
    this.lodFilterOptions.unshift(defaultLOD);
    this.lodCtrl.setValue([this.lodFilterOptions[0].id]);
    this.filteredLODs.next(this.lodFilterOptions);
    this.lodFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterLOD();
      });
  }

  getDMFilterOptionsValue() {
    // tslint:disable-next-line: quotemark
    const defaultDM = { id: -1, name: "All Delivery Models" };
    this.dmFilterOptions.unshift(defaultDM);
    this.dmCtrl.setValue([this.dmFilterOptions[0].id]);
    this.filteredDMs.next(this.dmFilterOptions);
    this.dmFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterDM();
      });
  }

  getPracticeEngagementsFilterOptionsValue() {
    const defaultPracticeEngagement = {
      id: -1,
      name: 'All Practice',
    };
    this.practiceEngagementsFilterOptions.unshift(defaultPracticeEngagement);
    this.projectCtrl.setValue([this.practiceEngagementsFilterOptions[0].id]);
    this.filteredProjects.next(this.practiceEngagementsFilterOptions);
    this.projectFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterProjects();
      });
  }

  getAccountNameFilterOptionsValue() {
    const defaultAccount = { name: 'All Account Names', id: -1 };
    this.accountNameFilterOptions.unshift(defaultAccount);
    // set initial selection
    this.accountNameCtrl.setValue([this.accountNameFilterOptions[0].id]);
    // load the initial project list
    this.filteredAccountName.next(this.accountNameFilterOptions);
    // listen for search field value changes
    this.accountNameFilterCtrl.valueChanges
      .pipe(takeUntil(this.onDestroy))
      .subscribe(() => {
        this.filterAccountName();
      });
  }

  protected setInitialValuePracticeEngagement() {
    this.filteredProjects
      .pipe(take(1), takeUntil(this.onDestroy))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        if (this.singleSelect) {
          this.singleSelect.compareWith = (a: Filter, b: Filter) =>
            a && b && a.id === b.id;
        }
      });
  }

  protected filterProjects() {
    if (!this.practiceEngagementsFilterOptions) {
      return;
    }
    // get the search keyword
    let search = this.projectFilterCtrl.value;
    if (!search) {
      this.filteredProjects.next(this.practiceEngagementsFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredProjects.next(
      this.practiceEngagementsFilterOptions.filter(
        (practiceEngagementsFilterOption) =>
          practiceEngagementsFilterOption.name.toLowerCase().includes(search)
      )
    );
  }

  protected setInitialValueAccountName() {
    this.filteredAccountName
      .pipe(take(1), takeUntil(this.onDestroy))
      .subscribe(() => {
        if (this.singleSelect) {
          this.singleSelect.compareWith = (a: Filter, b: Filter) =>
            a && b && a.id === b.id;
        }
      });
  }

  protected filterAccountName() {
    if (!this.accountNameFilterOptions) {
      return;
    }
    let search = this.accountNameFilterCtrl.value;
    if (!search) {
      this.filteredAccountName.next(this.accountNameFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredAccountName.next(
      this.accountNameFilterOptions.filter((accountNameFilterOption) =>
        accountNameFilterOption.name.toLowerCase().includes(search)
      )
    );
  }

  protected setInitialValuecsl() {
    this.filteredCsl.pipe(take(1), takeUntil(this.onDestroy)).subscribe(() => {
      if (this.singleSelect) {
        this.singleSelect.compareWith = (a: Filter, b: Filter) =>
          a && b && a.id === b.id;
      }
    });
  }

  protected setInitialValueGdm() {
    this.filteredGdm.pipe(take(1), takeUntil(this.onDestroy)).subscribe(() => {
      if (this.singleSelect) {
        this.singleSelect.compareWith = (a: Filter, b: Filter) =>
          a && b && a.id === b.id;
      }
    });
  }

  protected setInitialValueLOD() {
    this.filteredLODs.pipe(take(1), takeUntil(this.onDestroy)).subscribe(() => {
      if (this.singleSelect) {
        this.singleSelect.compareWith = (a: Filter, b: Filter) =>
          a && b && a.id === b.id;
      }
    });
  }

  protected setInitialValuePm() {
    this.filteredPm.pipe(take(1), takeUntil(this.onDestroy)).subscribe(() => {
      if (this.singleSelect) {
        this.singleSelect.compareWith = (a: Filter, b: Filter) =>
          a && b && a.id === b.id;
      }
    });
  }

  protected setInitialValueDM() {
    this.filteredDMs.pipe(take(1), takeUntil(this.onDestroy)).subscribe(() => {
      if (this.singleSelect) {
        this.singleSelect.compareWith = (a: Filter, b: Filter) =>
          a && b && a.id === b.id;
      }
    });
  }
  protected setInitialValueTtp() {
  this.filteredTtps
    .pipe(take(1), takeUntil(this.onDestroy))
    .subscribe(() => {
      if (this.singleSelect) {
        this.singleSelect.compareWith = (a: Filter, b: Filter) =>
          a && b && a.id === b.id;
      }
    });
}

  protected setInitialValueGdd() {
    this.filteredGdd.pipe(take(1), takeUntil(this.onDestroy)).subscribe(() => {
      if (this.singleSelect) {
        this.singleSelect.compareWith = (a: Filter, b: Filter) =>
          a && b && a.id === b.id;
      }
    });
  }

  protected filterCsl() {
    if (!this.cslFilterOptions) {
      return;
    }
    let search = this.cslFilterCtrl.value;
    if (!search) {
      this.filteredCsl.next(this.cslFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredCsl.next(
      this.cslFilterOptions.filter((cslFilterOption) =>
        cslFilterOption.name.toLowerCase().includes(search)
      )
    );
  }

  protected filterGdm() {
    if (!this.gdmFilterOptions) {
      return;
    }
    let search = this.gdmFilterCtrl.value;
    if (!search) {
      this.filteredGdm.next(this.gdmFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredGdm.next(
      this.gdmFilterOptions.filter((gdmFilterOption) =>
        gdmFilterOption.name.toLowerCase().includes(search)
      )
    );
  }

  protected filterPm() {
    if (!this.pmFilterOptions) {
      return;
    }
    let search = this.pmFilterCtrl.value;
    if (!search) {
      this.filteredPm.next(this.pmFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredPm.next(
      this.pmFilterOptions.filter((pmFilterOption) =>
        pmFilterOption.name.toLowerCase().includes(search)
      )
    );
  }

  protected filterGdd() {
    if (!this.gddFilterOptions) {
      return;
    }
    let search = this.gddFilterCtrl.value;
    if (!search) {
      this.filteredGdd.next(this.gddFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredGdd.next(
      this.gddFilterOptions.filter((gddFilterOptions) =>
        gddFilterOptions.name.toLowerCase().includes(search)
      )
    );
  }

  protected filterBU() {
    if (!this.buIdFilterOptions) {
      return;
    }
    let search = this.buFilterCtrl.value;
    if (!search) {
      this.filteredBUs.next(this.buIdFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredBUs.next(
      this.buIdFilterOptions.filter((buIdFilterOption) =>
        buIdFilterOption.name.toLowerCase().includes(search)
      )
    );
  }
 protected filterTTP() {
  if (!this.ttpFilterOptions) {
    return;
  }

  

  const search = this.ttpFilterCtrl.value?.toLowerCase() || '';


  this.filteredTtps.next(
    this.ttpFilterOptions.filter(option =>
      option.name.toLowerCase().indexOf(search) !== -1
    )
  );
}

 protected filterLOD() {
    if (!this.lodFilterOptions) {
      return;
    }
    let search = this.lodFilterCtrl.value;
    if (!search) {
      this.filteredLODs.next(this.lodFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredLODs.next(
      this.lodFilterOptions.filter((lodFilterOption) =>
        lodFilterOption.name.toLowerCase().includes(search)
      )
    );
  }

  protected filterDM() {
    if (!this.dmFilterOptions) {
      return;
    }
    let search = this.dmFilterCtrl.value;
    if (!search) {
      this.filteredDMs.next(this.dmFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredDMs.next(
      this.dmFilterOptions.filter((dmFilterOption) =>
        dmFilterOption.name.toLowerCase().includes(search)
      )
    );
  }

  // For GdpId
  /**
   * Sets the initial value after the filteredProjects are loaded initially
   */
  protected setInitialValueGdpId() {
    this.filteredGdpId
      .pipe(take(1), takeUntil(this.onDestroy))
      .subscribe(() => {
        if (this.singleSelect) {
          this.singleSelect.compareWith = (a: Filter, b: Filter) =>
            a && b && a.id === b.id;
        }
      });
  }

  protected setInitialValuePsId() {
    this.filteredPSIds
      .pipe(take(1), takeUntil(this.onDestroy))
      .subscribe(() => {
        if (this.singleSelect) {
          this.singleSelect.compareWith = (a: Filter, b: Filter) =>
            a && b && a.id === b.id;
        }
      });
  }

  protected filterGdpId() {
    if (!this.gdpIdFilterOptions) {
      return;
    }
    let search = this.gdpIdFilterCtrl.value;
    if (!search) {
      this.filteredGdpId.next(this.gdpIdFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredGdpId.next(
      this.gdpIdFilterOptions.filter((gdpIdFilterOption) =>
        gdpIdFilterOption.name.includes(search)
      )
    );
  }

  protected filterPsId() {
    if (!this.psIdFilterOptions) {
      return;
    }
    let search = this.psIdFilterCtrl.value;
    if (!search) {
      this.filteredPSIds.next(this.psIdFilterOptions);
      return;
    } else {
      search = search.toLowerCase();
    }
    this.filteredPSIds.next(
      this.psIdFilterOptions.filter((psIdFilterOption) =>
        psIdFilterOption.name.includes(search)
      )
    );
  }

  getProjectStatusDetails(isPaginator) {
    console.log(this.selectedOpcoId);
    this.demoService
      .getProjectStatus(this.currentPage, this.postPerPage, this.selectedOpcoId)
      .subscribe((data) => {
        this.data = data.data[0].projectStatusDtoList;
        this.totalPages = data.data[0].totalNumberOfElements;
        this.maxlenth = data.data[0].totalNumberOfElements;
        this.projectStatusArray = new MatTableDataSource<Project>(this.data);
        const projectStatusList = data.data[0].projectStatusDtoList;
        const opcoIds = projectStatusList.map((item) => item.opcoId);
        this.sortDate();
        this.projectStatusArray.sort = this.sort;
        if (this.projectStatusArray.data.length > 0) {
          this.tableHasData = true;
        } else {
          this.tableHasData = false;
        }
        this.getPageSizeOptions();
        if (isPaginator) {
          this.actualPaginator.pageIndex = this.currentPage;
          this.actualPaginator.pageSizeOptions = this.itemsPerPage;
          //this.actualPaginator.length = this.totalPages;
          //this.actualPaginator.pageSize = this.postPerPage;
          //this.projectStatusArray.paginator = this.actualPaginator;
        }
      });
  }

  getAllProjectFilterValues(filters: SearchProject) {
    console.log("SEE HERE")
    console.log(this.filterValues)
 
    this.demoService
      .getListOfFilterValuesForAllProjects(filters, this.selectedOpcoId)
      .subscribe((data) => {
        console.log(data.data[0]);
        this.accountNameFilterOptions = data.data[0]['accountNameList'].map(
          (eachProject) => {
            return { id: eachProject.id, name: eachProject.name };
          }
        );
        
        this.getAccountNameFilterOptionsValue();

        this.practiceEngagementsFilterOptions = data.data[0][
          'practiceEngagementList'
        ].map((eachProject) => {
          return { id: eachProject.id, name: eachProject.name };
        });
        this.getPracticeEngagementsFilterOptionsValue();

        this.dmFilterOptions = data.data[0]['deliverymodelList']
          .map((eachProject) => {
            return { id: eachProject.id, name: eachProject.name };
          }
          );
        this.getDMFilterOptionsValue();

        this.cslFilterOptions = data.data[0]['cslList'].map((eachProject) => {
          return { id: eachProject.id, name: eachProject.name };
        });
        this.getCslsFilterOptionsValue();

        this.gdmFilterOptions = data.data[0]['gdmList'].map((eachProject) => {
          return { id: eachProject.id, name: eachProject.name };
        });
        this.getGdmsFilterOptionsValue();

        this.gddFilterOptions = data.data[0]['gddList'].map((eachProject) => {
          return { id: eachProject.id, name: eachProject.name };
        });
        this.getGddsFilterOptionsValue();

        this.buIdFilterOptions = data.data[0]['businessUnitList'].map(
          (eachProject) => {
            return { id: eachProject.id, name: eachProject.name };
          }
        );
        this.getBUsFilterOptionsValue();
        
        this.ttpFilterOptions = (data.data[0]['ttpList'] || []).map(item => {
        return {
          id: item.id,    
          name: item.name
               };
        });

       this.getTTPFilterOptionsValue();
       

      
        this.lodFilterOptions = data.data[0]['locationList'].map(
          (eachProject) => {
            return { id: eachProject.id, name: eachProject.name };
          }
        );
        this.getLODFilterOptionsValue();
       

        this.gdpIdFilterOptions = data.data[0]['gdpIdList'].map(
          (eachProject) => {
            return { id: eachProject.id, name: eachProject.name };
          }
        );
        this.getGdpIdFilterOptionsValue();

        this.psIdFilterOptions = data.data[0]['psProjectIdList'].map(
          (eachProject) => {
            return { id: eachProject.id, name: eachProject.name };
          }
        );
        this.getPsIdFilterOptionsValue();

        this.pmFilterOptions = data.data[0]['programManager'].map(
          (eachProject) => {
            return { id: eachProject.id, name: eachProject.name };
          }
        );
        this.getPmsFilterOptionsValue();       
        if (this.selectedGdpId !== -1 && this.selectedGdpId !== undefined)
          this.gdpIdCtrl.setValue(this.selectedGdpId);
        if (this.selectedPsId !== -1 && this.selectedPsId !== undefined)
          this.psIdCtrl.setValue(this.selectedPsId);
        if (
          this.selectedAccountId !== [-1] &&
          this.selectedAccountId !== undefined
        )
          this.accountNameCtrl.setValue(this.selectedAccountId);
        if (
          this.selectedPracticeEngagementId !== [-1] &&
          this.selectedPracticeEngagementId !== undefined
        )
          this.projectCtrl.setValue(this.selectedPracticeEngagementId);
        if (this.selectedCsl !== [-1] && this.selectedCsl !== undefined)
          this.cslCtrl.setValue(this.selectedCsl);
        if (this.selectedGdmId !== [-1] && this.selectedGdmId !== undefined)
          this.gdmCtrl.setValue(this.selectedGdmId);
        if (this.selectedPmId !== [-1] && this.selectedPmId !== undefined)
          this.pmCtrl.setValue(this.selectedPmId);
        if (this.selectedGddId !== [-1] && this.selectedGddId !== undefined)
          this.gddCtrl.setValue(this.selectedGddId);
        if (this.selectedBuId !== [-1] && this.selectedBuId !== undefined)
          this.buCtrl.setValue(this.selectedBuId);
        if (this.selectedLOD !== [-1] && this.selectedLOD !== undefined)
          this.lodCtrl.setValue(this.selectedLOD);
        if (this.selectedDmId !== [-1] && this.selectedDmId !== undefined)
          this.dmCtrl.setValue(this.selectedDmId);
      });
    console.log("checking if accountname filter options are assigned or not")
    console.log(this.accountNameFilterOptions)
  }

  onChangedPage(pageData: PageEvent) {
    this.currentPage = pageData.pageIndex;
    this.postPerPage = pageData.pageSize;
    this.checkFlag = this.checkFilterValuesIsNotEmpty(this.filterValues);
    if (this.checkFlag) {
      this.getProjectStatusDetails(false);
      this.tempPage = this.currentPage;
    } else {
      this.searchProjectOnFilterValues(
        this.filterValues,
        0,
        this.postPerPage,
        false
      );
    }
    this.cacheSearchFilters('true', true);
  }

  checkFilterValuesIsNotEmpty(filterValues) {
    return (
      (this.filterValues.active === 1 ||
        this.filterValues.active === undefined) &&
      (this.filterValues.clientId === [-1] ||
        this.filterValues.clientId === undefined) &&
      (this.filterValues.deliveryOrganizationTypeId === [-1] ||
        this.filterValues.deliveryOrganizationTypeId === undefined) &&
      (this.filterValues.cslId === [-1] ||
        this.filterValues.cslId === undefined) &&
      (this.filterValues.projectId === -1 ||
        this.filterValues.projectId === undefined) &&
      (this.filterValues.gdmId === [-1] ||
        this.filterValues.gdmId === undefined) &&
      (this.filterValues.programManagerId === [-1] ||
        this.filterValues.programManagerId === undefined) &&
      (this.filterValues.gddId === [-1] ||
        this.filterValues.gddId === undefined) &&
      (this.filterValues.psId === -1 || this.filterValues.psId === undefined) &&
      (this.filterValues.dmId === [-1] || this.filterValues.dmId === undefined)
    );
  }
  sortDate() {
    this.projectStatusArray.sortingDataAccessor = (
      item,
      property
    ): string | number => {
      switch (property) {
        case 'statusDate':
          return Number(new Date(item.statusDate));
        default:
          return item[property];
      }
    };
  }

  cacheSearchFilters(cache: string, fromPaginator: boolean) {
    this.filterValues.orderByAttribute =
      this.orderByAttribute === undefined
        ? 'projectName'
        : this.orderByAttribute;
    this.filterValues.sortDirection =
      this.sortDirection === undefined ? 'asc' : this.sortDirection;
    if (!fromPaginator && this.postPerPage > 100) {
      this.postPerPage = 15;
    }
    localStorage.setItem('filters_cached', cache);
    localStorage.setItem('active', this.filterValues.active.toString());
    localStorage.setItem('clientId', this.filterValues.clientId.toString());
    localStorage.setItem(
      'deliveryOrganizationTypeId',
      this.filterValues.deliveryOrganizationTypeId.toString()
    );
    localStorage.setItem('cslId', this.filterValues.cslId.toString());
    localStorage.setItem('projectId', this.filterValues.projectId.toString());
    localStorage.setItem('gdmId', this.filterValues.gdmId.toString());
    localStorage.setItem('pmId', this.filterValues.programManagerId.toString());
    localStorage.setItem('gddId', this.filterValues.gddId.toString());
    localStorage.setItem('LODId', this.filterValues.lodId.toString());
    localStorage.setItem('dmId', this.filterValues.dmId.toString());
    localStorage.setItem(
      'businessUnitId',
      this.filterValues.businessUnitId.toString()
    );
    localStorage.setItem('ttpId', this.selectedTtp.join(','));
   
    localStorage.setItem('psId', this.filterValues.psId.toString());
    localStorage.setItem('currentPage', this.currentPage.toString());
    localStorage.setItem('postPerPage', this.postPerPage.toString());
    localStorage.setItem('orderByAttribute', 'projectName');
    localStorage.setItem('sortDirection', this.filterValues.sortDirection);
    if(Constants.CURRENT_ROLE==='Admin'||Constants.CURRENT_ROLE==='Executive'){
      localStorage.setItem('opcoId', this.sharedService.sharedDataSubject.value||'1'); 
      console.log('cacheopco',this.cacheOpco);
    }else{
      localStorage.setItem('opcoId', Constants.OPCO_ID)
    }
  }

  isFilterCached(): boolean {
    return localStorage.getItem('filters_cached') === 'true' ? true : false;
  }

  readFilterCache() {
    this.selectedEngagementStatus = Number.parseInt(
      localStorage.getItem('active')
    );
    this.defaultEngagementStatusValue = this.selectedEngagementStatus;
    this.selectedAccountId = localStorage
      .getItem('clientId')
      ?.split(',')
      .map((e) => Number.parseInt(e));
    this.selectedPracticeEngagementId = localStorage
      .getItem('deliveryOrganizationTypeId')
      ?.split(',')
      .map((e) => Number.parseInt(e));
    this.selectedCsl = localStorage
      .getItem('cslId')
      ?.split(',')
      .map((e) => Number.parseInt(e));
    this.selectedGdpId = Number.parseInt(localStorage.getItem('projectId'));
    this.selectedPsId = Number.parseInt(localStorage.getItem('psId'));
    this.selectedGdmId = localStorage
      .getItem('gdmId')
      ?.split(',')
      .map((e) => Number.parseInt(e));
      this.selectedLOD = localStorage
      .getItem('LODId')
      ?.split(',')
      .map((e) => Number.parseInt(e));
    this.selectedDmId = localStorage
      .getItem('dmId')
      ?.split(',')
      .map((e) => Number.parseInt(e));
    this.selectedPmId = localStorage
      .getItem('pmId')
      ?.split(',')
      .map((e) => Number.parseInt(e));
    this.selectedGddId = localStorage
      .getItem('gddId')
      ?.split(',')
      .map((e) => Number.parseInt(e));
    this.selectedBuId = localStorage
      .getItem('businessUnitId')
      ?.split(',')
      .map((e) => Number.parseInt(e));

     
    const cachedTTP = localStorage.getItem('ttpId');
    if (cachedTTP) {
  
    this.selectedTtp = cachedTTP
    .split(',')
    .map(v => Number(v.trim()))
    .filter(v => !isNaN(v));
     if (this.selectedTtp.length === 0) this.selectedTtp = [-1];
    } else {
  this.selectedTtp = [-1];
    }



    this.currentPage = Number.parseInt(localStorage.getItem('currentPage'));
    this.postPerPage = Number.parseInt(localStorage.getItem('postPerPage'));
    this.filterValues.active = this.selectedEngagementStatus;
    this.filterValues.clientId = this.selectedAccountId;
    this.filterValues.deliveryOrganizationTypeId = this.selectedPracticeEngagementId;
    this.filterValues.cslId = this.selectedCsl;
    this.filterValues.gdmId = this.selectedGdmId;
    this.filterValues.programManagerId = this.selectedPmId;
    this.filterValues.gddId = this.selectedGddId;
    this.filterValues.businessUnitId = this.selectedBuId;
    this.filterValues.projectId = this.selectedGdpId;
    this.filterValues.psId = this.selectedPsId;
    this.filterValues.lodId = this.selectedLOD;
    this.filterValues.dmId = this.selectedDmId;
    this.filterValues.ttpId = this.selectedTtp;
   
    this.filterValues.orderByAttribute = 'projectName';
    this.filterValues.sortDirection = localStorage.getItem('sortDirection');
    this.disableAllGDM =
      JSON.stringify(this.selectedGdmId) != JSON.stringify([-1]);
    this.disableAllPM =
      JSON.stringify(this.selectedPmId) != JSON.stringify([-1]);
    this.disableAllGDD =
      JSON.stringify(this.selectedGddId) != JSON.stringify([-1]);
    this.disableAllCSL =
      JSON.stringify(this.selectedCsl) != JSON.stringify([-1]);
    this.disableAllBU =
      JSON.stringify(this.selectedBuId) != JSON.stringify([-1]);
    this.disableAllPractice =
      JSON.stringify(this.selectedPracticeEngagementId) != JSON.stringify([-1]);
    this.disableAllAccount =
      JSON.stringify(this.selectedAccountId) != JSON.stringify([-1]);
    this.disableAllLOD =
      JSON.stringify(this.selectedLOD) != JSON.stringify([-1]);
    this.disableAllDM = 
      JSON.stringify(this.selectedDmId) != JSON.stringify([-1]);
    this.selectedOpcoId = localStorage.getItem('opcoId');
    this.sharedService.emitData(this.selectedOpcoId);
    this.sharedService.emitDataNavbar(this.selectedOpcoId);

  }

  openDialog(Summary) {
    if (Summary == null) {
      Summary = 'No Comments';
    }
    this.dialog.open(SummarypopupComponent, {
      data: {
        Summary,
      },
    });
  }
  onPageEvent = ($event) => {
    console.log($event);
    this.getProjectStatusDetails(false);
  };
  onSelect(event: MouseEvent): void {
    event.stopPropagation();
  }
  
}

        