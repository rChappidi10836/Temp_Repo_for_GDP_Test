// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  authProperties: {
    clientId: '31b402e2-aec3-46c8-9bd1-7e66abbf941b', // This is your client ID
    authority:
      'https://login.microsoftonline.com/6e9aafce-fe2c-48e4-b4b0-2f023408fc89', // This is your tenant ID
    redirectUri: `${window.location.origin}/#/dashboard`, // This is your redirect URI
  },
  linkToServiceNow:
    'https://allegisgroup.service-now.com/tgs?id=sc_category&sys_id=c1f05016db0bb700137ef3d51d961945&catalog_id=-1',
};

export const apiUri = '/gdp/';

//  in local
// export const apiUri = 'http://localhost:8080/gdp/';


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
