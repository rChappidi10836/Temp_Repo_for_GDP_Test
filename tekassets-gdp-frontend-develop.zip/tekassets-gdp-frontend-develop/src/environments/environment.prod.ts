export const environment = {
  production: true,
  authProperties: {
    clientId: 'f025ff75-cabf-49c1-b8b7-1d58871f3424', // This is your client ID
    authority:
      'https://login.microsoftonline.com/371cb917-b098-4303-b878-c182ec8403ac', // This is your tenant ID
    redirectUri: `${window.location.origin}/gdp/#/dashboard`, // This is your redirect URI
  },
  linkToServiceNow: 'https://allegisgroup.service-now.com/tgs?id=sc_category&sys_id=c1f05016db0bb700137ef3d51d961945&catalog_id=-1',
};


export const apiUri = '/gdp/';
